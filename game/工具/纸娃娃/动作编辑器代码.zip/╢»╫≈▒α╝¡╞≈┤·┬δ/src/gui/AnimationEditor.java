package gui;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.awt.Color;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class AnimationEditor
{
	public static void main(String[] args)
	{
		loadPreference();
		AniStudioFrm f = new AniStudioFrm();
		f.setVisible(true);
	}

	private static Color gridColor = new Color(0xA060A0);
	private static Color coordColor = new Color(0x0000D0);
	private static Color bgColor = new Color(0x909090);
	private static Color colColor = new Color(0x00FF00);
	private static Color selColor = new Color(0x0000FF);

	private static int frameTime = 100;
	private static String[] actorTypes = {
			"Rayman", "Fist", "Ting", "Life", "Cage", "Outlet", "Toon", "FishV", "FishH"
	};

	private static void writeColor(DataOutputStream dou, Color color) throws Exception
	{
		dou.writeInt(color.getRed());
		dou.writeInt(color.getGreen());
		dou.writeInt(color.getBlue());
	}

	private static Color readColor(DataInputStream din) throws Exception
	{
		int r = din.readInt();
		int g = din.readInt();
		int b = din.readInt();
		return new Color(r, g, b);
	}

	public static void savePreference()
	{
		try
		{
			FileOutputStream fou = new FileOutputStream("animation.cfg");
			DataOutputStream dou = new DataOutputStream(fou);
			writeColor(dou, gridColor);
			writeColor(dou, coordColor);
			writeColor(dou, bgColor);
			writeColor(dou, colColor);
			writeColor(dou, selColor);
			dou.writeInt(frameTime);
			dou.writeInt(actorTypes.length);
			for (int i = 0; i < actorTypes.length; i++)
			{
				dou.writeUTF(actorTypes[i]);
			}
			dou.close();
			fou.close();
		} catch (Exception e)
		{
		}
	}

	public static void loadPreference()
	{
		try
		{
			FileInputStream fin = new FileInputStream("animation.cfg");
			DataInputStream din = new DataInputStream(fin);
			gridColor = readColor(din);
			coordColor = readColor(din);
			bgColor = readColor(din);
			colColor = readColor(din);
			selColor = readColor(din);
			frameTime = din.readInt();
			String[] s = new String[din.readInt()];
			for (int i = 0; i < s.length; i++)
			{
				s[i] = din.readUTF();
			}
			actorTypes = s;
			din.close();
			fin.close();
		} catch (Exception e)
		{
		}
	}

	public static Color getGridColor()
	{
		return gridColor;
	}

	public static Color getCoordColor()
	{
		return coordColor;
	}

	public static Color getBGColor()
	{
		return bgColor;
	}

	public static Color getColColor()
	{
		return colColor;
	}

	public static Color getAttackColr()
	{
		return new Color(255, 0, 0);
	}

	public static Color getSelColor()
	{
		return selColor;
	}

	public static void setBGColor(Color color)
	{
		bgColor = color;
	}

	public static void setGridColor(Color color)
	{
		gridColor = color;
	}

	public static void setCoordColor(Color color)
	{
		coordColor = color;
	}

	public static void setColColor(Color color)
	{
		colColor = color;
	}

	public static void setSelColor(Color color)
	{
		selColor = color;
	}

	public static void setFrameTime(int t)
	{
		frameTime = t;
	}

	public static int getFrameTime()
	{
		return frameTime;
	}

	public static String[] getActorTypes()
	{
		return actorTypes;
	}

	public static void setActorTypes(String[] types)
	{
		actorTypes = types;
	}
}
