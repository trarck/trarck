/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.fontdemo.utils;

import javax.microedition.lcdui.Graphics;

public interface Screen{
	public void paint(Graphics g);
	public void update(); 
}
