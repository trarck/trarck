/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreezii@firstwave.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.firstwave.es
 * 
*/


//This is an example Title Screen.
//Modify this file as you want following the tutorials

//The main function
function Main()
{
  //Title of the Room
  SetTitle("Spooky Adventure");
  
  CreateScreen("Title",800,400)
  
  CreateStartButton("Start",346,74,227,500,"00");
  
  StartButton.Animate();
   
}

//Run the game
RunGame(); //Here we go!!!
