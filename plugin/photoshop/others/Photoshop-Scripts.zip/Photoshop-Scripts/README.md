Photoshop Scripts
================

A few Photoshop scripts to get you going

If you have any suggestions on any functions or questions, please submit an issue
