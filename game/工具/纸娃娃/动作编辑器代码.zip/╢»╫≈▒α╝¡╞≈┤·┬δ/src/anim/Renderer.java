package anim;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */
import java.awt.*;
import java.awt.geom.*;

public class Renderer
{
	public final static int FLAG_FLIPX = 1;
	public final static int FLAG_FLIPY = 2;
    public final static int FLAG_SELECTED = 4;
    public final static int FLAG_TASK = 8;
	Animation anim;
	int idAction, idFrame;
	AniFrame frame;
	Action action;
	Image[] image;
	int scale_factor, scale_shift;
	int flag;
    boolean m_bCycle;

	public Renderer(Animation a, int action_id, Image[] img) {
		anim = a;
        image = new Image[img.length];
        for (int i = img.length - 1; i >= 0; i--)
            image[i] = img[i];
		setAction(action_id, true);
	}

	private final int LP2DP(int x)
	{
		return x * scale_factor >> scale_shift;
	}

	void drawSprite(Graphics g, AniFrame frm, int id, int x, int y)
	{
		Sprite spt = (Sprite)frm.sprites.elementAt(id);
		Module mod = (Module)anim.modules.elementAt(spt.idModule);

		Graphics2D g2d = (Graphics2D)g;

		AffineTransform origXform = g2d.getTransform();
		AffineTransform newXform = (AffineTransform)(origXform.clone());
		newXform.scale(1.0 * scale_factor / (1 << scale_shift), 1.0 * scale_factor / (1 << scale_shift));
		newXform.translate(x, y);
		if((flag & FLAG_FLIPX) != 0)
		{
			newXform.scale(-1, 1);
		}
		if((flag & FLAG_FLIPY) != 0)
		{
			newXform.scale(1, -1);
		}
		newXform.concatenate(spt.trans);
		g2d.setTransform(newXform);
		g2d.drawImage(image[mod.idImage], 0, 0, mod.w, mod.h, mod.x, mod.y, mod.x + mod.w, mod.y + mod.h, null);

		if((flag & FLAG_SELECTED) != 0)
		{
			g.setXORMode(new Color(0xffffff));
			g.fillRect(0, 0, mod.w, mod.h);
			g.setPaintMode();
		}
		g2d.setTransform(origXform);
	}

	public void Render(Graphics g, int x, int y, int scale, int scaleShift, int f)
	{
		scale_shift = scaleShift;
		scale_factor = scale;
		flag = f;
		if (frame == null)
		{
			g.setColor(new Color((flag & FLAG_SELECTED) != 0?0xff0000:0xff));
			g.fillOval(LP2DP(x)-4, LP2DP(y)-4, 8, 8);
		}
		else
		{
			int n = frame.sprites.size();
			for(int i = 0 ; i < n; i++)
			{
				drawSprite(g, frame, i, x, y);
			}
		}
        if ((flag & FLAG_TASK) != 0)
        {
            g.setColor(new Color(0xFF0000));
            g.drawOval(LP2DP(x) - 2 , LP2DP(y) - 2, 5, 5);
        }
	}

	void setFrame(int id)
	{
		idFrame = id;
		if(action.frmIdTable.size() > id)
		{
			frame = (AniFrame)anim.getFrame(((Integer)action.frmIdTable.get(id)).intValue());
		}
		else
		{
			frame = null;
		}
	}

	public void setAction(int id, boolean cycle)
	{
		idAction = id;
		action = (Action)anim.actions.get(id);
		setFrame(0);
        m_bCycle = cycle;
	}

    public void setEndFrame()
    {
        if( action.frmIdTable.size() > 0 )
        {
            frame = (AniFrame)anim.getFrame(((Integer)action.frmIdTable.get(action.frmIdTable.size()-1)).intValue());
        }
    }


	public void nextFrame()
	{
		if(frame != null)
		{
			idFrame++;
			if(idFrame >= action.frmIdTable.size())
			{
				idFrame = 0;
			}
			setFrame(idFrame);
		}
	}

    //wangboqiang
    public AniFrame getCurFrame()
    {
        return frame;
    }
    //end
}
