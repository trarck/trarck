package gui;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.List;
import java.awt.Panel;
import java.awt.Point;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import anim.Animation;
import anim.Module;

public class ModuleDlg extends Dialog implements ActionListener, ItemListener
{
    /** ���а汾ID */
	private static final long serialVersionUID = -8905905263562263274L;
	private final static Color colorModule = new Color(0xA060A0);
    private final static Color colorModuleX = new Color(0x40FF40);
    private final static Color colorModuleY = new Color(0x4040FF);
    private final static Color colorModuleXY = new Color(0x40FFFF);

    public static int moduleSelId = -1;

    Frame ownerFrame;
    Vector modules;
    String imageFile;
    Image image;
    ImgCanvas imgCanvas;
    Animation anim;
    List modList;
    int imageWidth, imageHeight;

    private class ImgCanvas extends Canvas implements MouseListener, MouseMotionListener, KeyListener
    {
        /** ���а汾ID */
		private static final long serialVersionUID = -8095641001704988217L;
		final static int MAX_ZOOM = 10;
        int zoomLevel;
        int mouseMode;
        int curItem;
        Image scimg, bimg;
        Point mouseStartPos = new Point(0, 0);

        public ImgCanvas()
        {
            zoomLevel = 4;
            int w = image.getWidth(null) * zoomLevel;
            int h = image.getHeight(null) * zoomLevel;
            scimg = AniStudioFrm.instance.createImage(w, h);
            Graphics g = scimg.getGraphics();
            g.setColor(AnimationEditor.getBGColor());
            g.fillRect(0, 0, w, h);
            g.drawImage(image, 0, 0, scimg.getWidth(null), scimg.getHeight(null), 0, 0, image.getWidth(null), image.getHeight(null), null);
            bimg = AniStudioFrm.instance.createImage(image.getWidth(null) * zoomLevel, image.getHeight(null) * zoomLevel);
            setSize(image.getWidth(null) * MAX_ZOOM, image.getHeight(null) * MAX_ZOOM);
            addMouseListener(this);
            addMouseMotionListener(this);
            addKeyListener(this);
        }

        public void update(Graphics g)
        {
            paint(g);
        }

        public void drawAxis(Graphics g, int x, int y)
        {
            g.setColor(AnimationEditor.getSelColor());
            g.setXORMode(new Color(0xffffff));
            g.drawLine(0, y, 1000, y);
            g.drawLine(x, 0, x, 1000);
        }

        public void paint(Graphics g)
        {
            int i;
            Graphics bg = bimg.getGraphics();
            Module mod;

            bg.drawImage(scimg, 0, 0, null);

            moduleSelId = modList.getSelectedIndex();
            if (moduleSelId >= 0)
            {
                mod = (Module)modules.elementAt(moduleSelId);
                if (mod.idImage == anim.getCurImage())
                {
                    bg.setXORMode(new Color(0xffffff));
                    bg.fillRect(mod.x * zoomLevel, mod.y * zoomLevel, mod.w * zoomLevel, mod.h * zoomLevel);
                }
            }
            // draw module rect
            bg.setPaintMode();
            for (i = modules.size() - 1; i >= 0; i--)
            {
                mod = (Module)modules.elementAt(i);
                if (mod.idImage != anim.getCurImage())
                    continue;
                if (mod.flipX && mod.flipY)
                {
                    bg.setColor(colorModuleXY);
                }
                else if (mod.flipX)
                {
                    bg.setColor(colorModuleX);
                }
                else if (mod.flipY)
                {
                    bg.setColor(colorModuleY);
                }
                else
                {
                    bg.setColor(colorModule);
                }
                bg.drawRect(mod.x * zoomLevel, mod.y * zoomLevel, mod.w * zoomLevel - 1, mod.h * zoomLevel - 1);
            }
            drawAxis(bg, mouseStartPos.x * zoomLevel, mouseStartPos.y * zoomLevel);
            g.drawImage(bimg, 0, 0, null);
        }

        public void zoomIn()
        {
            if (zoomLevel < MAX_ZOOM)
            {
                zoomLevel++;
                int w = image.getWidth(null) * zoomLevel;
                int h = image.getHeight(null) * zoomLevel;
                setSize(w, h);
                scimg = createImage(w, h);
                Graphics g = scimg.getGraphics();
                g.setColor(AnimationEditor.getBGColor());
                g.fillRect(0, 0, w, h);
                scimg.getGraphics().drawImage(image, 0, 0, scimg.getWidth(null), scimg.getHeight(null), 0, 0, image.getWidth(null), image.getHeight(null), null);
                bimg = createImage(image.getWidth(null) * zoomLevel, image.getHeight(null) * zoomLevel);
            }
        }

        public void zoomOut()
        {
            if (zoomLevel > 1)
            {
                zoomLevel--;
                int w = image.getWidth(null) * zoomLevel;
                int h = image.getHeight(null) * zoomLevel;
                setSize(w, h);
                scimg = createImage(w, h);
                Graphics g = scimg.getGraphics();
                g.setColor(AnimationEditor.getBGColor());
                g.fillRect(0, 0, w, h);
                scimg.getGraphics().drawImage(image, 0, 0, scimg.getWidth(null), scimg.getHeight(null), 0, 0, image.getWidth(null), image.getHeight(null), null);
                bimg = createImage(image.getWidth(null) * zoomLevel, image.getHeight(null) * zoomLevel);
            }
        }

        void LP2DP(Point p)
        {
            p.x /= zoomLevel;
            p.y /= zoomLevel;
        }

        public void mouseClicked(MouseEvent e)
        {
        }

        public void mouseEntered(MouseEvent e)
        {
        }

        public void mouseExited(MouseEvent e)
        {
        }

        public void mousePressed(MouseEvent e)
        {
            Point p = e.getPoint();
            LP2DP(p);
            mouseStartPos = p;
            int id = itemFromPoint(p.x, p.y, curItem);
            if (id >= 0)
            {
                modList.select(id);
                curItem = id;
                mouseMode = 2;
            }
            else
            {
                if (p.x < imageWidth - 1 && p.y < imageHeight - 1)
                {
                    mouseMode = 1;
                    curItem = addModule(p.x, p.y, 1, 1);
                    modList.select(curItem);
                }
            }
            repaint();
        }

        public void mouseReleased(MouseEvent e)
        {
            mouseMode = 0;
            AniStudioFrm.instance.pushHistry();
        }

        public void mouseDragged(MouseEvent e)
        {
            Module mod;

            Point p = e.getPoint();
            LP2DP(p);
            if (mouseMode == 1)
            {
                p.x -= mouseStartPos.x;
                p.y -= mouseStartPos.y;
                if (p.x < 1)
                {
                    p.x = 1;
                }
                if (p.y < 1)
                {
                    p.y = 1;
                }
                mod = (Module)modules.elementAt(curItem);
                mod.w = p.x;
                if (mod.w + mod.x > imageWidth)
                {
                    mod.w = imageWidth - mod.x;
                }
                mod.h = p.y;
                if (mod.h + mod.y > imageHeight)
                {
                    mod.h = imageHeight - mod.y;
                }
                repaint();
            }
            else if (mouseMode == 2)
            {
                mod = (Module)modules.elementAt(curItem);
                if (e.isShiftDown())
                {
                    mod.w += p.x - mouseStartPos.x;
                    mod.h += p.y - mouseStartPos.y;
                    if (mod.w < 1)
                    {
                        mod.w = 1;
                    }
                    if (mod.h < 1)
                    {
                        mod.h = 1;
                    }
                    if (mod.w + mod.x > imageWidth)
                    {
                        mod.w = imageWidth - mod.x;
                    }
                    if (mod.h + mod.y > imageHeight)
                    {
                        mod.h = imageHeight - mod.y;
                    }
                }
                else
                {
                    mod.x += p.x - mouseStartPos.x;
                    mod.y += p.y - mouseStartPos.y;
                    if (mod.x < 0)
                    {
                        mod.x = 0;
                    }
                    if (mod.y < 0)
                    {
                        mod.y = 0;
                    }
                    if (mod.x + mod.w > image.getWidth(null))
                    {
                        mod.x = image.getWidth(null) - mod.w;
                    }
                    if (mod.y + mod.h > image.getHeight(null))
                    {
                        mod.y = image.getHeight(null) - mod.h;
                    }
                }
                mouseStartPos = p;
                repaint();
            }
        }

        public void mouseMoved(MouseEvent e)
        {
            Point p = e.getPoint();
            LP2DP(p);
            mouseStartPos = p;
            repaint();
        }

        public void keyPressed(KeyEvent e)
        {
            if (e.getKeyCode() == KeyEvent.VK_Z)
            {
                if (e.getModifiers() == InputEvent.CTRL_MASK)
                {
                    undo();
                }
                else if (e.getModifiers() == (InputEvent.CTRL_MASK | InputEvent.SHIFT_MASK))
                {
                    redo();
                }
                return;
            }

            if (e.getKeyCode() == KeyEvent.VK_DELETE)
            {
                removeModule();
                return;
            }

            int[] ids = modList.getSelectedIndexes();
            for (int i = ids.length - 1; i >= 0; i--)
            {
                Module mod = (Module)modules.elementAt(ids[i]);
                if (mod.idImage != anim.getCurImage())
                    continue;
                switch (e.getKeyCode())
                {
                case KeyEvent.VK_LEFT:
                    mod.x--;
                    break;
                case KeyEvent.VK_RIGHT:
                    mod.x++;
                    break;
                case KeyEvent.VK_UP:
                    mod.y--;
                    break;
                case KeyEvent.VK_DOWN:
                    mod.y++;
                    break;
                }
            }
            repaint();
        }

        public void keyReleased(KeyEvent e)
        {
            AniStudioFrm.instance.pushHistry();
        }

        public void keyTyped(KeyEvent e)
        {
        }
    }

    public ModuleDlg(Frame owner, Animation _anim, Image img)
    {
        super(owner, "Module Window", true);
        ownerFrame = owner;
        anim = _anim;
        modules = _anim.modules;
        image = img;
        imageWidth = image.getWidth(null);
        imageHeight = image.getHeight(null);

        setSize(800, 600);

        centerOnParent(owner);

        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        setLayout(gridbag);

        Panel leftPanel = new Panel(new BorderLayout());
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        gridbag.setConstraints(leftPanel, c);
        add(leftPanel);
        Panel bpan = new Panel(new GridLayout(2, 2));
        leftPanel.add(bpan, "South");
        Button btn = new Button("Zoom In");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Zoom Out");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Remove");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("OK");
        btn.addActionListener(this);
        bpan.add(btn);

        modList = new java.awt.List(34);
        modList.addItemListener(this);
        leftPanel.add(modList, "Center");
        imgCanvas = new ImgCanvas();
        ScrollPane rightPanel = new ScrollPane();
        rightPanel.setSize(400, 400);
        c.gridwidth = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(rightPanel, c);
        add(rightPanel);
        rightPanel.add(imgCanvas);

        checkValidity();

        refreshList();

        AniStudioFrm.instance.clearHistry();
        AniStudioFrm.instance.pushHistry();
    }

    private void checkValidity()
    {
        int i, w, h;
        Module mod;

        w = image.getWidth(null);
        h = image.getHeight(null);
        for (i = modules.size() - 1; i >= 0; i--)
        {
            mod = (Module)modules.get(i);
            if (mod.idImage != anim.getCurImage())
                continue;
            if (mod.x < 0 || mod.x >= w)
            {
                System.out.println("Warning: Module " + i + "'s x=" + mod.x + " -> out of bound");
                if (mod.x >= w)
                {
                    mod.x = w - mod.w;
                }
                if (mod.x < 0)
                {
                    mod.x = 0;
                }
            }
            if (mod.y < 0 || mod.y >= h)
            {
                System.out.println("Warning: Module " + i + "'s y=" + mod.y + " -> out of bound");
                if (mod.y >= h)
                {
                    mod.y = h - mod.h;
                }
                if (mod.y < 0)
                {
                    mod.y = 0;
                }
            }
            if (mod.w <= 0 || mod.x + mod.w > w)
            {
                System.out.println("Warning: Module " + i + "'s width=" + mod.w + " -> out of bound");
                if (mod.x + mod.w > w)
                {
                    mod.x = w - mod.w;
                    if (mod.x < 0)
                    {
                        mod.x = 0;
                        mod.w = w;
                    }
                }
                if (mod.w <= 0)
                {
                    mod.w = 1;
                }
            }
            if (mod.h <= 0 || mod.y + mod.h > h)
            {
                System.out.println("Warning: Module " + i + "'s height=" + mod.h + " -> out of bound");
                if (mod.y + mod.h > h)
                {
                    mod.y = h - mod.h;
                    if (mod.y < 0)
                    {
                        mod.y = 0;
                        mod.h = h;
                    }
                }
                if (mod.h <= 0)
                {
                    mod.h = 1;
                }
            }
        }
    }

    private void centerOnParent(Component comp)
    {
        setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2,
                    comp.getLocation().y + (comp.getSize().height - getSize().height) / 2);
    }

    public void actionPerformed(ActionEvent e)
    {
        String s = e.getActionCommand();
        if (s == "Zoom In")
        {
            imgCanvas.zoomIn();
        }
        else if (s == "Zoom Out")
        {
            imgCanvas.zoomOut();
        }
        else if (s == "Remove")
        {
            removeModule();
        }
        else if (s == "OK")
        {

            dispose();
            AniStudioFrm.instance.refreshFrameList();
        }
    }

    private void removeModule()
    {
        moduleSelId = modList.getSelectedIndex();
        if (moduleSelId >= 0 && ((Module)modules.elementAt(moduleSelId)).idImage == anim.getCurImage())
        {
            if (anim.isModuleUsed(moduleSelId, "Module "+moduleSelId+" is used by"))
            {
                MsgBox box = new MsgBox((Frame)getParent(), "Error", anim.strError);
                box.show();
            }
            else
            {
                anim.removeModule(moduleSelId);
                refreshList();
                imgCanvas.repaint();
            }
        }
    }

    private void undo()
    {
        if (AniStudioFrm.instance.undoHistry())
        {
            anim = AniStudioFrm.instance.m_actor;
            modules = anim.modules;
            refreshList();
            imgCanvas.repaint();
        }
    }

    private void redo()
    {
        if (AniStudioFrm.instance.redoHistry())
        {
            anim = AniStudioFrm.instance.m_actor;
            modules = anim.modules;
            refreshList();
            imgCanvas.repaint();
        }
    }

    protected int addModule(int x, int y, int w, int h)
    {
        Module mod = new Module(x, y, w, h, anim.getCurImage());
        modules.addElement(mod);
        String name = "Module " + (modules.size() - 1);
        if (mod.flipX)
        {
            name += " (X)";
        }
        if (mod.flipY)
        {
            name += " (Y)";
        }
        name += " (active)";
        modList.add(name);
        return modules.size() - 1;
    }

    public void refreshList()
    {
        modList.removeAll();
        for (int i = 0; i < modules.size(); i++)
        {
            Module mod = (Module)modules.elementAt(i);
            String name = "Module " + i;
            if (mod.flipX)
            {
                name += " (X)";
            }
            if (mod.flipY)
            {
                name += " (Y)";
            }
            if (mod.idImage == anim.getCurImage())
            {
                name += " (active)";
            }
            modList.add(name);
        }
        modList.select(moduleSelId);
    }

    public void itemStateChanged(java.awt.event.ItemEvent itemEvent)
    {
        imgCanvas.repaint();
    }

    public int itemFromPoint(int x, int y, int prevId)
    {
        int i;
        Module mod;
        if (prevId >= modules.size()) prevId = -1;
        for (i = prevId+1; i < modules.size(); i++)
        {
            mod = (Module)modules.elementAt(i);
            if (x >= mod.x && x <= mod.x + mod.w && y >= mod.y && y <= mod.y + mod.h && mod.idImage == anim.getCurImage())
            {
                return i;
            }
        }
        for (i = 0; i <= prevId; i++)
        {
            mod = (Module)modules.elementAt(i);
            if (x >= mod.x && x <= mod.x + mod.w && y >= mod.y && y <= mod.y + mod.h && mod.idImage == anim.getCurImage())
            {
                return i;
            }
        }
        return -1;
    }
}