/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.screens;

import javax.microedition.lcdui.Graphics;

import com.motionwelder.animationdemo.MainCanvas;
import com.motionwelder.animationdemo.MainMidlet;
import com.motionwelder.animationdemo.ResourceLoader;
import com.motionwelder.animationdemo.utils.GenericImageTextRenderableScreen;
import com.motionwelder.animationdemo.utils.Key;

/**
 * Class MongoIntroScreen is used to show introduction screen of Mongo with game description
 */

public class MongoIntroScreen extends GenericImageTextRenderableScreen{

	public MongoIntroScreen(){
		// append string and image
		append("Mongo is a monkey of");
		append("African jungle, and is ready ");
		append("to fight with his predator.");
		append("We have tried to showcase");
		append("different animation of Mongo");
		append("like stance and run which");
		append("are designed from");
		append("Motion Welder.!!");
		append("");
		append("Mongo Animations are created");
		append("from clipped image shown");
		append("below.");
		append(ResourceLoader.loadImage("/mongo/character.png"));
		append("Motion Welder is easy to use,");
		append("and gives great flexibility to");
		append("design best animations.");
		append("");
		append("Click 'Next' to see mongo");
		append("in action...!!");
		calculateScreenHeight();
	}
	
	public void paint(Graphics g){
		super.paint(g);
		
		MainCanvas.drawCommands(g,"Next","Exit");
	}
	
	public void update(){
		super.update();
		
		if((MainCanvas.keyPressed&(Key.SOFT_R))!=0 ){
			MainMidlet.exitApp();
			return;
		}
		
		if((MainCanvas.keyPressed&(Key.SELECT|Key.NUM5|Key.SOFT_L))!=0 ){
			MainCanvas.switchScreen(new MongoGameScreen());
		}
	}
}
