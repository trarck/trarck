----------------------------------------------------------
    Motion Welder Library
----------------------------------------------------------

Motion Welder library is open source library used to load/play animation.
We request developer to understand it's flow, design properly before using it, since library is open source developer can integrate with his code.
Please use doc to understand API.
Also read readMeMustForNokia.txt to understand changes for Nokia.

If any queries, please write to support@motionwelder.com
or write to author Nitin Pokar at (pokar.nitin@gmail.com, nitin@motionwelder.com)