package gui;

import java.awt.Button;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

public class ScaleDlg extends Dialog implements ActionListener
{
	/** ���а汾ID */
	private static final long serialVersionUID = 8024830098766010941L;
	TextField fldPar;
	float fac;

	public ScaleDlg(Frame owner)
	{
		super(owner, "Scale Animation", true);
		setSize(300, 100);
		centerOnParent(owner);
		setLayout(new GridLayout(2, 2));
		add(new Label("Scale Factor"));
		fldPar = new TextField("1");
		add(fldPar);
		Button btn = new Button("OK");
		btn.addActionListener(this);
		add(btn);
		Button btn2 = new Button("Cancel");
		btn2.addActionListener(this);
		add(btn2);
		fac = 1.0f;
	}

	private void centerOnParent(Component comp)
	{
		setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2, comp.getLocation().y + (comp.getSize().height - getSize().height) / 2);
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getActionCommand() == "OK")
		{
			fac = Float.valueOf(fldPar.getText()).floatValue();
			dispose();
		}
		else if(e.getActionCommand() == "Cancel")
		{
			fac = 1.0f;
			dispose();
		}
	}
}