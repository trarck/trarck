package anim;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.sun.org.apache.xml.internal.serialize.LineSeparator;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

public class Animation
{
	//	public int type;
	int imageId;
	//	boolean hasMModule;
	int imgNum;
	public Vector/*String[]*/imageFile;
	int curImg;
	public Vector modules;
	public Vector frames;
	public Vector actions;
	public String strError;

	public Animation()
	{
		curImg = 0;
	}

	public static Animation Create()
	{
		Animation actor = new Animation();
		//actor.imageFile = new String();
		actor.modules = new Vector();
		actor.frames = new Vector();
		actor.actions = new Vector();
		return actor;
	}

	public int getImageNum()
	{
		return imgNum;
	}

	public int getCurImage()
	{
		return curImg;
	}

	public void setCurImage(int i)
	{
		curImg = i;
	}

	public String getImageFile(int i)
	{
		if (imageFile != null)
			return (String) imageFile.get(i);
		else
			return null;
	}

	public void setImageFile(String fn, int i)
	{
		//imageFile[i] = fn;
		if (imageFile == null)
		{
			imageFile = new Vector();
			imageFile.add(fn);
		} else
			imageFile.set(i, fn);
	}

	public void addImageFile(String fn)
	{
		if (imageFile == null)
			imageFile = new Vector();
		imageFile.add(fn);
		imgNum++;
	}

	public int isImageUsed(int id)
	{
		Module mod;
		for (int i = modules.size() - 1; i >= 0; i--)
		{
			mod = (Module) modules.elementAt(i);
			if (mod.idImage == id)
				return i;
		}
		return -1;
	}

	public void removeImageFile(int id)
	{
		int i;
		imgNum--;
		Module mod;
		for (i = modules.size() - 1; i >= 0; i--)
		{
			mod = (Module) modules.elementAt(i);
			if (mod.idImage > id)
				mod.idImage--;
		}
		imageFile.removeElementAt(id);
	}

	public void updateModuleFlip(Sprite spr)
	{
		if (modules != null && spr != null && spr.idModule < modules.size())
		{
			Module mod = (Module) modules.elementAt(spr.idModule);
			mod.flipX = spr.isFlipX();
			mod.flipY = spr.isFlipY();
		}
	}

	public boolean isModuleUsed(int id, String str)
	{
		int i, j;
		AniFrame frm;
		Sprite spt;
		boolean ret = false;
		for (i = frames.size() - 1; i >= 0; i--)
		{
			frm = (AniFrame) frames.elementAt(i);
			for (j = frm.sprites.size() - 1; j >= 0; j--)
			{
				spt = (Sprite) frm.sprites.elementAt(j);
				if (spt.idModule == id)
				{
					if (str != null)
					{
						str += "\nFrame " + i;
					}
					ret = true;
					break;
				}
			}
		}
		strError = str;
		return ret;
	}

	public void removeModule(int id)
	{
		int i, j;
		AniFrame frm;
		Sprite spt;
		for (i = frames.size() - 1; i >= 0; i--)
		{
			frm = (AniFrame) frames.elementAt(i);
			for (j = frm.sprites.size() - 1; j >= 0; j--)
			{
				spt = (Sprite) frm.sprites.elementAt(j);
				if (spt.idModule == id)
					return;
				else if (spt.idModule > id)
					spt.idModule--;
			}
		}
		modules.removeElementAt(id);
	}

	public AniFrame getFrame(int id)
	{
		if (id < 0 || id >= frames.size())
			return null;
		return (AniFrame) frames.elementAt(id);
	}

	public int getFrameCount()
	{
		if (frames == null)
			return 0;
		return frames.size();
	}

	public int isFrameUsed(int id)
	{
		int i, j;
		Action action;
		for (i = actions.size() - 1; i >= 0; i--)
		{
			action = (Action) actions.elementAt(i);
			for (j = action.frmIdTable.size() - 1; j >= 0; j--)
			{
				if (((Integer) action.frmIdTable.elementAt(j)).intValue() == id)
					return i;
			}
		}
		return -1;
	}

	public void insertFrame(int id, AniFrame frm)
	{
		int i, j;
		Action action;

		for (i = actions.size() - 1; i >= 0; i--)
		{
			action = (Action) actions.elementAt(i);
			for (j = action.frmIdTable.size() - 1; j >= 0; j--)
			{
				int fid = ((Integer) action.frmIdTable.elementAt(j)).intValue();
				if (fid >= id)
					action.frmIdTable.setElementAt(new Integer(fid + 1), j);
			}
		}
		frames.insertElementAt(frm, id);
	}

	public void moveFrameUp(int id)
	{
		int i, j;
		Action action;

		if (id <= 0)
			return;
		for (i = actions.size() - 1; i >= 0; i--)
		{
			action = (Action) actions.elementAt(i);
			for (j = action.frmIdTable.size() - 1; j >= 0; j--)
			{
				int fid = ((Integer) action.frmIdTable.elementAt(j)).intValue();
				if (fid == id)
					action.frmIdTable.setElementAt(new Integer(fid - 1), j);
				else if (fid == id - 1)
					action.frmIdTable.setElementAt(new Integer(id), j);
			}
		}
		Object frm = frames.elementAt(id);
		frames.setElementAt(frames.elementAt(id - 1), id);
		frames.setElementAt(frm, id - 1);
	}

	public void moveFrameDown(int id)
	{
		int i, j;
		Action action;

		if (id >= frames.size() - 1)
			return;
		for (i = actions.size() - 1; i >= 0; i--)
		{
			action = (Action) actions.elementAt(i);
			for (j = action.frmIdTable.size() - 1; j >= 0; j--)
			{
				int fid = ((Integer) action.frmIdTable.elementAt(j)).intValue();
				if (fid == id)
					action.frmIdTable.setElementAt(new Integer(fid + 1), j);
				else if (fid == id + 1)
					action.frmIdTable.setElementAt(new Integer(id), j);
			}
		}
		Object frm = frames.elementAt(id);
		frames.setElementAt(frames.elementAt(id + 1), id);
		frames.setElementAt(frm, id + 1);
	}

	public void addFrame(AniFrame frame)
	{
		frames.addElement(frame);
	}

	public void removeFrame(int id)
	{
		int i, j;
		Action action;

		for (i = actions.size() - 1; i >= 0; i--)
		{
			action = (Action) actions.elementAt(i);
			for (j = action.frmIdTable.size() - 1; j >= 0; j--)
			{
				int fid = ((Integer) action.frmIdTable.elementAt(j)).intValue();
				if (fid == id)
					return;
				else if (fid > id)
					action.frmIdTable.setElementAt(new Integer(fid - 1), j);
			}
		}
		frames.removeElementAt(id);
	}

	public boolean isActionNameExist(String name)
	{
		Action action;

		for (int i = actions.size() - 1; i >= 0; i--)
		{
			action = (Action) actions.elementAt(i);
			if (action.name.compareTo(name) == 0)
				return true;
		}
		return false;
	}

	public int getActionIdByName(String name)
	{
		Action action;

		for (int i = actions.size() - 1; i >= 0; i--)
		{
			action = (Action) actions.elementAt(i);
			if (action.name.compareTo(name) == 0)
				return i;
		}
		return -1;
	}

	public void removeAction(int id)
	{
		actions.removeElementAt(id);
	}

	/*
	 public void saveToAni(DataOutputStream os)
	 throws IOException
	 {
	 int i;
	 os.writeInt(type);
	 os.writeInt(imageId);
	 os.writeBoolean(hasMModule);
	 os.writeUTF(imageFile);
	 os.writeInt(modules.size());
	 for(i = 0; i < modules.size(); i++)
	 {
	 ((Module)modules.elementAt(i)).saveToAni(os);
	 }
	 os.writeInt(frames.size());
	 for(i = 0; i < frames.size(); i++)
	 {
	 ((AniFrame)frames.elementAt(i)).saveToAni(os);
	 }
	 os.writeInt(actions.size());
	 for(i = 0; i < actions.size(); i++)
	 {
	 ((Action)actions.elementAt(i)).saveToAni(os);
	 }
	 }
	 */
	/*
	 public void exportForBrew(DataOutputStream os)
	 throws IOException
	 {
	 int i;
	 os.writeByte(type);
	 os.writeByte(imageId);
	 os.writeByte(hasMModule?1:0);
	 AniStudio.myassert(modules.size() < 256, "Number of modules exceed 256!");
	 os.writeByte(modules.size());
	 os.writeByte(frames.size() & 0xff);
	 os.writeByte(frames.size() >> 8);
	 os.writeByte(actions.size() & 0xff);
	 os.writeByte(actions.size() >> 8);
	 for(i = 0; i < modules.size(); i++)
	 {
	 ((Module)modules.elementAt(i)).exportForBrew(os);
	 }
	 for(i = 0; i < frames.size(); i++)
	 {
	 ((AniFrame)frames.elementAt(i)).exportForBrew(os);
	 }
	 for(i = 0; i < actions.size(); i++)
	 {
	 ((Action)actions.elementAt(i)).exportForBrew(os);
	 }
	 }
	 */
	public void exportActionNames(String prefix, OutputStream os)
	{
		int i;
		String s;
		PrintWriter w = new PrintWriter(os);
		for (i = 0; i < actions.size(); i++)
		{
			s = prefix + "_" + ((Action) actions.elementAt(i)).name;
			//            s = s.toUpperCase();
			w.println("#define " + s + " " + i);
			//            w.println("#define " + s + "_L " + Integer.toString(i * 2));
			//           w.println("#define " + s + "_R " + Integer.toString(i * 2 + 1));
		}
		w.close();
	}

	public void LoadFromAni(DataInputStream is) throws IOException
	{
		int i, n;
		/*type = */is.readInt();
		imageId = is.readInt();
		/*hasMModule = */is.readBoolean();
		imageFile.set(0, is.readUTF());
		n = is.readInt();
		modules = new Vector(n);
		for (i = 0; i < n; i++)
			modules.addElement(Module.createFromAni(is));
		n = is.readInt();
		frames = new Vector(n);
		for (i = 0; i < n; i++)
			frames.addElement(AniFrame.createFromAni(is, this));
		n = is.readInt();
		actions = new Vector(n);
		for (i = 0; i < n; i++)
			actions.addElement(Action.createFromAni(this, is));
	}

	public void Scale(float f)
	{
		int i;

		for (i = 0; i < modules.size(); i++)
		{
			((Module) modules.elementAt(i)).Scale(f);
		}
		for (i = 0; i < frames.size(); i++)
		{
			((AniFrame) frames.elementAt(i)).Scale(f);
		}
		for (i = 0; i < actions.size(); i++)
		{
			((Action) actions.elementAt(i)).Scale(f);
		}
	}

	public void exportXML(OutputStream os) throws Exception
	{
		int i;
		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		document = builder.newDocument(); // Create from whole cloth
		Element e, root = (Element) document.createElement("Animation");
		document.appendChild(root);
		root.setAttribute("imgNum", Integer.toString(imgNum));
		for (i = 0; i < imgNum; i++)
			root.setAttribute("image" + Integer.toString(i + 1), (String) imageFile.get(i));
		root.setAttribute("version", "4");
		//		root.setAttribute("type", String.valueOf(type));
		e = document.createElement("Modules");
		root.appendChild(e);
		for (i = 0; i < modules.size(); i++)
		{
			((Module) modules.elementAt(i)).exportXML(document, e);
		}
		e = document.createElement("Frames");
		root.appendChild(e);
		for (i = 0; i < frames.size(); i++)
		{
			((AniFrame) frames.elementAt(i)).exportXML(document, e);
		}
		e = document.createElement("Actions");
		root.appendChild(e);
		for (i = 0; i < actions.size(); i++)
		{
			((Action) actions.elementAt(i)).exportXML(document, e);
		}
		OutputFormat format = new OutputFormat(document);
		format.setLineSeparator(LineSeparator.Windows);
		format.setIndenting(true);
		format.setIndent(4);
		format.setLineWidth(0);
		format.setPreserveSpace(false);
		XMLSerializer serializer = new XMLSerializer(os, format);
		serializer.asDOMSerializer();
		serializer.serialize(document);
	}

	public void importXML(InputStream is)
	{
		int i;
		NodeList nl;
		Document document = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try
		{
			DocumentBuilder builder = factory.newDocumentBuilder();
			document = builder.parse(is);
			Element e, root;
			root = document.getDocumentElement();
			if (root.getTagName().compareTo("Animation") != 0)
			{
				System.out.println("Not a animation file!");
				return;
			}
			String tmp = root.getAttribute("imgNum");
			if (tmp == "")
			{
				imgNum = 1;
				imageFile = new Vector(imgNum);
				imageFile.add(root.getAttribute("image"));
			} else
			{
				imgNum = Integer.parseInt(tmp);
				imageFile = new Vector(imgNum); //String[imgNum];
				for (i = 0; i < imgNum; i++)
					imageFile.add(root.getAttribute("image" + Integer.toString(i + 1)));
			}

			e = (Element) (root.getElementsByTagName("Modules").item(0));
			nl = e.getElementsByTagName("Module");
			modules = new Vector(nl.getLength());
			for (i = 0; i < nl.getLength(); i++)
			{
				modules.add(Module.fromXML((Element) nl.item(i)));
			}
			e = (Element) (root.getElementsByTagName("Frames").item(0));
			nl = e.getElementsByTagName("Frame");
			frames = new Vector(nl.getLength());
			for (i = 0; i < nl.getLength(); i++)
			{
				frames.add(AniFrame.fromXML((Element) nl.item(i), this));
			}
			e = (Element) (root.getElementsByTagName("Actions").item(0));
			nl = e.getElementsByTagName("Action");
			actions = new Vector(nl.getLength());
			for (i = 0; i < nl.getLength(); i++)
			{
				actions.add(Action.fromXML(this, (Element) nl.item(i)));
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public boolean isEqual(Animation dst)
	{
		int i;
		//		if(type != dst.type) return false;
		for (i = 0; i < imgNum; i++)
			if (((String) imageFile.get(i)).compareToIgnoreCase((String) dst.imageFile.get(i)) != 0)
				return false;
		if (modules.size() != dst.modules.size())
			return false;
		if (actions.size() != dst.actions.size())
			return false;
		if (frames.size() != dst.frames.size())
			return false;

		for (i = 0; i < modules.size(); i++)
		{
			if (!((Module) modules.get(i)).isEqual((Module) dst.modules.get(i)))
				return false;
		}

		for (i = 0; i < actions.size(); i++)
		{
			if (!((Action) actions.get(i)).isEqual((Action) dst.actions.get(i)))
				return false;
		}

		for (i = 0; i < frames.size(); i++)
		{
			if (!((AniFrame) frames.get(i)).isEqual((AniFrame) dst.frames.get(i)))
				return false;
		}

		return true;
	}

	public Animation Clone()
	{
		int i;
		Animation a = new Animation();
		//		a.type = type;
		//		a.hasMModule = hasMModule;
		a.curImg = curImg;
		a.imageId = imageId;
		a.imgNum = imgNum;
		a.imageFile = new Vector(imgNum);//String[imgNum];
		for (i = 0; i < imgNum; i++)
			a.imageFile.add((String) imageFile.get(i));
		a.actions = new Vector();
		for (i = 0; i < actions.size(); i++)
		{
			a.actions.add(((Action) actions.get(i)).clone());
		}
		a.frames = new Vector();
		for (i = 0; i < frames.size(); i++)
		{
			a.frames.add(((AniFrame) frames.get(i)).clone());
		}
		a.modules = new Vector();
		for (i = 0; i < modules.size(); i++)
		{
			a.modules.add(((Module) modules.get(i)).clone());
		}
		return a;
	}

	public int getActionCount()
	{
		return actions.size();
	}

	public Action getAction(int id)
	{
		if (id < 0 || id >= actions.size())
			return null;
		return (Action) actions.get(id);
	}

	public String getActionName(int id)
	{
		if (id < 0 || id >= actions.size())
			return "" + id;
		return ((Action) actions.get(id)).name;
	}
}