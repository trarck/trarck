---------------------------------------------------------------------------------------
-  Motion Welder Library for Nokia | Changes For Nokia Direct Graphics  -
---------------------------------------------------------------------------------------
Motion Welder library is used to play/load animation, In library we have tried to explain general case, where runtime flipping is not available
Few Modification need to be made for Nokia Device, infact without making any modification also it wil work fine.
But few changes can save lot of heap, as DirectGraphics provide utility to flip image at runtime.
Here are the changes that need to be made.
1. While loading Image for ANU using (loadImage() and loadImageClips()) please don't load flipped image. Just load image[0] and set image[1], image[2] to null;
For Reference, image[] is used to store images for animation.
image[0] = NO_ORIENTATION
image[1] = H_FLIP_ORIENTATION
image[2] = V_FLIP_ORIENTATION

2. Since now we have made changes in loadImage(), loadImageClip() we need to handle it while drawing it.
To use Nokia Version check MPLayer.java, we have provided a code for drawImageClip() for Nokia.

To know more about this please feel free to write to support(support@motionwelder.com)
Or to Nitin Pokar (pokar.nitin@gmail.com, nitin@motionwelder.com)