#ifndef FNN_PERCEPTRON_H
#define FNN_PERCEPTRON_H

#include "freeNN/neuron.h"

#ifdef __cplusplus
extern "C" {
#endif

static const char *PERCEPTRON_STR_START = "_perceptron_start_";
static const char *PERCEPTRON_STR_END = "_perceptron_end_";

typedef struct Perceptron {
	Neuron *neuron_;
	double trainingRate_;
} Perceptron;

// Public
Perceptron *Perceptron_new(unsigned numOfInputs, double trainingRate);
Perceptron *Perceptron_new_from_string(const char *perceptronStr);
void Perceptron_destroy(Perceptron *perceptron);
double Perceptron_getValue(const Perceptron *perceptron, const double inputs[]);
void Perceptron_setTrainingRate(Perceptron *perceptron, double trainingRate);
void Perceptron_train(Perceptron *perceptron, const double inputs[], int expectedResult);
double Perceptron_getResult(const Perceptron *perceptron, const double inputs[]);
double Perceptron_getWeightAt(const Perceptron *perceptron, unsigned index);
const double *Perceptron_getWeights(const Perceptron *perceptron);
unsigned Perceptron_getNumOfInputs(const Perceptron *perceptron);
double Perceptron_getThreshold(const Perceptron *perceptron);
double Perceptron_getTrainingRate(const Perceptron *perceptron);
void Perceptron_setWeightAt(Perceptron *perceptron, unsigned index, double weight);
void Perceptron_setWeights(Perceptron *perceptron, const double *weights);
void Perceptron_setThreshold(Perceptron *perceptron, double threshold);
char *Perceptron_toString(const Perceptron *perceptron);

// Private
void _Perceptron_changeWeights(Perceptron *perceptron, double actualResult, double desiredResult, const double inputs[]);


#ifdef __cplusplus
}
#endif

#endif

