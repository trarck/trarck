package gui;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;

public class FrameTimeDlg  extends Dialog implements ActionListener, AdjustmentListener
{
	Scrollbar bar;
	Label lbTime;
	int val;

	public FrameTimeDlg(Frame owner, int initValue)
	{
		super(owner, "Frame Delay", true);
		setLayout(null);
		setSize(280, 160);
		centerOnParent(owner);

		val = initValue;

		lbTime = new Label("Delay (ms): " + val);
		lbTime.setSize(240, 24);
		lbTime.setLocation(12, 28);
		add(lbTime);
		bar = new Scrollbar(Scrollbar.HORIZONTAL, val, 24, 30, 224);
		bar.setLocation(12, 56);
		bar.setSize(240, 24);
		bar.addAdjustmentListener(this);
		add(bar);

		Button btn = new Button("OK");
		btn.setSize(64, 28);
		btn.setLocation(100, 100);
		btn.addActionListener(this);
		add(btn);
	}

	private void centerOnParent(Component comp)
	{
		setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2, comp.getLocation().y + (comp.getSize().height - getSize().height) / 2);
	}

	public void actionPerformed(java.awt.event.ActionEvent actionEvent)
	{
		dispose();
	}

	public void adjustmentValueChanged(java.awt.event.AdjustmentEvent adjustmentEvent)
	{
		val = bar.getValue();
		lbTime.setText("Delay (ms): " + val);
	}

}
