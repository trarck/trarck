package anim;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.io.*;
import org.w3c.dom.*;

public class MechModule {
	public final static int FRAC = 256;
	public int flag;
	public int[] par = new int[4];
	public MechModule() {
	}

	public Object clone()
	{
		MechModule m = new MechModule();
		m.flag = flag;
		m.par = (int[])par.clone();
		return m;
	}

	public void saveToAni(DataOutputStream os)
		throws IOException
	{
		os.writeInt(flag);
		for(int i = 0; i < par.length; i++)
			os.writeInt(par[i]);
	}

	public void exportXML(Document document, Element parent)
	{
		Element e = document.createElement("MechModel");
		parent.appendChild(e);
		e.setAttribute("flag", String.valueOf(flag));
		e.setAttribute("vx", String.valueOf(par[0]));
		e.setAttribute("vy", String.valueOf(par[1]));
		e.setAttribute("ax", String.valueOf(par[2]));
		e.setAttribute("ay", String.valueOf(par[3]));
	}

	public static MechModule fromXML(Element e)
	{
		MechModule mmodule = new MechModule();
		mmodule.flag = Integer.parseInt(e.getAttribute("flag"));
		mmodule.par[0] = Integer.parseInt(e.getAttribute("vx"));
		mmodule.par[1] = Integer.parseInt(e.getAttribute("vy"));
		mmodule.par[2] = Integer.parseInt(e.getAttribute("ax"));
		mmodule.par[3] = Integer.parseInt(e.getAttribute("ay"));
		return mmodule;
	}

	public void exportForBrew(DataOutputStream os)
		throws IOException
	{
/*		os.writeByte(type & 0xff);
		os.writeByte(type >> 8);
//        os.writeByte(parLen[type]);
		for(int i = 0; i < parLen[type] / 2; i++)
		{
			os.writeByte(par[i] & 0xff);
			os.writeByte(par[i] >> 8);
		}*/
	}

	public static MechModule createFromAni(DataInputStream is)
		throws IOException
	{
		int i;
		int data[] = new int[8];

		MechModule mmodule = new MechModule();
		for(i = 0; i < 8; i++)
		{
			data[i] = is.readInt();
		}
		switch(data[0])
		{
			case 0://NULL
				mmodule.flag = 15;
				break;
			case 3://Move
				mmodule.flag = 3;
				mmodule.par[0] = data[2];
				mmodule.par[1] = data[3];
				break;
			case 4://MoveX
				mmodule.flag = 3;
				mmodule.par[0] = data[2];
				break;
			case 5://MoveY
				mmodule.flag = 3;
				mmodule.par[1] = data[2];
				break;
			case 6://MoveXFreeY
				mmodule.flag = 1;
				mmodule.par[0] = data[2];
				break;
			case 7://MoveYFreeX
				mmodule.flag = 2;
				mmodule.par[1] = data[2];
				break;
			case 8://ModifySpeed
				mmodule.flag = 12;
				mmodule.par[2] = data[3];
				mmodule.par[3] = data[5];
				break;
			case 9://ModifySpeedX
				mmodule.flag = 4;
				mmodule.par[2] = data[3];
				break;
			case 10://ModifySpeedY
				mmodule.flag = 8;
				mmodule.par[3] = data[3];
				break;
			case 11://Impulse
				mmodule.flag = 15;
				mmodule.par[0] = data[2];
				mmodule.par[1] = data[3];
				mmodule.par[2] = data[5];
				mmodule.par[3] = data[7];
				break;
			case 12://ImpulseX
				mmodule.flag = 5;
				mmodule.par[0] = data[2];
				mmodule.par[2] = data[4];
				break;
			case 13://ImpulseY
				mmodule.flag = 10;
				mmodule.par[1] = data[2];
				mmodule.par[3] = data[4];
				break;
		}
		return mmodule;
	}

	public void Scale(float f)
	{
		par[0] *= f;
		par[1] *= f;
		par[2] *= f * f;
		par[3] *= f * f;
	}

	boolean isEqual(MechModule dst)
	{
		return dst.flag == flag && dst.par[0] == par[0] && dst.par[1] == par[1]
				 && dst.par[2] == par[2] && dst.par[3] == par[3];
	}
}