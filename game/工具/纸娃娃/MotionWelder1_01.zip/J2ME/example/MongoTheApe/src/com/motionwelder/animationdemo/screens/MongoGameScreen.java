/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.screens;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.motionwelder.animationdemo.MainCanvas;
import com.motionwelder.animationdemo.MainMidlet;
import com.motionwelder.animationdemo.ResourceLoader;
import com.motionwelder.animationdemo.components.GameCharacter;
import com.motionwelder.animationdemo.components.Pickable;
import com.motionwelder.animationdemo.utils.Key;
import com.motionwelder.animationdemo.utils.Screen;
import com.studio.motionwelder.MSpriteData;
import com.studio.motionwelder.MSpriteLoader;

public class MongoGameScreen implements Screen{
	
	/** game dimenstion */
	public static int gameWidth  = 4000;
	public static int gameHeight = 208;
	
	/** Camera Position */
	public static int cameraX = 0;
	public static int cameraY = 0;
	static int cameraWidth = 176; 
	
	/** Background Images*/
	private Image bg1Image,bg2Image;
	
	/** Mongo Animation Data for: MONGO, BANANA */
	private MSpriteData characterData;
	
	/** Mongo Object */
	private GameCharacter gameCharacter;
	
	/** Pickables */
	public Pickable[] pickables;
	
	/** Constructor */
	public MongoGameScreen(){
		try {
			loadResource();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void paint(Graphics g){
		// paint game screen
		// bg1
		int xpos = -(cameraX%bg1Image.getWidth());
		g.drawImage(bg1Image,xpos,0,20);
		if(xpos+bg1Image.getWidth()<cameraWidth){
			g.drawImage(bg1Image,xpos+bg1Image.getWidth(),0,20);
		}
		
		xpos = -((cameraX)%bg2Image.getWidth());
		int ypos = gameHeight-bg2Image.getHeight();
		g.drawImage(bg2Image,xpos,ypos,20);
		if(xpos+bg2Image.getWidth()<cameraWidth){
			g.drawImage(bg2Image,xpos+bg2Image.getWidth(),ypos,20);
		}

		gameCharacter.paint(g);
		
		// check if pickable is colliding
		for(int i=0;i<pickables.length;i++){
			if(pickables[i].getX()<cameraX) continue;
			if(pickables[i].getX()>cameraX+cameraWidth) break;
			
			if(!pickables[i].isExploded()){
				if(!pickables[i].isExploding()){
					int noOfRect = gameCharacter.player.getNumberOfCollisionRect();
					for(int j=0;j<noOfRect;j++){
						int[] rect = gameCharacter.player.getCollisionRect(j);
						
						// rect will return values based on axis.. change it 
						rect[0] += gameCharacter.getSpriteX();
						rect[1] += gameCharacter.getSpriteY();
						
						if(collide(rect,pickables[i].getX(),pickables[i].getY())){
							pickables[i].explode();
						}
					}
				}
				
				pickables[i].paint(g);
			}
		}
	}
	
	/** Update function of Game*/
	public void update(){
		// handle key events 
		if((MainCanvas.keyPressed&(Key.SOFT_R))!=0 ){
			MainMidlet.exitApp();
			return;
		}
		
		// update game character
		gameCharacter.update();
		
		// modifying camera position, and adjusting it so the movement is better and smooth
		int leftThreshold = 50;
		int rightThreshold = 126;
		if(gameCharacter.direction==GameCharacter.DIR_RIGHT&&gameCharacter.getSpriteDrawX()>leftThreshold){
			int increment = gameCharacter.getSpriteDrawX()-leftThreshold;
			if(increment>0){
				if(increment>15)
					increment=15;
				
				cameraX+=increment;

			}
		} else if(gameCharacter.direction==GameCharacter.DIR_LEFT&&gameCharacter.getSpriteDrawX()<rightThreshold){
			int decrement = rightThreshold-gameCharacter.getSpriteDrawX();
			if(decrement>0){
				if(decrement>15)
					decrement=15;

				
				cameraX-=decrement;
			}			
		}
		
		// checking out bonds of camera
		if(cameraX<0) cameraX=0;
		if(cameraX>gameWidth-cameraWidth) cameraX=gameWidth-cameraWidth;
		
	}
	
	/** Load resource */
	private void loadResource() throws Exception{
		// loading character's mongo.anu data
		characterData = MSpriteLoader.loadMSprite("/mongo/mongo.anu",true,ResourceLoader.getInstance());
		
		// loading background images
		bg1Image = ResourceLoader.loadImage("/mongo/bg1.png");
		bg2Image = ResourceLoader.loadImage("/mongo/bg2.png");
		
		// initializing Game Character Mongo Object
		gameCharacter = new GameCharacter(characterData);
		
		
		// initializing position of pickables
		short[] pickablesPos = new short[]{80,200,350,415,500,600,675,810,900,990,1080,1200,1350,1415,1500,1600,1675,1810,1900,1990,2080,2200,2350,2415,2500,2600,2675,2810,2900,2990,3080,3200,3350,3415,3500,3600,3675,3810,3900,3990};
		pickables = new Pickable[pickablesPos.length];
		for(int i=0;i<pickablesPos.length;i++){
			// creating object for each pickable
			pickables[i] = new Pickable(characterData,pickablesPos[i]);
		}
	}

	/** Function to check collision detection between two rectangles */
	private boolean collide(int[] rect,int x,int y){
		if(x > rect[0]+rect[2]) return false;
		if(y > rect[1]+rect[3]) return false;
		
		if(x < rect[0]) return false;
		if(y < rect[1]) return false;
		
		return true;
	}
}
