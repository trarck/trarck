#ifndef UIKIT2_KB_THREAD_H
#define UIKIT2_KB_THREAD_H

namespace KB {
	void kb_set_thread_priority(int curThreadPriority);
};

#endif