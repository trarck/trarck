import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

////////////////////////////////////////////////////////////////////////////////////////////////////

class LSprite {

	final static byte FLAG_FLIP_X = 0x01;
	final static byte FLAG_FLIP_Y = 0x02;
	
	// Modules...
	int _nModules; // number of modules
	byte[] _modules_x; // x for each module 
	byte[] _modules_y; // y for each module 
	byte[] _modules_w; // width for each module
	byte[] _modules_h; // height for each module

	// Frames...
	byte[] _frames_nfm; // number of FModules 
	short[] _frames_fm_start; // index of the first FModule

	// FModules...
	byte[] _fmodules_id; // module/hyper frame index
	short[] _fmodules_ox; // fmodule ox
	short[] _fmodules_oy; // fmodule oy
	byte[] _fmodules_flags; // fmodule flags

	// Anims...
	byte[] _anims_naf; // number of AFrames 
	short[] _anims_af_start; // index of the first AFrame

	// AFrames...
	byte[] _aframes_frame; // frame index
	byte[] _aframes_time; // aframe time
	short[] _aframes_ox; // aframe ox
	short[] _aframes_oy; // aframe oy

	Image _modules_image; 

	LSprite() {
	}
	
	
	void Load(byte[] file, int offset) {
		try {
			System.gc();

			// Modules...
			_nModules = ((file[offset++] & 0xFF) << 8)
					+ ((file[offset++] & 0xFF));
			if (_nModules > 0) {
				
				_modules_x = new byte[_nModules];
				_modules_y = new byte[_nModules];
				_modules_w = new byte[_nModules];
				_modules_h = new byte[_nModules];
				for (int i = 0; i < _nModules; i++) {
					_modules_x[i] = (byte) (file[offset++] & 0xFF);
					_modules_y[i] = (byte) (file[offset++] & 0xFF);
					_modules_w[i] = (byte) (file[offset++] & 0xFF);
					_modules_h[i] = (byte) (file[offset++] & 0xFF);
				}
			}

			// ////////////////////////////
			// Frames...

			int nFrames = ((file[offset++] & 0xFF) << 8)
					+ (file[offset++] & 0xFF);

			if (nFrames > 0) {
				_frames_nfm = new byte[nFrames];
				_frames_fm_start = new short[nFrames];
				for (int i = 0; i < nFrames; i++) {
					_frames_nfm[i] = file[offset++];
					_frames_fm_start[i] = (short) (((file[offset++] & 0xFF) << 8) + (file[offset++] & 0xFF));
				}
			}

			// ////////////////////////////
			// FModules...

			int nFModules = ((file[offset++] & 0xFF) << 8)
					+ ((file[offset++] & 0xFF));

			if (nFModules > 0) {
				_fmodules_id = new byte[nFModules];
				_fmodules_ox = new short[nFModules];
				_fmodules_oy = new short[nFModules];
				_fmodules_flags = new byte[nFModules];

				for (int i = 0; i < nFModules; i++) {
					_fmodules_id[i] = file[offset++];
					_fmodules_ox[i] = (short) (((file[offset++] & 0xFF) << 8) + (file[offset++] & 0xFF));
					_fmodules_oy[i] = (short) (((file[offset++] & 0xFF) << 8) + (file[offset++] & 0xFF));
					_fmodules_flags[i] = file[offset++];
				}
			}

			// ////////////////////////////
			// Anims...

			int nAnims = ((file[offset++] & 0xFF) << 8)
					+ (file[offset++] & 0xFF);

			if (nAnims > 0) {
				_anims_naf = new byte[nAnims];
				_anims_af_start = new short[nAnims];
				for (int i = 0; i < nAnims; i++) {
					_anims_naf[i] = file[offset++];
					_anims_af_start[i] = (short) (((file[offset++] & 0xFF) << 8) + (file[offset++] & 0xFF));
				}
			}

			// ////////////////////////////
			// AFrames...

			int nAFrames = ((file[offset++] & 0xFF) << 8)
					+ (file[offset++] & 0xFF);

			if (nAFrames > 0) {
				_aframes_frame = new byte[nAFrames];
				_aframes_time = new byte[nAFrames];
				_aframes_ox = new short[nAFrames];
				_aframes_oy = new short[nAFrames];

				for (int i = 0; i < nAFrames; i++) {
					_aframes_frame[i] = file[offset++];
					_aframes_time[i] = file[offset++];
					_aframes_ox[i] = (short) (((file[offset++] & 0xFF) << 8) + (file[offset++] & 0xFF));
					_aframes_oy[i] = (short) (((file[offset++] & 0xFF) << 8) + (file[offset++] & 0xFF));
				}
			}

			{
				int off = offset;
				int size = (((file[offset++] & 0xFF) << 8) + (file[offset++] & 0xFF)) & 0xFFFF;
				byte[] buffer = new byte[size];
				// is.read(buffer);
				System.arraycopy(file, offset, buffer, 0, size);
				_modules_image = Image.createImage(buffer, 0, buffer.length);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void FreeSprite() {

		_modules_x = null;
		_modules_y = null;

		_modules_w = null;
		_modules_h = null;

		// Frames...
		_frames_nfm = null;
		_frames_fm_start = null;
		// FModules...
		_fmodules_id = null;
		_fmodules_ox = null;
		_fmodules_oy = null;
		_fmodules_flags = null;

		// Anims...
		_anims_naf = null;
		_anims_af_start = null;
		// AFrames...
		_aframes_frame = null;
		_aframes_time = null;
		_aframes_ox = null;
		_aframes_oy = null;

	}

	// //////////////////////////////////////////////////////////////////////////////////////////////////

	int GetAFrameTime(int anim, int aframe) {
		return _aframes_time[_anims_af_start[anim] + aframe] & 0xFF;
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////////

	int GetAFrames(int anim) {
		return _anims_naf[anim] & 0xFF;
	}

	private static Graphics _g;

	static void SetGraphics(Graphics g) {
		_g = g;
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintAFrame(int anim, int aframe, int posX, int posY, int flags) {
		int off = _anims_af_start[anim] + aframe;
		int frame = _aframes_frame[off] & 0xFF;

		if ((flags & FLAG_FLIP_X) != 0)
			posX -= _aframes_ox[off];
		else
			posX += _aframes_ox[off];
		if ((flags & FLAG_FLIP_Y) != 0)
			posY -= _aframes_oy[off];
		else
			posY += _aframes_oy[off];
		PaintFrame(frame, posX, posY, flags);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintFrame(int frame, int posX, int posY, int flags) {
		int nFModules = _frames_nfm[frame] & 0xFF;

		for (int fmodule = 0; fmodule < nFModules; fmodule++)
			PaintFModule(frame, fmodule, posX, posY, flags);
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintFModule(int frame, int fmodule, int posX, int posY, int flags) {
		int off = _frames_fm_start[frame] + fmodule;
		int fm_flags = _fmodules_flags[off] & 0xFF;
		int index = _fmodules_id[off] & 0xFF;

		if ((flags & FLAG_FLIP_X) != 0) {
			posX -= _fmodules_ox[off] + (_modules_w[index] & 0xFF);
		} else
			posX += _fmodules_ox[off];

		if ((flags & FLAG_FLIP_Y) != 0)
			posY -= _fmodules_oy[off] + (_modules_h[index] & 0xFF);
		else
			posY += _fmodules_oy[off];
		PaintModule(index, posX, posY, flags ^ (fm_flags & 0x0F));
	}

	final static int[] midp2_flags = { // R Y X
			javax.microedition.lcdui.game.Sprite.TRANS_NONE, // 0 0 0
			javax.microedition.lcdui.game.Sprite.TRANS_MIRROR, // 0 0 1
			javax.microedition.lcdui.game.Sprite.TRANS_MIRROR_ROT180, // 0 1 0
			javax.microedition.lcdui.game.Sprite.TRANS_ROT180, // 0 1 1
			javax.microedition.lcdui.game.Sprite.TRANS_ROT90, // 1 0 0
			javax.microedition.lcdui.game.Sprite.TRANS_MIRROR_ROT90, // 1 0 1
			javax.microedition.lcdui.game.Sprite.TRANS_MIRROR_ROT270, // 1 1 0
			javax.microedition.lcdui.game.Sprite.TRANS_ROT270, // 1 1 1
	};

	void PaintModule(int module, int posX, int posY, int flags) {
		int sizeX = _modules_w[module] & 0xFF;
		int sizeY = _modules_h[module] & 0xFF;
		if (sizeX <= 0 || sizeY <= 0)
			return;

		int cx = _g.getClipX();
		int cy = _g.getClipY();
		int cw = _g.getClipWidth();
		int ch = _g.getClipHeight();

		if (posX + sizeX < cx || posY + sizeY < cy || posX >= cx + cw
				|| posY >= cy + ch) {
			return;
		}
		Image img = _modules_image;
		if (img == null) {
			return;
		}

		int x = 0;
		int y = 0;
		x = _modules_x[module] & 0xFF;
		y = _modules_y[module] & 0xFF;
		_g.drawRegion(img, x, y, sizeX, sizeY, midp2_flags[flags & 0x07],
				posX, posY, 0);
	}

}

// //////////////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////////////
