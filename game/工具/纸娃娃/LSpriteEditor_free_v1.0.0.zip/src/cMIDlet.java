import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class cMIDlet extends MIDlet {

	static cGame m_cGameInstance;
	static cMIDlet m_midletInstance;
	static Display m_display;

    public cMIDlet() {
        m_midletInstance = this;
        m_display = Display.getDisplay(this);
        m_cGameInstance = new cGame();
    }

    protected void startApp(){
        Display.getDisplay(this).setCurrent(m_cGameInstance);
    }

    protected void pauseApp() {
    	notifyPaused();
    }

    protected void destroyApp(boolean arg0){
        Display.getDisplay(this).setCurrent(null);
        notifyDestroyed();
        m_cGameInstance = null;
    }
    
    public static void quitApp() {
    	m_midletInstance.destroyApp(true);
    	m_midletInstance.notifyDestroyed();
    	m_midletInstance = null;
    }
}
