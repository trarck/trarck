package gui;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;

public class ColorDlg extends Dialog implements ActionListener, ItemListener, AdjustmentListener
{
	Color color;
	Scrollbar rBar, gBar, bBar;
	Label lbRed, lbGreen, lbBlue, lbSample;

	public ColorDlg(Frame owner, Color _color)
	{
		super(owner, "Choose Color", true);
		color = _color;
		setLayout(null);
		setSize(400, 220);
		centerOnParent(owner);

		lbRed = new Label("Red: " + Integer.toString(color.getRed()));
		lbRed.setSize(240, 24);
		lbRed.setLocation(12, 28);
		add(lbRed);
		rBar = new Scrollbar(Scrollbar.HORIZONTAL, color.getRed(), 24, 0, 279);
		rBar.setLocation(12, 56);
		rBar.setSize(240, 24);
		rBar.addAdjustmentListener(this);
		add(rBar);

		lbGreen = new Label("Green: " + Integer.toString(color.getGreen()));
		lbGreen.setSize(240, 24);
		lbGreen.setLocation(12, 86);
		add(lbGreen);
		gBar = new Scrollbar(Scrollbar.HORIZONTAL, color.getGreen(), 24, 0, 279);
		gBar.setLocation(12, 112);
		gBar.setSize(240, 24);
		gBar.addAdjustmentListener(this);
		add(gBar);

		lbBlue = new Label("Blue: " + Integer.toString(color.getBlue()));
		lbBlue.setSize(240, 24);
		lbBlue.setLocation(12, 148);
		add(lbBlue);
		bBar = new Scrollbar(Scrollbar.HORIZONTAL, color.getBlue(), 24, 0, 279);
		bBar.setLocation(12, 172);
		bBar.setSize(240, 24);
		bBar.addAdjustmentListener(this);
		add(bBar);

		lbSample = new Label(" ");
		lbSample.setSize(100, 100);
		lbSample.setLocation(280, 60);
		lbSample.setBackground(color);
		add(lbSample);

		Button btn = new Button("OK");
		btn.setSize(64, 28);
		btn.setLocation(320, 172);
		btn.addActionListener(this);
		add(btn);
	}

	private void centerOnParent(Component comp)
	{
		setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2, comp.getLocation().y + (comp.getSize().height - getSize().height) / 2);
	}

	public void actionPerformed(java.awt.event.ActionEvent actionEvent)
	{
		if(actionEvent.getActionCommand() == "OK")
		{
			dispose();
		}
	}

	public void itemStateChanged(java.awt.event.ItemEvent itemEvent)
	{
	}

	public void textValueChanged(java.awt.event.TextEvent textEvent)
	{
	}

	public void adjustmentValueChanged(java.awt.event.AdjustmentEvent adjustmentEvent)
	{
		if(adjustmentEvent.getSource() == rBar)
		{
			color = new Color(rBar.getValue(), color.getGreen(), color.getBlue());
			lbRed.setText("Red: " + Integer.toString(color.getRed()));
		}
		else if(adjustmentEvent.getSource() == gBar)
		{
			color = new Color(color.getRed(), gBar.getValue(), color.getBlue());
			lbGreen.setText("Green: " + Integer.toString(color.getGreen()));
		}
		else if(adjustmentEvent.getSource() == bBar)
		{
			color = new Color(color.getRed(), color.getGreen(), bBar.getValue());
			lbBlue.setText("Blue: " + Integer.toString(color.getBlue()));
		}
		lbSample.setBackground(color);
	}

}
