#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <stdio.h>

#include "freeNN/neuron.h"

#ifdef __cplusplus
extern "C" {
#endif

Neuron *Neuron_new(unsigned numOfInputs, int withBias, NeuronActivationFunction activationFunction) {
	unsigned i;
	static int initializedRandomization_ = 0;
	
	Neuron *neuron = (Neuron*)malloc(sizeof(Neuron));
	neuron->numInputs_ = numOfInputs;
	if (neuron->numInputs_ <= 0) {
		neuron->numInputs_ = 1;
	}
	neuron->weights_ = (double*)malloc(neuron->numInputs_ * sizeof(double));
	if (! initializedRandomization_) {
		srand(time(NULL));
		initializedRandomization_ = 1;
	}	
	for (i = 0 ; i < neuron->numInputs_ ; i++) {
		neuron->weights_[i] = _Neuron_getRandomDouble();
	}
	neuron->threshold_ = _Neuron_getRandomDouble();
	neuron->withBias_ = withBias;
	neuron->activationFunction_ = activationFunction;
	
	return neuron;	
}

Neuron *Neuron_new_from_string(const char *neuronStr) {
	char *buffer = (char*)malloc(NEURON_STR_READ_BUFFER_SIZE * sizeof(char));
	_Neuron_getValueFromString(neuronStr, "numInputs=", buffer);
	if (strcmp(buffer, "") == 0) {
		free(buffer);
		return NULL;
	}
	unsigned numInputs = atoi(buffer);	
	_Neuron_getValueFromString(neuronStr, "threshold=", buffer);
	if (strcmp(buffer, "") == 0) {
		free(buffer);
		return NULL;
	}
	double threshold = atof(buffer);
	_Neuron_getValueFromString(neuronStr, "withBias=", buffer);
	if (strcmp(buffer, "") == 0) {
		free(buffer);
		return NULL;
	}
	int withBias = atoi(buffer);
	_Neuron_getValueFromString(neuronStr, "activationFunction=", buffer);
	if (strcmp(buffer, "") == 0) {
		free(buffer);
		return NULL;
	}
	int activationFunction = atoi(buffer);
	_Neuron_getValueFromString(neuronStr, "weights=", buffer);
	if (strcmp(buffer, "") == 0) {
		free(buffer);
		return NULL;
	}
	double *weights = (double*)malloc(numInputs * sizeof(double));
	char weightsBuffer[64] = "";
	int i;
	char *valStart = buffer;
	for (i = 0 ; i < numInputs ; i++) {
		char *valEnd = strstr(valStart, ",");
		if (valEnd == NULL) {
			if (i < (numInputs - 1)) {
				printf("%d\n", i);
				free(weights);
				free(buffer);
				return NULL;
			}
			valEnd = valStart + strlen(valStart);
		}
		unsigned valLen = valEnd - valStart;
		memcpy(weightsBuffer, valStart, valLen);
		weights[i] = atof(weightsBuffer);
		valStart = valEnd + 1;
	}
	Neuron *n = Neuron_new(numInputs, withBias, activationFunction);
	memcpy(n->weights_, weights, numInputs * sizeof(double));
	n->threshold_ = threshold;
	free(weights);
	free(buffer);
	
	return n;
}

void Neuron_destroy(Neuron *neuron) {
	free(neuron->weights_);
	free(neuron);
}

double Neuron_getValue(const Neuron *neuron, const double inputs[]) {
	unsigned i;
	double ans = 0.0;
	
	for (i = 0 ; i < neuron->numInputs_ ; i++) {
		ans += neuron->weights_[i] * inputs[i];
	}	
	if (neuron->withBias_) {
		ans += neuron->threshold_;
	}
	return ans;
}

double Neuron_getResult(const Neuron *neuron, const double inputs[]) {
	double value = Neuron_getValue(neuron, inputs);
	if (neuron->activationFunction_ == STEP_FUNCTION) {
		return (value >= neuron->threshold_);
	} else if (neuron->activationFunction_ == SIGMOID) {
		return (1.0 / (1.0 + exp(-1.0 * value)));
	} else if (neuron->activationFunction_ == TANH) {
		return tanh(value);
	} else {
		return value;
	}
}

double Neuron_getWeightAt(const Neuron *neuron, unsigned index) {
	return neuron->weights_[index];
}

const double *Neuron_getWeights(const Neuron *neuron) {
	return neuron->weights_;
}

unsigned Neuron_getNumOfInputs(const Neuron *neuron) {
	return neuron->numInputs_;
}

double Neuron_getThreshold(const Neuron *neuron) {
	return neuron->threshold_;
}

void Neuron_setWeightAt(Neuron *neuron, unsigned index, double weight) {
	neuron->weights_[index] = weight;
}

void Neuron_setWeights(Neuron *neuron, const double *weights) {
	unsigned i;
	for (i = 0 ; i < neuron->numInputs_ ; i++) {
		neuron->weights_[i] = weights[i];
	}
}

void Neuron_setThreshold(Neuron *neuron, double threshold) {
	neuron->threshold_ = threshold;
}

char *Neuron_toString(const Neuron *neuron) {
	unsigned alloc_size = 0;
	unsigned used_size = 0;
	char *str = NULL;
	char buffer[NEURON_STR_BUFFER_SIZE] = "";
	unsigned i;

	_Neuron_appendToString(&str, NEURON_STR_START, &used_size, &alloc_size);
	sprintf(buffer, "\nnumInputs=%u\n", neuron->numInputs_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	_Neuron_appendToString(&str, "weights=", &used_size, &alloc_size);
	for (i = 0 ; i < neuron->numInputs_ ; i++) {
		sprintf(buffer, (i == neuron->numInputs_ - 1) ? "%f\n" : "%f,", neuron->weights_[i]);
		_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	}
	sprintf(buffer, "threshold=%f\n", neuron->threshold_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	sprintf(buffer, "withBias=%d\n", neuron->withBias_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	sprintf(buffer, "activationFunction=%d\n", (int)(neuron->activationFunction_));
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	_Neuron_appendToString(&str, NEURON_STR_END, &used_size, &alloc_size);

	return str;	
}

void _Neuron_appendToString(char **dest, const char *src, unsigned *used_size, unsigned *alloc_size) {
	int src_size = strlen(src);
	int remaining_mem = *alloc_size - *used_size - src_size - 1;
	if (remaining_mem < 0) {
		*dest = (char*)realloc(*dest, (*alloc_size + NEURON_STR_INC_SIZE) * sizeof(char));
		if (*alloc_size == 0) {
			strcpy(*dest, "");
		}
		*alloc_size += NEURON_STR_INC_SIZE;
	}
	strcat(*dest + *used_size, src);
	*used_size += src_size;
}

double _Neuron_getRandomDouble() {
	double randValue = ((double)rand() / (double)RAND_MAX);
	double negativeRand = ((double)rand() / (double)RAND_MAX);
	if (negativeRand < 0.5) {
		randValue *= -1.0;
	}
	return randValue;
}

void _Neuron_getValueFromString(const char *string, const char *prefix, char *buffer) {
	char *prefixStart = strstr(string, prefix);
	char *valueStart = prefixStart + strlen(prefix);
	char *valueEnd = strstr(valueStart, "\n");
	if (! (prefixStart && valueEnd)) {
		strcpy(buffer, "");
		return;
	}
	unsigned valueLen = valueEnd - valueStart;
	memcpy(buffer, valueStart, valueLen);
	buffer[valueLen] = '\0';
}


#ifdef __cplusplus
}
#endif

