/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.screens;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.motionwelder.animationdemo.MainCanvas;
import com.motionwelder.animationdemo.ResourceLoader;
import com.motionwelder.animationdemo.utils.Screen;
/**
 * class SplashScreen is used to show splash screen at start up 
 */
public class SplashScreen implements Screen{

	/** counter */
	int ctr;
	
	/** Logo Image */
	Image logoImage;
	
	/** Constructor */
	public SplashScreen(){
		// load logo images
		logoImage = ResourceLoader.loadImage("/logo.png");
	}
	
	/** Paint Function */
	public void paint(Graphics g){
		g.drawImage(logoImage,0,0,20);
		// if counter have crossed a time limit, switch it to Next screen.
		if(ctr>=15){
			MainCanvas.switchScreen(new MongoIntroScreen());
		}
	}
	
	/** Update Function */
	public void update(){
		// update time counter
		ctr++;
	}

}
