package com.motionwelder.fontdemo;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.studio.motionwelder.MCPLReader;

/**
 * 
 * Class CustomFont is used to render custom font, where alphabets are taken in image, and rendering is done with help of index.
 * .cpl file stores the coordinates of the alphabets
 *
 */
public class CustomFont {

	/** Store coordinates */
	private static short[][] cordinates;
	
	/** Font Image*/
	private static Image fontImage;
	
	/** Character Width and Height */
	private static int FONT_WIDTH = 7;
	private static int FONT_HEIGHT = 5;

	/** Alignment Constants */
	public static int ALIGN_CENTER = 0;
	public static int ALIGN_LEFT   = 1;
	public static int ALIGN_RIGHT   = 2;
	
	/** Load font.cpl when class is loaded */
	static{
		try{
			// this will return two dimensional array which represents coordinates. ([NO OF CHARACTERS][NO OF PARAMETERS]) 
			cordinates = MCPLReader.readCplFile("/font.cpl");
			fontImage = Image.createImage("/font.png");
		}catch (Exception e) {
		}
	}
	
	/** Draw String */
	public static void drawString(Graphics g,String str, int x,int y,int align){
		if(align==ALIGN_CENTER){
	  	   x = x -(getWidth(str)>>1);	
		} else if(align==ALIGN_RIGHT){
		   x = x -getWidth(str);
		}
		
		int clipX = g.getClipX();
		int clipY = g.getClipY();
		int clipW = g.getClipWidth();
		int clipH = g.getClipHeight();
		str = str.toLowerCase();
		for(int i=0;i<str.length();i++){
			char c = str.charAt(i);
			if(c>='a' && c <='z'){
				int index = (int)c-97;
				g.setClip(x,y,FONT_WIDTH,FONT_HEIGHT);
				g.drawImage(fontImage,x-cordinates[index][0],y-cordinates[index][1],20);
			} 
			x+=FONT_WIDTH+1;
		}
		
		g.setClip(clipX, clipY, clipW, clipH);
	}
	

	public static int getWidth(String str){
		return str.length()*FONT_WIDTH + (str.length()-1);
	}
}
