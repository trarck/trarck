import javax.microedition.lcdui.*;

class LSpriteInstance {
	int _posX; // position
	int _posY;
	int _flags; // flags

	LSprite _sprite;
	int _nCrtAnim; // = _nCrtModule (if _nCrtTime < 0)
	int _nCrtAFrame; // = _nCrtFrame (if _nCrtTime < 0)
	int _nCrtTime;

	LSpriteInstance() {
	}

	LSpriteInstance(LSprite spr, int posX, int posY) {
		_posX = posX;
		_posY = posY;
		_sprite = spr;
	}

	void SetAnim(int id) {

		if (id != _nCrtAnim) {
			_nCrtAnim = id;
			_nCrtAFrame = 0;
			_nCrtTime = 0;
		}
	}

	void SetFlag(int flag){
		_flags = flag;
	}
	
	boolean IsAnimEnded() {
		if (_nCrtAFrame != _sprite.GetAFrames(_nCrtAnim) - 1)
			return false;

		int time = _sprite.GetAFrameTime(_nCrtAnim, _nCrtAFrame);

		return ((time == 0) || (_nCrtTime == time - 1));
	}

	void PaintSprite(Graphics g) {
		if (_sprite == null)
			return;

		int posX = _posX, posY = _posY;

		_sprite.SetGraphics(g);

		if (_nCrtTime >= 0)
			_sprite.PaintAFrame(_nCrtAnim, _nCrtAFrame, posX, posY, _flags);
	}

	void UpdateSpriteAnim() {
		if (_sprite == null)
			return;

		if (_nCrtTime < 0)
			return;

		int time = _sprite.GetAFrameTime(_nCrtAnim, _nCrtAFrame);

		if (time == 0)
			return;

		_nCrtTime++;

		if (time > _nCrtTime)
			return;

		_nCrtTime = 0;

		_nCrtAFrame++;

		if (_nCrtAFrame >= _sprite.GetAFrames(_nCrtAnim)) {
			_nCrtAFrame = 0;
		}
	}

}
