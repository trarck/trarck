<template>
    <div id="active-document-iofo-box">

    </div>
</template>
<style lang="scss">

</style>



<script>
    export default {

        watch:{},
        props: [],
        data () {
            return {}
        },
        methods: {},
        computed: {},
        components: {
        }
    }
</script>

