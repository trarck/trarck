#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

#include "freeNN/perceptron.h"

#ifdef __cplusplus
extern "C" {
#endif

Perceptron *Perceptron_new(unsigned numOfInputs, double trainingRate) {
	Perceptron *perc = (Perceptron*)malloc(sizeof(Perceptron));
	perc->neuron_ = Neuron_new(numOfInputs, 0, STEP_FUNCTION);
	perc->trainingRate_ = trainingRate;
	
	return perc;	
}

Perceptron *Perceptron_new_from_string(const char *perceptronStr) {
	char buffer[NEURON_STR_READ_BUFFER_SIZE];
	_Neuron_getValueFromString(perceptronStr, "trainingRate=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	double trainingRate = atof(buffer);
	Perceptron *p = Perceptron_new(1, trainingRate);
	Neuron *n = Neuron_new_from_string(perceptronStr);
	Neuron_destroy(p->neuron_);
	p->neuron_ = n;
	
	return p;
}

void Perceptron_destroy(Perceptron *perceptron) {
	Neuron_destroy(perceptron->neuron_);
	free(perceptron);
}

double Perceptron_getValue(const Perceptron *perceptron, const double inputs[]) {
	return Neuron_getValue(perceptron->neuron_, inputs);
}

void Perceptron_setTrainingRate(Perceptron *perceptron, double trainingRate) {
	perceptron->trainingRate_ = trainingRate;
}

void Perceptron_train(Perceptron *perceptron, const double inputs[], int expectedResult) {
	double result = Perceptron_getResult(perceptron, inputs);
	if (result == expectedResult) {
		return;
	}
	_Perceptron_changeWeights(perceptron, result, expectedResult, inputs);
}

double Perceptron_getResult(const Perceptron *perceptron, const double inputs[]) {
	return Neuron_getResult(perceptron->neuron_, inputs);
}

double Perceptron_getWeightAt(const Perceptron *perceptron, unsigned index) {
	return Neuron_getWeightAt(perceptron->neuron_, index);
}

const double *Perceptron_getWeights(const Perceptron *perceptron) {
	return Neuron_getWeights(perceptron->neuron_);
}

unsigned Perceptron_getNumOfInputs(const Perceptron *perceptron) {
	return Neuron_getNumOfInputs(perceptron->neuron_);
}

double Perceptron_getThreshold(const Perceptron *perceptron) {
	return Neuron_getThreshold(perceptron->neuron_);
}

double Perceptron_getTrainingRate(const Perceptron *perceptron) {
	return perceptron->trainingRate_;
}

void Perceptron_setWeightAt(Perceptron *perceptron, unsigned index, double weight) {
	Neuron_setWeightAt(perceptron->neuron_, index, weight);
}

void Perceptron_setWeights(Perceptron *perceptron, const double *weights) {
	Neuron_setWeights(perceptron->neuron_, weights);
}

void Perceptron_setThreshold(Perceptron *perceptron, double threshold) {
	Neuron_setThreshold(perceptron->neuron_, threshold);
}

char *Perceptron_toString(const Perceptron *perceptron) {
	char *str = NULL;
	char *neuron_str = Neuron_toString(perceptron->neuron_);
	unsigned neuron_str_len = strlen(neuron_str);
	unsigned used_size = 0;
	unsigned alloc_size = 0;
	char buffer[64] = "";

	sprintf(buffer, "%s\n", PERCEPTRON_STR_START);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	str = (char*)realloc(str, (alloc_size + neuron_str_len + 1) * sizeof(char));
	strcat(str, neuron_str);
	free(neuron_str);
	used_size += neuron_str_len;
	alloc_size += neuron_str_len + 1;
	sprintf(buffer, "\ntrainingRate=%f\n", perceptron->trainingRate_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	_Neuron_appendToString(&str, PERCEPTRON_STR_END, &used_size, &alloc_size);

	return str;
}

void _Perceptron_changeWeights(Perceptron *perceptron, double actualResult, double desiredResult, const double inputs[]) {
	unsigned i;
	for (i = 0 ; i < perceptron->neuron_->numInputs_ ; i++) {
		perceptron->neuron_->weights_[i] += perceptron->trainingRate_ * (desiredResult - actualResult) * inputs[i];
	}
	perceptron->neuron_->threshold_ -= perceptron->trainingRate_ * (desiredResult - actualResult);
}


#ifdef __cplusplus
}
#endif

