/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.components;

import javax.microedition.lcdui.Graphics;

import com.motionwelder.animationdemo.MainCanvas;
import com.motionwelder.animationdemo.screens.MongoGameScreen;
import com.motionwelder.animationdemo.utils.Key;
import com.studio.motionwelder.MSprite;
import com.studio.motionwelder.MSpriteAnimationPlayer;
import com.studio.motionwelder.MSpriteData;
import com.studio.motionwelder.MPlayer;

public class GameCharacter implements MSprite{
	
	/** Sprite */
	public MPlayer player;
	int spriteX = 50;
	int spriteY = 175;
	
	/** Direction */
	public byte direction;
	public static final byte DIR_RIGHT = 0;
	public static final byte DIR_LEFT = 1;
	
	/*
	 *  This below way of handling animation, might seem to be confusing and useless, at first go, but it is useful way to avoid
	 *  duplication of animation in Motion Welder
	 *  Just Consider the scenario below. 
	 *   Animation used in Game 			 - STAND, WALK, RUN
	 *   Animation designed in Motion Welder - STAND, RUN
	 *   Basically WALK, and RUN animation is same for this game only difference is in WALK run cycle is executed once
	 *   hence instead of making both the animation in Motion Welder, we just made one, and have handled it here this way      
	 */
	
	/** Animations states to GAME */
	private static final byte ANIM_MONGO_STANCE = 0;
	private static final byte ANIM_MONGO_RUN    = 1;
	private static final byte ANIM_MONGO_WALK   = 2;
	
	/** Animations state of MOTION WELDER PLAYER*/
	private static final byte M_ANIM_MONGO_STANCE = 0;
	private static final byte M_ANIM_MONGO_RUN    = 1;

	// current mongo animation
	private int animation;
	
	public GameCharacter(MSpriteData spriteData){
		player = new MSpriteAnimationPlayer(spriteData,this);
		setAnimation(ANIM_MONGO_STANCE);
		direction = DIR_RIGHT;
	}

	/** Update Function */
	public void update(){
		switch (animation) {
		case ANIM_MONGO_STANCE:
			if((MainCanvas.keyPressed&Key.RIGHT)!=0 ){
				if(direction==DIR_RIGHT){
					setAnimation(ANIM_MONGO_WALK); 
				} else{
					direction=DIR_RIGHT;
				}
			} else if((MainCanvas.keyPressed&Key.LEFT)!=0 ){
				if(direction==DIR_LEFT){
					setAnimation(ANIM_MONGO_WALK); 
				} else{
					direction=DIR_LEFT;
				}
			}
			break;
		case ANIM_MONGO_WALK:
			break;
		case ANIM_MONGO_RUN:
			   if(!((MainCanvas.keyKeptPressed&(Key.RIGHT | Key.LEFT))!=0)){
				   setAnimation(ANIM_MONGO_STANCE);
			   }
			break;
		}
		
		player.update();
	}
	
	//@From MSprite
	public void endOfAnimation(){
		switch (animation) {
		case ANIM_MONGO_WALK:
				   if((MainCanvas.keyKeptPressed&(Key.RIGHT | Key.LEFT))!=0){
					  setAnimation(ANIM_MONGO_RUN);   
					  player.setFrame(1);
				   } else {
					  setAnimation(ANIM_MONGO_STANCE);
				   }
				   
				   player.update();
			break;
		}
	}
	
	/** Paint Function */
	public void paint(Graphics g){
		player.drawFrame(g);
		
		g.setColor(0xdddddd);
		// h
		g.drawLine(0,getSpriteDrawY(),176,getSpriteDrawY());
		// v
		g.drawLine(getSpriteDrawX(),0,getSpriteDrawX(),208);
	}

	//@From MSprite
	public int getSpriteDrawX(){
		return spriteX-MongoGameScreen.cameraX;
	}
	
	//@From MSprite
	public int getSpriteDrawY(){
		return spriteY-MongoGameScreen.cameraY;
	}
	
	/** Sprite X */
	public int getSpriteX(){
		return spriteX;
	}
	
	/** Sprite Y */
	public int getSpriteY(){
		return spriteY;
	}

	
	//@From MSprite
	public byte getSpriteOrientation(){
		return (byte)direction;
	}
	
	/** Notification to update Sprite Position */
	//@From MSprite
	public void updateSpritePosition(int incX,int incY){
		spriteX +=incX; 
		spriteY+=incY;
		
		if(spriteX<0){
			spriteX = 0;
		} else if(spriteX>MongoGameScreen.gameWidth){
			spriteX = MongoGameScreen.gameWidth;
		}
	}
	
	/** Sets animation, also maps from Game Animation to Studio Animation */
	public void setAnimation(int animation){
		switch (animation) {
		case ANIM_MONGO_STANCE:
			 player.setAnimation(M_ANIM_MONGO_STANCE);
			 player.setLoopOffset(0);
			break;
		case ANIM_MONGO_RUN:
			 player.setAnimation(M_ANIM_MONGO_RUN);
			 player.setLoopOffset(1);
			 break;
		case ANIM_MONGO_WALK:
			 player.setAnimation(M_ANIM_MONGO_RUN);
			 player.setLoopOffset(-1);
			break;
		}
		this.animation = animation;		
	}
}
