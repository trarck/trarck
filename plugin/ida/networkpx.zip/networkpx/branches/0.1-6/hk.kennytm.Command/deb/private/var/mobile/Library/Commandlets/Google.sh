#!/bin/bash

Commandlet-Tools url http://www.google.com/ ? q "$1"