package anim;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.util.Vector;
import java.io.*;
import org.w3c.dom.*;

public class Action {
	public String name = "";
	public Vector frmIdTable = new Vector(), frmDelay = new Vector();
	public MechModule mechModule = new MechModule();

	public Action()
	{
	}

    public String getName(int frameSelId)
    {
        if (frameSelId < 0 || !includeFrame(frameSelId))
            return "      "+name;
        return "["+frameSelId+"]"+name;
    }
    public boolean includeFrame(int frameId)
    {
        for(int i = 0; i < frmIdTable.size(); i++)
        {
            if (((Integer)frmIdTable.elementAt(i)).intValue() == frameId)
                return true;
        }
        return false;
    }

	public void saveToAni(DataOutputStream os)
		throws IOException
	{
		int i;
		os.writeUTF(name);
		os.writeInt(frmIdTable.size());
		for(i = 0; i < frmIdTable.size(); i++)
		{
			os.writeInt(((Integer)frmIdTable.elementAt(i)).intValue());
		}
		mechModule.saveToAni(os);
	}

	public void exportXML(Document document, Element parent)
	{
		Element e = document.createElement("Action"), c;
		parent.appendChild(e);
		e.setAttribute("name", name);
		mechModule.exportXML(document, e);
		int i;
		for(i = 0; i < frmIdTable.size(); i++)
		{
			c = document.createElement("Sequence");
			c.setAttribute("id", String.valueOf(((Integer)frmIdTable.elementAt(i)).intValue()));
			c.setAttribute("duration", String.valueOf(((Integer)frmDelay.elementAt(i)).intValue()));
			e.appendChild(c);
		}
	}

	public static Action fromXML(Animation ani, Element e)
	{
		int i;
		NodeList nl;
		String attr;
		Action a = new Action();
		a.name = e.getAttribute("name");
		nl = e.getElementsByTagName("Sequence");
		a.frmIdTable = new Vector(nl.getLength());
		a.frmDelay = new Vector(nl.getLength());
		for(i = 0; i < nl.getLength(); i++)
		{
			a.frmIdTable.addElement(Integer.valueOf(((Element)nl.item(i)).getAttribute("id")));
			attr = ((Element)nl.item(i)).getAttribute("duration");
			if(attr == null || attr.length() == 0)
			{
				a.frmDelay.addElement(new Integer(((AniFrame)ani.frames.get(((Integer)a.frmIdTable.get(i)).intValue())).duration));
			}
			else
			{
				a.frmDelay.addElement(new Integer(attr));
			}
		}
		a.mechModule = MechModule.fromXML((Element)(e.getElementsByTagName("MechModel").item(0)));
		return a;
	}

	public void exportForBrew(DataOutputStream os)
		throws IOException
	{
		int i, n, s;
/*
		s = 2 + frmIdTable.size() * 2 + 2 + mechModule.parLen[mechModule.type];
		os.writeByte(s & 0xff);
		os.writeByte(s >> 8);
		os.writeByte(frmIdTable.size() & 0xff);
		os.writeByte(frmIdTable.size() >> 8);
		for(i = 0; i < frmIdTable.size(); i++)
		{
			n = ((Integer)frmIdTable.elementAt(i)).intValue();
			os.writeByte(n & 0xff);
			os.writeByte(n >> 8);
		}
		//Make data align to 2
//        if(n != frmIdTable.size())
 //           os.writeByte(0);
		mechModule.exportForBrew(os);*/
	}

	public static Action createFromAni(Animation ani, DataInputStream is)
		throws IOException
	{
		int i, n;

		Action action = new Action();
		action.name = is.readUTF();
		n = is.readInt();
		action.frmIdTable = new Vector(n);
		for(i = 0; i < n; i++)
		{
			action.frmIdTable.addElement(new Integer(is.readInt()));
			action.frmDelay.addElement(new Integer(((AniFrame)ani.frames.get(i)).duration));
		}
		action.mechModule = MechModule.createFromAni(is);
		return action;
	}

	public Object clone()
	{
		int i;
		Action a = new Action();
		a.name = name;
		for(i = 0; i < frmIdTable.size(); i++)
		{
			a.frmIdTable.addElement((Integer)frmIdTable.elementAt(i));
			a.frmDelay.addElement((Integer)frmDelay.elementAt(i));
		}
		a.mechModule = (MechModule)mechModule.clone();
		return a;
	}

	public void Scale(float f)
	{
		mechModule.Scale(f);
	}

	boolean isEqual(Action dst)
	{
		int i;
		if(dst.name.compareTo(name) != 0) return false;
		if(frmIdTable.size() != dst.frmIdTable.size()) return false;
		for(i = 0; i < frmIdTable.size(); i++)
		{
			if(!((Integer)frmIdTable.get(i)).equals(dst.frmIdTable.get(i))) return false;
			if(!((Integer)frmDelay.get(i)).equals(dst.frmDelay.get(i))) return false;
		}
		return dst.mechModule.isEqual(mechModule);
	}
}
