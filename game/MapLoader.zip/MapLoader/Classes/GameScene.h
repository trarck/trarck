//
//  GameScene.h
//  Dungeons
//
//  Created by trarck trarck on 11-10-14.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface GameScene : CCLayer {

}
+(CGPoint) locationFromTouch:(UITouch*) touch; 
+(id) scene;
@end
