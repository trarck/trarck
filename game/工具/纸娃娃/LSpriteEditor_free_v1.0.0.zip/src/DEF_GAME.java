
public interface DEF_GAME {
	public static final int SCREEN_WIDTH = 240;
	public static final int SCREEN_HEIGHT = 320;
	public static final int FPS = 25;
	
	public static final int LOADING = 0;
	public static final int DISPLAY = 1;
	
}
