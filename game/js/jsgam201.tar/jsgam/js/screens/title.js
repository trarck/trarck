/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreezii@firstwave.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.firstwave.es
 * 
*/


//This is an example Title Screen.
//Modify this file as you want following the tutorials

//The main function
function Main()
{
  //Title of the Room
  SetTitle("JSGAM (JavaScript Graphic Adventure engine)");
  
  CreateScreen("Title",800,600)
  
  CreateStartButton("Name",208,64,300,250,"00");
  
  TitleTxt=CreateText(400,20,200,150);
  TitleTxt.ChangeText("Click on the title to start the adventure");
   
}

//Run the game
RunGame(); //Here we go!!!
