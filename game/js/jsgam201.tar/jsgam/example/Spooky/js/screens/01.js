//The main function
function Main()
{
  //Title of the Room
  SetTitle("This is the screen00");
  
  //Creating Scene and menu
  CreateScreen("01",800,400);
  SetScreenLimits(0,800,250);
  CreateMenu();
   
  //Adding the player
  CreatePlayer(180,245,400,150);
  
  //Objects 
  Window1=CreateInvisibleObject(120,98,565,56);
  Window1.description="My bedroom's window"
  Window1.DoorTo("00");

}

//Run the game
RunGame(); //Here we go!!!
