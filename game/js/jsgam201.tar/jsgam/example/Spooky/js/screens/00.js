//The main function
function Main()
{
  //Title of the Room
  SetTitle("Neiang's Room");
  
  //Creating Scene and menu
  CreateScreen("00",800,400);
  SetScreenLimits(60,740,280);
  CreateMenu();
   
  //Adding the player
  CreatePlayer(180,245,400,150);
  
  //Objects 
   
  //-Door
  Door=CreateInvisibleObject(145,165,95,65);
  Door.description="The Door to the gym, it's locked";
  
  //-Sword
  Sword=CreateObject("Sword",82,62,360,80);
  Sword.description="It's a taoist sword, useful to fight with vampires.";
  
  //-Hay
  Hay=CreateObject("Hay",144,56,600,300);
  Hay.description="Where is Ying-Fing?";
  
  //-Cupboard
  Cupboard=CreateInvisibleObject(130,165,602,77);
  Cupboard.description="My cupboard, here are all my cloths. I don't need nothing from here.";
  
  //-Bed
  Bed=CreateInvisibleObject(260,60,296,180);
  Bed.description="The Bed";
  
  //-Window
  Window=CreateInvisibleObject(40,80,0,108);
  
  if(SearchParameter("WindowOpened"))
  {
	  Window.description="Window to the outside, it's opened";
	  Window.DoorTo("01"); 
  }else{
	  Window.description="Window to the outside, it's locked but it seems i can use something to open it";
	  Window.UsableWith("Sword",OpenWindow);
  }
     
  //Set the actions
  SetTakableObjects(new Array(Sword));

}

//Screen Actions
function OpenWindow()
{
	Player.Say("Now it's open");
	Window.DoorTo("01");
	CreateParameter("WindowOpened");
}

//Run the game
RunGame(); //Here we go!!!
