/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreeziidaemon@yahoo.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.blogspot.com
 * 
*/

//Variables
var preloadImages=new Array();
var jsImages=new Array();
var jsImagesLoaded=new Array();
var imagesTotal=0;
var loadedimages=0;
var imgStates=new Array('left','right','goleft','goright');
var forLimit=imgStates.length*spriteframes;

//Preload images for animations
function Preload(numScreen)
{
	
	PreloadTxt=CreateText(300,30,parseInt(document.getElementById(DivScreen).style.width)/2-150,parseInt(document.getElementById(DivScreen).style.height)/2-15,"Preload");
  	PreloadTxt.ChangeText(TextPreloadImages);   
  	
    //Add the Player images
	if(Player!=undefined)
	{
		Player.lockSprite=true;
	
		preloadImages[imagesTotal]="imgs/Sprites/Player/frame.png"
		imagesTotal++;
		
		this.j=0
		this.k=0;

		for(i=0;i<forLimit;i++)
		{
			preloadImages[imagesTotal]="imgs/Sprites/Player/"+imgStates[this.j]+"/frame"+this.k+".png";
			imagesTotal++;
			if(this.k<spriteframes-1)
			{
			  this.k++;
			}else{
			  this.k=0;
			  this.j++;          
			}
		}
		
		//Add the Menu images, if player doesn't exist the menu doesn't preload
		imgMenu=new Array('back','Look','Speak','Take','Use');
		for(i=0;i<imgMenu.length;i++)
		{
			preloadImages[imagesTotal]="imgs/Menu/"+imgMenu[i]+".png";
			imagesTotal++;
		}   
	}
	
    //Add the Objects images
    if(objectsArray!=undefined)
    {    
    	for(i=0;i<objectsArray.length;i++)
    	{
			preloadImages[imagesTotal]="imgs/Sprites/"+objectsArray[i].name+"/frame.png";
        	imagesTotal++;
			this.j=0
			this.k=0;
			
			for(z=0;z<forLimit;z++)
			{
				preloadImages[imagesTotal]="imgs/Sprites/"+objectsArray[i].name+"/"+imgStates[this.j]+"/frame"+this.k+".png";
				imagesTotal++;
				if(this.k<spriteframes-1)
				{
				  this.k++;
				}else{
				  this.k=0;
				  this.j++;          
				}
			}
		}
		
	} 

    //Add the Screen image
    preloadImages[imagesTotal]="imgs/Screens/"+ImgScreen+".png";
    imagesTotal++;
    
    //Now preload all images
    for(i=0;i<imagesTotal;i++)
    {
      jsImages[i]=new Image();
      jsImages[i].src=preloadImages[i];
    }
    
    for(i=0;i<imagesTotal;i++)
    {
	  jsImagesLoaded[i]=false;
    }
    
    CheckLoad();
}

function CheckLoad()
{
  for(i=0;i<imagesTotal;i++)
  {
    if(jsImages[i].complete && jsImagesLoaded[i]==false)
    {
      loadedimages++;
      jsImagesLoaded[i]=true;
    }
  }
  if(loadedimages==imagesTotal)
  {
   DestroyText(PreloadTxt);
   
   if(Player!=undefined)
   {
   	Player.lockSprite=false;
   }
   
  }else{
  	PreloadTxt.ChangeText(TextPreloadImages+" ("+Math.round(loadedimages/imagesTotal*100)+"%)");
    timerID = setTimeout("CheckLoad()",10);
  }
}
