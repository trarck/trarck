/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.components;

import javax.microedition.lcdui.Graphics;

import com.motionwelder.animationdemo.screens.MongoGameScreen;
import com.studio.motionwelder.MSimpleAnimationPlayer;
import com.studio.motionwelder.MSpriteData;

/*
 *  Class Pickable is use to represent Banana that Mongo takes while running
 *  Pickable uses MSimpleAnimationPlayer to load banana animation, and when mongo hits it, it explodes
 *  For Explode: player animation is set to EXPLODE
 */
public class Pickable {
	
	/**  Here Animation starts from 2, as intial 0,1 is occupied by mongo(stance, run), as mongo and banana animation are in same .anu */
	public static final byte BANANA_SHINE   = 2;
	public static final byte BANANA_EXPLODE = 3;
	
	/** player */
	MSimpleAnimationPlayer pickablePlayer;
	
	/** position of banana */
	private int x,y;
	
	/** Pickable Constructor */
	public Pickable(MSpriteData data,int x){
		// creating new pickable player
		this.x = x;
		this.y = 135;
		
		pickablePlayer = new MSimpleAnimationPlayer(data,x,y);
		
		// sets its animation to BANANA_SHINE
		pickablePlayer.setAnimation(BANANA_SHINE);
	}
	
	/** Returns X */
	public int getX(){
		return x;
	}
	
	/** Returns Y */
	public int getY(){
		return y;
	}
	
	/**  Set the state of banana to Expode	 */
	public void explode(){
		// change player state to Explode
		pickablePlayer.setAnimation(BANANA_EXPLODE);
		
		// set animation to play it for once 
		pickablePlayer.setLoopOffset(-1);
	}
	
	/** Update Function */
	public void update(){
		// check if we have completed comple banana explode
		if(pickablePlayer==null){
			return;
		}
		
		// update player
		pickablePlayer.update();
		
		if(pickablePlayer.getAnimation()==BANANA_EXPLODE && !pickablePlayer.isPlaying()){
			// we are done here, release pickable player
			pickablePlayer = null;
		}
	}
	
	/** Paint Function */
	public void paint(Graphics g){
		// don't proceed .. if animation is done..
		update();
		if(pickablePlayer==null) return;
		
		// set position of player, as camera might pan, set new value of player
		pickablePlayer.setSpriteX(x-MongoGameScreen.cameraX);
		pickablePlayer.drawFrame(g);
	}

	/** returns true if banana is already exploded, this will be called to avoid calls to update and paint */
	public boolean isExploded(){
		return pickablePlayer==null;
	}
	
	/** returns true if banana is already exploded, this will be called to avoid calls to update and paint */
	public boolean isExploding(){
		return pickablePlayer.getAnimation()==BANANA_EXPLODE;
	}
}
