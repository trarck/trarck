#ifndef UIKIT2_KB_DEBUG_H
#define UIKIT2_KB_DEBUG_H

namespace KB {
	void kb_debug();
};

#endif