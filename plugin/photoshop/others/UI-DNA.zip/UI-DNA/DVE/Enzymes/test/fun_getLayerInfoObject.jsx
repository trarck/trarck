﻿/**
 * Created by bgllj on 2016/7/12.
 */
$.evalFile("C:/Users/nullice/MyProject/UI-DNA/DVE/bin/JSX/json3.js")
$.evalFile(File($.fileName).path + "/test.jsx")


var ob = ki.layer.getLayerInfoObject_byActiveLayer()


log(json(ob))
logSave()