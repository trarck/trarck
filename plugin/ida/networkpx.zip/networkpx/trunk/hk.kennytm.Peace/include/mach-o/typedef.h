#ifndef MACH_O_TYPEDEF_H
#define MACH_O_TYPEDEF_H

typedef int integer_t;
typedef integer_t	cpu_type_t;
typedef integer_t	cpu_subtype_t;
typedef integer_t vm_prot_t;

#endif
