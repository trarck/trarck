var fs = require('fs');
var util = require ('util');
var crypto = require('crypto');
var path = require('path');
var exec = require('child_process').exec;
var sys = require('sys');
var spawn = require('child_process').spawn;

var File = require('./file');
var Async = require('./async');

exports.process_assets = function(manifest_file, output_dir, base_path, options, callback) {

	if(typeof manifest_file == 'string'){
		var manifest = JSON.parse(fs.readFileSync(manifest_file));
	}
	else {
		var manifest = manifest_file;
	}

    var androidResize=options.androidResize!='false';
    //console.log("@@@@@@@@@@@@@androidResize:",androidResize,options.androidResize,typeof(options.androidResize));

	var images = [];
	var ts = new Async.WorkPool();
	var asset_categories = ['textures', 'audio', 'other'];
	for(var a in asset_categories){
		if(manifest[asset_categories[a]]){
			var asset_list = manifest[asset_categories[a]];
			for(var i in asset_list){
				var search_path = path.join(base_path, asset_list[i]);
				var file_list = File.glob(search_path);
				var base_size = base_path.split('/').length;
				if(base_path.replace('/', '') == '.') base_size = 0;
				for(var j in file_list){
					(function(){
						var rel_path = file_list[j].split('/').slice(base_size).join('/');
						var input_path = file_list[j];
						var copy_path = path.join(output_dir, rel_path);
						var android_copy_path = path.join(output_dir, 'android', rel_path);
						var ios_copy_path = path.join(output_dir, 'ios', rel_path);
						var flash_copy_path = copy_path;

						var catName = asset_categories[a];
						//console.log('copy_image_file', input_path, copy_path, android_copy_path);
						ts.enqueue(function(done){
							// console.log("Copying ", input_path, copy_path);
							var ts2 = new Async.TaskSet();
							copy_asset(input_path, flash_copy_path, false, ts2.task());
							copy_asset(input_path, ios_copy_path, false, ts2.task());
							copy_asset(input_path, android_copy_path, androidResize && (catName == 'other' ? false : true), ts2.task());
							ts2.join(done);
						});
					})();
				}
			}
		}
	}
	ts.join(function(){
		if(callback) callback();
	});
	
};


function copy_asset(source, dest, resize, callback){
   	var copy = false;
	if(!File.exists(dest)){copy = true;}
	else {
		var sstat = fs.statSync(source);
		var dstat = fs.statSync(dest);
		if(new Date(sstat.mtime) > new Date(dstat.mtime)) copy = true
	}

	var abort = function(err){
		console.log('Could not copy ' + source + ' to ' + dest, err);
		done();
	}

	if(copy)
	{
		File.mkdirp(path.dirname(dest), 0777);

		exec('cp "' + source + '" "' + dest + '"',
			function (error, stdout, stderr)
			{
				if (error !== null)
				{
					console.log('stdout: ' + stdout);
					console.log('stderr: ' + stderr);
					console.log('exec error: ' + error);
					abort(error);
				}
				else if(resize)
				{
                    var resize_path = path.join(__dirname, 'images.py');
					//Call images.py to convert images. images.py should be in the same directory as server code
					var sips = spawn(resize_path,[dest]);
					sips.stdout.on('data', util.print);
					sips.on('exit', function ()
					{
						if(callback) callback();
					});
				}
				else
				{
					if(callback) callback();
				}
			}
		);
	}
	else {
		if(callback) callback();
	}	
}
