/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.screens;

import javax.microedition.lcdui.Graphics;

import com.motionwelder.animationdemo.MainCanvas;
import com.motionwelder.animationdemo.MainMidlet;
import com.motionwelder.animationdemo.utils.GenericImageTextRenderableScreen;
import com.motionwelder.animationdemo.utils.Key;

/**
 * 
 * Class AnimationViewerIntroScreen is used to show intro which appears before actual animation starts
 *
 */
public class AnimationViewerIntroScreen extends GenericImageTextRenderableScreen{

	public AnimationViewerIntroScreen(){
		// append string and image
		append("Games are nothing without");
		append("animation, and offcourse");
		append("nothing without idyllic");
		append("animation. Explore your");
		append("creativity using Motion Welder");
		append("Lets take a tour of few");
		append("animations made from");
		append("Motion Welder");
		append("");
		append("Click 'Next' to load suites of");
		append("animation.");
		append("Can you think of more");
		append("animations..?");
		calculateScreenHeight();
	}
	
	public void paint(Graphics g){
		super.paint(g);
		
		MainCanvas.drawCommands(g,"Next","Back");
	}
	
	public void update(){
		super.update();
		
		if((MainCanvas.keyPressed&(Key.SOFT_R))!=0 ){
			MainMidlet.exitApp();
			return;
		}
		
		if((MainCanvas.keyPressed&(Key.SELECT|Key.NUM5|Key.SOFT_L))!=0 ){
			MainCanvas.switchScreen(new AnimationViewerScreen());
		}
	}
}
