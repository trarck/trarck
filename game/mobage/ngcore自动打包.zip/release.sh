#!/bin/bash
file="dungeons"$(date +%Y%m%d)".zip"
cd /root/ngcore-sdk-sdks_1.1-20110616-1.1.6-20110701-g3984b42/SDK/Samples/Dungeons
node ../../Tools/jake/lib/jake.js -f ../../Tools/prepare/ServerJakefile build jslint=false
zip -q -r $file build
mv $file /mnt/website/dungeons_server/www/download