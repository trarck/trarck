package gui;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;

public class ActorTypeDlg extends Dialog implements ActionListener
{
	TextField[] flds = new TextField[100];

	public ActorTypeDlg(Frame owner)
	{
		super(owner, "Edit Actor Types", true);
		setSize(800, 720);
		setLayout(new GridLayout(26, 8));
		centerOnParent(owner);
		int i;
		String[] s = AnimationEditor.getActorTypes();
		Label lb;
		for(i = 0; i < 100; i++)
		{
			flds[i] = new TextField();
			lb = new Label("Type " + i + ":");
			lb.setAlignment(Label.RIGHT);
			this.add(lb);
			this.add(flds[i]);
		}
		for(i = 0; i < s.length; i++)
		{
			flds[i].setText(s[i]);
		}
		Button btn = new Button("OK");
		btn.addActionListener(this);
		this.add(btn);
		btn = new Button("Cancel");
		btn.addActionListener(this);
		this.add(btn);
	}

	private void centerOnParent(Component comp)
	{
		setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2, comp.getLocation().y + (comp.getSize().height - getSize().height) / 2);
	}

	public void actionPerformed(java.awt.event.ActionEvent actionEvent)
	{
		if(actionEvent.getActionCommand() == "OK")
		{
			String[] s;
			int i, n;
			for(n = flds.length; n > 0; n--)
				if(flds[n - 1].getText().length() != 0)
					break;
			s = new String[n];
			for(i = 0; i < n; i++)
				s[i] = flds[i].getText();
			AnimationEditor.setActorTypes(s);
			dispose();
		}
		else if(actionEvent.getActionCommand() == "Cancel")
		{
			dispose();
		}
	}
}
