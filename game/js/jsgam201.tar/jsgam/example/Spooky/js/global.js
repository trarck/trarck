/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreeziidaemon@yahoo.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.blogspot.com
 * 
*/

//This file contains the global variables and the definition of the Sprites, Inventory and Texts

//Global variables
var AddtoInventory=new Array();
var ObjectsUsed=new Array();
var GameParameters=new Array();
var GameActions=new Array("Look","Take","Speak","Use");

//Scene variables
var DivScreen;
var ImgScreen;
var ScreenName;
var leftLimit=0;
var rightLimit=800;
var verticalLimit=0;
var defaultScreen=null;

//Sprite variables
var Player;
var emptySprite;
var spriteframes=3;
var spritedepth=1;
var fps=200;

//Object variables
var objectsArray=new Array();
var objectArrayNumber=0;
var invisibleObject=0;

//Inventory variables
var invnum=new Array();
var actualinv=null;
var maxinv=6;
var menuheight=100;
var iconsize=50;
var acticonsize=60;

//Text variables
var txtwidth=220;
var txtheight=150;
var saytxt;
var textcount=0;

//Other
var ActiontoDo=null;
var delay=2000;
var StartButton=null;

//Regular Expressions
var SpriteFolder="imgs/Sprites/";
var ScreenFolder="imgs/Screens/";
var MenuFolder="imgs/Menu/";
var MenuBackground = 'url(imgs/Menu/back.png)';
var Frame="frame";
var GoLeftStatus='goleft';
var GoRightStauts='goright';
var LeftStatus='left';
var RightStatus='right';
var ImgExt=".png";

function Sprite(name,x,y,width,height,zindex,nframes,description)
{
//Variables
	this.description=description;
	
	if(name=="Invisible")
	{
		this.divname=ScreenName+"Div-"+name+"-"+invisibleObject;
		invisibleObject++;
	}else{
		this.divname=ScreenName+"Div-"+name+"-"+SearchDiv(name);
	}
	
	this.imgname=this.divname+"Img";
	this.name=name;
	this.zindex=zindex;
    
    this.conversationText=new Array();
    this.conversationPart=0;

//Animation varibles
	this.status=LeftStatus;//Status
	this.states=new Array();
	this.nframes=nframes;//Number of animation frames
	this.frame=0;//Actual frame
    this.loopAnimation=true;

//Moving variables
	this.dirx=1;//Tell if move to left or right
	this.diry=1;//Tell if move to up or down
	this.ismovingH=false;
	this.ismovingV=false;
	this.mtimeout;
	this.toX=0;//Number of times to move x
	this.toY=0;//Number of times to move y
	this.step=5;//Step
	this.lockSprite=false;//It determinate if the sprite can move or not
	
//Move limits for the sprite
	this.limitX=leftLimit;
	this.limitX2=rightLimit;
	this.limitY=verticalLimit;	
	
    this.actionWith=null;
	this.action;
	
//Functions
	this.checkdepth=CheckDepth;
	//Move functions
	this.getx=getX;
	this.gety=getY;
	this.getleft=getLeft;
	this.getright=getRight;
	this.move=Move;
	this.gotoxy=gotoXY;
    this.Animate=Animate;
    this.StopAnimate=StopAnimate;
	
//Action functions
	this.look=Look;
	this.take=Cantdo;
	this.use=Cantdo;
	this.speak=Cantdo;
	this.action=Action;
	this.Say=Say;
    this.SetConversation=SetConversation;
    this.UsableWith=UsableWith;
    this.DoorTo=IsDoorTo;
    this.Flip=FlipSprite;
    this.Hide=HideSprite;
    this.Show=ShowSprite;
}

function Inventory(id)
{
//Variables
	this.image=document.createElement('IMG');
	this.id=id;
	this.fromDiv;
	this.name;
	this.image.style.width=iconsize +"px"
	this.image.style.height=iconsize +"px"
}

function GameText(name,div,width,height,x,y,txt)
{
//Variables
  this.name=name;
  this.div=div;
  this.width=width;
  this.height=height;
  this.x=x;
  this.y=y;
  
//Functions
  this.ChangeText=ChangeText;
  this.RemoveText=RemoveText;
}
