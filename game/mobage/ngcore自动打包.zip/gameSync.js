	var path = require('path'),
    fs = require('fs'),
    crypto = require('crypto'),
    sys = require('sys'),
    gameClient = require('gameClient.js').gameClient,
    http = require('http'),
    fileUtils = require('fileUtils'),
    spawn = require('child_process').spawn,
    exec  = require('child_process').exec
	ngUtil = require('ngUtil'),
	util = require('util'),
	Async = require('async'),
	querystring = require('querystring');

/**
 * This handles communicating with the packaging server, from getting data
 * to sending data
 * 
 * Two things must be set before any calls can be made
 *      serverUrl - the Url of the packaging server itself
 */
exports.version = 0.1;
exports.gameSync = new function()
{
	this.masterServerUrl = 'localhost';
	this.masterServerPort = 8090;
    this.serverUrl = null;
    this.serverPort = 8090;
    this.verbose = false;
    this.auth = null;
	
	// socket management
	this.uploadSockets = 80;
	this.querySockets = 20;
	this.uploadQueries = new Async.WorkPool();
	
	this.getLimit = function(isUpload)
	{
		var percentage = this.querySockets;
		if(isUpload)
			percentage = this.uploadSockets;
			
		var agent = this.getAgent();
		
		if(!agent)
			return null;
		
		var limit = (percentage / 100) * agent.maxSockets;
		limit = Math.floor(limit);
		
		return limit;
	};
	
    /**
     * Sets the server Url, does any necessary validation to ensure it's
     * been passed a valid packaging server
     */
    this.setServerUrl = function(serverUrl, serverPort, cb)
    {
        var error = { msg: 'setServerUrl failed:\n', b: false };
    
        this.serverUrl = serverUrl;
        
		if(serverPort)
			this.serverPort  = serverPort;
			
		this.masterServerUrl = serverUrl;
		this.masterServerPort = serverPort;
		
		this.updateUploadWorkpool();
        
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': '/get/host',
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		//this.verbose = true;
		this.makeRequest(options, error, (function(err, data)
		{
			this.serverUrl = data.host;
			
			if(data.port)
				this.serverPort = data.port;
			else
				this.serverPort = null;
			
			cb(err, data.host);
		}).bind(this));
	};

    /**
     * Stores authentication info
     */
    this.authenticate = function(auth, cb)
    {
        var error = { msg: 'authenticate failed:\n', b: false };
    
        this.auth = auth;
		
		cb(error);
    };
	
	this.setMaxSockets = function(sockets)
	{
		var agent = this.getAgent();
		
		if(agent)
			agent.maxSockets = sockets;
			
		this.updateUploadWorkpool();
	};
	
	this.updateUploadWorkpool = function()
	{
		var limit = this.getLimit(true);
		
		if(limit)
			this.uploadQueries.limit = limit;
	};
	
	this.getAgent = function()
	{
		var agent = null;
		if(this.serverUrl && (this.serverPort !== undefined))
		{
			agent = http.getAgent(this.serverUrl, this.serverPort);
		}
		return agent;
	};

    /**
     * Get calls, these all get various data and returns it back as JSON
     */
	this.makeRequest = function(options, error, cb)
	{
		gameClient.verbose = this.verbose;
		//console.log('making request', this.serverUrl);
		var request = (function(callback)
		{
			gameClient.makeRequest(options, (function(err, data, headers)
			{
				error.b = err.b;
				error.statusCode = err.statusCode;
				
				// handle error messages if they exist
				if(data && data.error && (typeof(data.error) === 'object'))
					error.msg += JSON.stringify(data.error);
				else if(data && data.error && (typeof(data.error) === 'string'))
					error.msg += data.error;
				else
					error.msg += err.msg;
																		
				callback(error, data, headers);
			}).bind(this));
		}).bind(this);
		
		if(!options.isUpload)
		{
			request(cb);
		} else
		{
			this.uploadQueries.enqueue(function(done)
			{
				request(function(error, data, headers)
				{
					done();
					cb(error, data, headers);
				});
			});
		}
	};
	 
    this.getApps = function(cb)
    {
        var error = { msg: 'getApps failed:\n', b: false };
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': '/get/apps',
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		this.makeRequest(options, error, function(err, data)
		{
			cb(err, data.apps);
		});
    };

    this.getAppStages = function(appId, cb)
    {
        var stageList = [];
        var error = { msg: 'getAppStages failed:\n', b: false };
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': '/get/stages/' + appId,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		this.makeRequest(options, error, function(err, data)
		{
			cb(err, data.stages);
		});
    };

    this.getAppReleases = function(appId, cb)
    {
        var releaseList = [];
        var error = { msg: 'getAppReleases failed:\n', b: false };
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': '/get/releases/' + appId,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		this.makeRequest(options, error, function(err, data)
		{
			cb(err, data.releases);
		});
    };
	
	this.getReleaseInfo = function(appId, releaseId, cb)
    {
        var releaseList = [];
        var error = { msg: 'getAppReleases failed:\n', b: false };
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': '/get/releaseinfo/' + appId + '/' + releaseId,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		
		this.makeRequest(options, error, function(err, data)
		{
			cb(err, data.release);
		});
    };
	
	// we poll for the release state until it matches the one specified
	// options:
	// - appId
	// - releaseId
	// - stateCode
	// - not (checks for the current state code to not be the one passed, default false)
	// - returnProgress (default false)
	// - interval (default 200ms)
	// - timeout (default 20s)
	this.onReleaseState = function(options, cb)
	{
		var error = { msg: 'onReleaseState failed:\n', b: false };
		var setIfNot = ngUtil.setIfNot;
		
		setIfNot(options, 'interval', 200);
		setIfNot(options, 'timeout', 20 * 1000);
		setIfNot(options, 'not', false);
		setIfNot(options, 'returnProgress', false);
		
		var totalTime = 0;
		var check = (function()
		{
			this.getReleaseInfo(options.appId, options.releaseId, function(err, data)
			{
				if(err.b)
				{
					error.b = true;
					error.msg += err.msg;
					cb(error);
				} else
				{
					var code = data.status_code;
					if((!options.not && code === options.stateCode) || (options.not && code !== options.stateCode))
					{
						cb(error, { 'done': true });
					} else
					{
						totalTime += options.interval;
						if(totalTime > options.timeout)
						{
							error.b = true;
							error.msg += 'OnReleaseState timeout (' + options.timeout + ')';
							cb(error);
						} else
						{
							if(options.returnProgress)
								cb(error, { 'done': false, 'progress': data.status_progress });
							
							setTimeout(check, options.interval);
						}
					}
				}
			});
		}).bind(this);
		check();
	};
    
	this.getPublishedRelease = function(getPublishedOptions, cb)
	{
		var error = { msg: 'getPublishedRelease failed:\n', b: false };
		
		var requestPath;
		if(getPublishedOptions.environment === 'sandbox')
			requestPath = '/get/published/' + getPublishedOptions.appId + '/' + getPublishedOptions.environment + '/' + getPublishedOptions.stageId;
		else
			requestPath = '/get/published/' + getPublishedOptions.appId + '/' + getPublishedOptions.environment;
		
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': requestPath,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		
		this.makeRequest(options, error, function(err, data)
		{
			cb(err, data.details);
		});
	};
	
	this.getDeployedUrl = function(appId, releaseId, cb)
    {
        var error = { msg: 'getDeployedUrl failed:\n', b: false };
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': '/get/deployedurl/' + appId + '/' + releaseId,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		this.makeRequest(options, error, function(err, data)
		{
			cb(err, data.url);
		});
    };
	
	this.getPublishedUrl = function(getUrlOptions, cb)
    {
        var error = { msg: 'getDeployedUrl failed:\n', b: false };
		
		var requestPath;
		if(getUrlOptions.environment === 'sandbox')
			requestPath = '/get/publishedurl/' + getUrlOptions.appId + '/' + getUrlOptions.environment + '/' + getUrlOptions.stageId;
		else
			requestPath = '/get/publishedurl/' + getUrlOptions.appId + '/' + getUrlOptions.environment;
		
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': requestPath,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		this.makeRequest(options, error, function(err, data)
		{
			cb(err, data.url);
		});
    };
	
	/**
     * getPublishAttempts
	 * callOptions:
	 * - appId
	 * - environment
	 * - stageId
	 * - releaseId
	 * - queryParams
	 * -- count
	 * -- newest
	 * -- oldest
	 */
    this.getPublishAttempts = function(callOptions, cb)
    {
        var error = { msg: 'publishRelease failed:\n', b: false };
		
		var requestPath = '/get/publishattempt/' + callOptions.appId;
		
		if(callOptions.environment)
			requestPath += '/' + callOptions.environment;
		
		if(callOptions.environment === 'sandbox' && callOptions.stageId)
			requestPath += '/stage/' + callOptions.stageId;
		else if(callOptions.releaseId)
			requestPath += '/release/' + callOptions.releaseId;	
		
		var actualQueryParams = {};
		for(param in callOptions.queryParams)
		{
			//console.log('val ' + callOptions.queryParams[param]);
			if(callOptions.queryParams[param])
			{
				actualQueryParams[param] = callOptions.queryParams[param];
			}
		}
		
		//console.log('query params');
		//console.log(callOptions.queryParams);
		//console.log(actualQueryParams);
		
		var paramString = querystring.stringify(actualQueryParams);
		if(paramString.length > 0)
			requestPath += '?' + paramString;
		
		//console.log(requestPath);
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': requestPath,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		
		this.makeRequest(options, error, cb);
    };

    /**
     * Add calls, these add various types of data by querying the packaging
     * server
     */
    this.addAppStageId = function(appId, stageId, cb)
    {
        var error = { msg: 'addAppStageId failed:\n', b: false };
		var options = 
		{
			requestOptions:
			{
				'method': 'POST',
				'host': this.serverUrl,
				'path': '/new/stage/' + appId + '/' + stageId,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		this.makeRequest(options, error, cb);
    };
    
	/**
     * createRelease
	 * releaseOptions:
	 * - appId
     */
	this.createRelease = function(releaseOptions, cb)
    {
        var error = { msg: 'create release failed:\n', b: false };
		var options = 
		{
			requestOptions:
			{
				'method': 'POST',
				'host': this.serverUrl,
				'path': '/create/release/' + releaseOptions.appId,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		this.makeRequest(options, error, function(err, data)
		{
			cb(err, data['releaseId']);
		});
    };
	
	/**
     * deployRelease
	 * releaseOptions:
	 * - appId
	 * - releaseId
     * - localGameBundle
	 * - version (optional)
	 */
    this.deployRelease = function(releaseOptions, cb)
    {
        var error = { msg: 'deploy release failed:\n', b: false };
		
		var localGameBundle = releaseOptions.localGameBundle;
		
		var boundary = "AaB03x";
        var body = '';
        var addLine = function(text)
        {
            body += text + '\r\n';
        };
		
		if(releaseOptions.version)
		{
			addLine('--' + boundary);
			addLine('Content-Disposition: form-data; name="version"');
			addLine('');
			addLine(releaseOptions.version);
		}
		
		addLine('--' + boundary);
        addLine('Content-Disposition: form-data; name="file"; filename="' + path.basename(localGameBundle) + '"');
        
		var contentType = null;
		if(localGameBundle.substr(localGameBundle.length - '.zip'.length) === '.zip')
		{
			contentType = 'application/zip';
		} else if(localGameBundle.substr(localGameBundle.length - '.tar.gz'.length) === '.tar.gz')
		{
			contentType = 'application/x-gzip';
		}
		
		if(!contentType)
		{
			error.b = true;
			error.msg += 'invalid bundle type';
			cb(error, {});
		}
		
		addLine('Content-Type: ' + contentType);
		addLine('');
      
        var contentLength = Buffer.byteLength(body, 'utf8');
		
		var stat = fs.statSync(localGameBundle);
		contentLength += stat.size;
		var tail = '\r\n--' + boundary + '--';
		contentLength += Buffer.byteLength(tail, 'utf8');
		
		var requestCallback = function(request)
		{
			// write the first chunk
			request.write(body);
			
			// write the file
			var readStream = fs.createReadStream(localGameBundle, 
			{
				'bufferSize': stat.blksize
			});
			
			util.pump(readStream, request, function(err)
			{
				// when we're done writing the file, let's write the tail
				request.write(tail);
				request.end();
			});
		}
		
		var options = 
		{
			requestOptions:
			{
				'method': 'POST',
				'host': this.serverUrl,
				'path': '/deploy/release/' + releaseOptions.appId + '/' + releaseOptions.releaseId,
				'port': this.serverPort,
				'headers':
				{
					'User-Agent': 'Node.js (AbstractHttpRequest)',
					'Accept-Encoding': 'gzip,deflate',
					'Content-Type': 'multipart/form-data; boundary=' + boundary,
					'Content-Length': contentLength,
					'Authorization': 'OAuth ' + this.auth
				}
			},
			requestCb: requestCallback,
			isUpload: true
		};
		this.makeRequest(options, error, cb);
    };
    
	/**
     * publishRelease
	 * publishOptions:
	 * - appId
	 * - environment
	 * - stageId
	 * - releaseId
	 * - publishManifest
	 * - secureUrl
	 */
    this.publishRelease = function(publishOptions, cb)
    {
        var error = { msg: 'publishRelease failed:\n', b: false };
		
		var requestPath;
		if(publishOptions.environment === 'sandbox')
			requestPath = '/publish/release/' + publishOptions.appId + '/' + publishOptions.environment + '/' + publishOptions.stageId + '/' + publishOptions.releaseId;
		else
			requestPath = '/publish/release/' + publishOptions.appId + '/' + publishOptions.environment + '/' + publishOptions.releaseId;
		
		var queryParams = [];
		
		if(publishOptions.publishManifest)
			queryParams.push('publishManifest');
			
		if(publishOptions.secureUrl)
			queryParams.push('secureUrl');
			
		//console.log('queryParmas', queryParams);
			
		for(var i=0; i<queryParams.length; i++)
		{
			if(i === 0)
			{
				requestPath += '?' + queryParams[i] + '=true';
			} else
			{
				requestPath += '&' + queryParams[i] + '=true';
			}
		}
		//console.log(requestPath);
		var options = 
		{
			requestOptions:
			{
				'method': 'POST',
				'host': this.serverUrl,
				'path': requestPath,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			}, data: {}
		};
		
		this.makeRequest(options, error, cb);
    };
    
    /**
     * downloadStandaloneBuild
	 * callOptions:
	 * - appId
	 * - environment
	 * - stageId
	 * - releaseId
	 * - os
	 * - destDownloadBuild
	 */
	this.downloadStandaloneBuild = function(callOptions, cb)
    {
        var error = { msg: 'downloadStandaloneBuild failed:\n', b: false };
		
		var requestPath = '';
		
		if(!callOptions.os)
		{
			error.b = true;
			error.msg += 'No os specified\n';
			cb(error, null);
			return;
		}
		
		if(callOptions.environment)
		{
			if(callOptions.environment === 'sandbox')
			{
				if(callOptions.stageId)
				{
					requestPath = '/download/standalone/' + callOptions.appId + '/' + callOptions.environment + '/' + callOptions.stageId + '/' + callOptions.os;
				} else
				{
					error.b = true;
					error.msg += 'Environment set to sandbox but no stageId specified\n';
					cb(error, null);
					return;
				}
			} else if(callOptions.environment === 'production')
			{
				requestPath = '/download/standalone/' + callOptions.appId + '/' + callOptions.environment + '/' + callOptions.os;
			} else
			{
				error.b = true;
				error.msg += 'Invalid environment specified(' + environment + '), must be production or sandbox\n';
				cb(error, null);
				return;
			}
		} else if(callOptions.releaseId)
		{
			requestPath = '/download/standalonedeployed/' + callOptions.appId + '/' + callOptions.releaseId + '/' + callOptions.os;
		} else
		{
			error.b = true;
			error.msg += 'No environment or releaseId specified\n';
			cb(error, null);
			return;
		}
		
		var options = 
		{
			requestOptions:
			{
				'method': 'GET',
				'host': this.serverUrl,
				'path': requestPath,
				'port': this.serverPort,
				'headers':
				{
					'Authorization': 'OAuth ' + this.auth
				}
			},
			data:
			{
				'bundleId': callOptions.bundleId
			},
			receiveEncoding: 'binary'
		};
		this.makeRequest(options, error, function(err, data, headers)
		{
			var filePath = callOptions.destDownloadBuild + '/';
			if(!err.b)
			{
				var content = headers['content-disposition'];
				var fileNameIndex = content.indexOf('filename="') + 'filename="'.length;
				var fileName = content.substring(fileNameIndex, content.indexOf('"', fileNameIndex));
				var fileExt = path.extname(fileName);
			
				if(fileExt === '.zip')
				{
					filePath += (new Date().getTime()) + '.zip';
				} else if(fileExt === '.apk' || fileExt === '.ipa')
				{
					filePath += callOptions.appId + fileExt;
				}
	
				fs.writeFile(filePath, data, 'binary', function(writeErr)
				{
					if(writeErr)
					{
						err.b = true;
						err.msg += writeErr;
						cb(err, filePath);
					} else
					{
						cb(err, filePath);
					}
				});
			} else
			{
				cb(err, filePath);
			}
		});
    };

	this.createStandaloneBuild = function()
	{
	
	};

    /**
     * Bakes out the specified game path, NOT CURRENTLY IMPLEMENTED
	 *
	 * options:
	 * - appId
	 * - stageId
	 * - localGamePath
	 * - toolPath
	 * - destPath
     */
    this.bakeGamePath = function(options, cb)
    {
        //console.log("###########bakeGamePath########");
        //console.log(options);

        var error = { msg: 'bakeGamePath failed:\n', b: false };
        var responseData = {};
           
        // generate the bin directory, as well as make sure it exists
        var dir = this.directory;
        var dstBin = dir(options.destPath);
      
		if(options.appId)
			dir(dstBin += '/' + options.appId);
        
		if(options.stageId)
			dir(dstBin += '/' + options.stageId);
        
		var jakejsPath = path.join(process.cwd(), options.toolPath, '/jake/lib/jake.js');
        var jakeFilePath = path.join(process.cwd(), options.toolPath, '/prepare/Jakefile');
        //var args = [jakejsPath, '-f', jakeFilePath, 'build', 'generateArchives=true', 'jslint=false'];
		var args = [jakejsPath, '-f', jakeFilePath, 'build',
            'generateArchives='+options.generateArchives,
            'jslint='+options.jslint,
            'androidResize='+options.androidResize
            ];
        var jake = spawn('node', args, { 'cwd': options.localGamePath } );
		
		var outData = '';
		var errorData = '';
        jake.stdout.on('data', function(data)
        {
			console.log(data.toString());
            outData += data;
        });
		
		jake.stderr.on('data', function(data)
		{
			errorData += data;
		});
        
        jake.on('exit', (function(code)
        {
            if(code === 0)
            {
                this.clearPath(dstBin, (function(success)
                {
                    if(success)
                    {
                       
                        fileUtils.copyDirectory(options.localGamePath + '/build', dstBin);
                        
                        this.createBundle(dstBin, function(success)
                        {
                            error.b = !success;
                            responseData['bakedGamePath'] = dstBin + '/build.zip';
                            cb(error, responseData);
                        });

                    } else
                    {
						
                        error.b = true;
                        cb(error);
                    }
                }).bind(this));
            } else
			{
				error.b = true;
				error.msg += errorData;
				cb(error);
			}
        }).bind(this));
    };
    
    this.clearPath = function(clearPath, cb)
    {
        var rm = spawn('rm', ['-r', clearPath]);
        
        var out = '';
        var error = '';
        rm.stdout.on('data', function(data)
        {
            out += data;
        });
        
        rm.stderr.on('data', function(data)
        {
            error += data;
        });
        
        rm.on('exit', function(code)
        {
            if(code !== 0)
            {    
                console.log('error');
                console.log(error);
            }
                
            cb(code === 0);
        });
    };
    
    this.createBundle = function(srcPath, cb)
    {
        var child = exec('zip -r build.zip *', { 'cwd': srcPath }, function(error, stdout, stderror)
        {
			if(error)
			{
				console.log('out\n' + stdout);
				console.log('stderror\n' + stderror);
				console.log('zip error\n' + error);
            }
			
			cb(error == null);
        });
    };
    
    this.directory = function(dirPath)
    {
        try{ fs.mkdirSync(dirPath, 0777); } catch(err) {}
        
        return dirPath;
    };
};