package anim;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.util.Vector;
import java.io.*;
import org.w3c.dom.*;

public class AniFrame implements Cloneable
{
	public String name = "";
	public int[] colBox = new int[4];
	public int[] attackBox = new int[4];
	public int duration;
	public Vector sprites = new Vector();

	public AniFrame() {
		duration = 1;
	}

    public String getName(int moduleSelId)
    {
        if (moduleSelId < 0 || !includeModule(moduleSelId))
            return "      "+name;
        return "["+moduleSelId+"]"+name;
    }
    public boolean includeModule(int moduleId)
    {
        for(int i = 0; i < sprites.size(); i++)
        {
            if (((Sprite)sprites.elementAt(i)).idModule == moduleId)
                return true;
        }
        return false;
    }

	public Object clone()
	{
		AniFrame frm = new AniFrame();
		frm.duration = duration;
		frm.attackBox = (int[])attackBox.clone();
		frm.colBox = (int[])colBox.clone();
		frm.name = name;
		Vector spts = new Vector();
		for(int i = 0; i < sprites.size(); i++)
			spts.addElement(((Sprite)sprites.elementAt(i)).clone());
		frm.sprites = spts;
		return frm;
	}

	public void exportXML(Document document, Element parent)
	{
		int i;
		Element e = document.createElement("Frame");
		parent.appendChild(e);
		e.setAttribute("name", name);
		e.setAttribute("cl", String.valueOf(colBox[0]));
		e.setAttribute("ct", String.valueOf(colBox[1]));
		e.setAttribute("cr", String.valueOf(colBox[2]));
		e.setAttribute("cb", String.valueOf(colBox[3]));

		e.setAttribute("al", String.valueOf(attackBox[0]));
		e.setAttribute("at", String.valueOf(attackBox[1]));
		e.setAttribute("ar", String.valueOf(attackBox[2]));
		e.setAttribute("ab", String.valueOf(attackBox[3]));

//		e.setAttribute("duration", String.valueOf(duration));

		for(i = 0; i < sprites.size(); i++)
		{
			((Sprite)sprites.elementAt(i)).exportXML(document, e);
		}
	}

	public static AniFrame fromXML(Element e, Animation anim)
	{
		int i;
		AniFrame frm = new AniFrame();
		NodeList nl;
		String str;

		frm.name = e.getAttribute("name");
		frm.colBox[0] = Integer.parseInt(e.getAttribute("cl"));
		frm.colBox[1] = Integer.parseInt(e.getAttribute("ct"));
		frm.colBox[2] = Integer.parseInt(e.getAttribute("cr"));
		frm.colBox[3] = Integer.parseInt(e.getAttribute("cb"));

		frm.attackBox[0] = Integer.parseInt(e.getAttribute("al"));
		frm.attackBox[1] = Integer.parseInt(e.getAttribute("at"));
		frm.attackBox[2] = Integer.parseInt(e.getAttribute("ar"));
		frm.attackBox[3] = Integer.parseInt(e.getAttribute("ab"));

		str = e.getAttribute("duration");

		if(str != null && str.length() > 0)
		{
			frm.duration = Integer.parseInt(e.getAttribute("duration"));
		}
		else
		{
			frm.duration = 1;
		}

		nl = e.getElementsByTagName("Sprite");
		frm.sprites = new Vector(nl.getLength());
		for(i = 0; i < nl.getLength(); i++)
		{
			frm.sprites.add(Sprite.fromXML((Element)nl.item(i), anim));
		}
		return frm;
	}

	public void exportForBrew(DataOutputStream os)
		throws IOException
	{
		int i;
		int n = 4 + 1 + 1 + sprites.size() * 4;
		os.writeByte(n & 0xff);
		os.writeByte(n >> 8);
		os.writeByte(duration);
		os.writeByte(sprites.size());
		for(i = 0; i < colBox.length; i++)
		{
			os.writeByte(colBox[i]);
		}
		for(i = 0; i < sprites.size(); i++)
		{
			((Sprite)sprites.elementAt(i)).exportForBrew(os);
		}
	}

	public static AniFrame createFromAni(DataInputStream is, Animation anim)
		throws IOException
	{
		int i, n;
		AniFrame frm = new AniFrame();

		frm.name = is.readUTF();
		frm.duration = is.readInt();
		frm.colBox = new int[is.readInt()];
		for(i = 0; i < frm.colBox.length; i++)
		{
			frm.colBox[i] = is.readInt();
		}
		n = is.readInt();
		frm.sprites = new Vector(n);
		for(i = 0; i < n; i++)
		{
			frm.sprites.addElement(Sprite.createFromAni(is, anim));
		}
		return frm;
	}

	public void Scale(float f)
	{
		int i;
		for(i = 0; i < sprites.size(); i++)
		{
			((Sprite)sprites.elementAt(i)).Scale(f);
		}
		colBox[0] *= f;
		colBox[1] *= f;
		colBox[2] *= f;
		colBox[3] *= f;
	}
	public boolean isEqual(AniFrame dst, boolean bCheckName)
	{
		int i;

		for(i = 0; i < attackBox.length; i++)
		{
			if(dst.attackBox[i] != attackBox[i]) return false;
		}
		for(i = 0; i < colBox.length; i++)
		{
			if(dst.colBox[i] != colBox[i]) return false;
		}
		if(bCheckName && name.compareTo(dst.name) != 0) return false;
		if(dst.duration != duration) return false;
		if(dst.sprites.size() != sprites.size()) return false;
		for(i = 0; i < sprites.size(); i++)
		{
			if(!((Sprite)sprites.get(i)).isEqual((Sprite)dst.sprites.get(i)))
			   return false;
		}
		return true;
	}

	boolean isEqual(AniFrame dst)
	{
		int i;

		for(i = 0; i < attackBox.length; i++)
		{
			if(dst.attackBox[i] != attackBox[i]) return false;
		}
		for(i = 0; i < colBox.length; i++)
		{
			if(dst.colBox[i] != colBox[i]) return false;
		}
		if(name.compareTo(dst.name) != 0) return false;
		if(dst.duration != duration) return false;
		if(dst.sprites.size() != sprites.size()) return false;
		for(i = 0; i < sprites.size(); i++)
		{
			if(!((Sprite)sprites.get(i)).isEqual((Sprite)dst.sprites.get(i)))
			   return false;
		}
		return true;
	}
}
