/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.utils;

import javax.microedition.lcdui.Graphics;

/**
 * Interface to abstract a Screens Functionality 
 */
public interface Screen{
	public void paint(Graphics g);
	public void update(); 
}
