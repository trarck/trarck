package com.motionwelder.fontdemo.screens;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.motionwelder.fontdemo.MainCanvas;
import com.motionwelder.fontdemo.MainMidlet;
import com.motionwelder.fontdemo.utils.GenericImageTextRenderableScreen;
import com.motionwelder.fontdemo.utils.Key;

public class InfoAboutCplScreen extends GenericImageTextRenderableScreen{
	
	public InfoAboutCplScreen(){
		Image image1=null,image2=null; 
		try{
			image1 = Image.createImage("/fontshow.png");
			image2 = Image.createImage("/fontuse.png");
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		// append string and image
		append("CustomFont.java shows you");
		append("how to load cpl file using");
		append("MCPLReader java and use it");
		append("to read cordinate of");
		append("characters in font strip as");
		append("shown below");
		append(image1);
		append("You can optimized size of");
		append("cpl by saving, cordinates");
		append("which is required");
		append("For example, lets consider");
		append("font, in which width and");
		append("height for all the character");
		append("is constant");
		append("In such screnario you can");
		append("only export X,Y as shown");
		append("below.");
		append(image2);
		calculateScreenHeight();
	}
	
	public void paint(Graphics g){
		super.paint(g);
		
		MainCanvas.drawCommands(g,"","Exit");
	}
	
	public void update(){
		super.update();
		
		if((MainCanvas.keyPressed&(Key.SOFT_R))!=0 ){
			MainMidlet.exitApp();
			return;
		}
	}
}
