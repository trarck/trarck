function getActiveLayerID() {   
    var ref = new ActionReference();   
    ref.putProperty( charIDToTypeID("Prpr") , charIDToTypeID( "LyrI" ));   
    ref.putEnumerated( charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt") );  
	return executeActionGet(ref).getInteger( stringIDToTypeID( "layerID" ) );  
}