/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.screens;

import javax.microedition.lcdui.Graphics;

import com.motionwelder.animationdemo.MainCanvas;
import com.motionwelder.animationdemo.MainMidlet;
import com.motionwelder.animationdemo.ResourceLoader;
import com.motionwelder.animationdemo.utils.Key;
import com.motionwelder.animationdemo.utils.Screen;
import com.studio.motionwelder.MSimpleAnimationPlayer;
import com.studio.motionwelder.MSpriteData;
import com.studio.motionwelder.MSpriteLoader;

public class AnimationViewerScreen implements Screen{
	
	MSimpleAnimationPlayer animationPlayer;
	private MSpriteData animationData;
	
	/** Animation Constructor */
	public AnimationViewerScreen(){
		try{
			animationData = MSpriteLoader.loadMSprite("/animationsuite/animationsuite.anu", false, ResourceLoader.getInstance());
		}catch (Exception e) {
			System.out.println("Error loading animationsuite anu " + e);
		}
		
		/** Creating Player using animation data*/
		animationPlayer = new MSimpleAnimationPlayer(animationData,MainMidlet.getCanvasInstance().getWidth()>>1,MainMidlet.getCanvasInstance().getHeight()>>1);
		animationPlayer.setLoopOffset(0);
		animationPlayer.setAnimation(0);
	}
	
	/** boolean to decide whether to paint left and right arrow */
	boolean paintLeftArrow=true;
	boolean paintRightArrow=true;
	
	/** Paint Function */
	public void paint(Graphics g){
		// show arrows
		g.setColor(0xffffff);
		if(paintLeftArrow){
			g.drawString("<",15,10,17);
		}else{
			paintLeftArrow = true;
		}
		
		if(paintRightArrow){
			g.drawString(">",MainMidlet.getCanvasInstance().getWidth()-15,10,17);
		}else{
			paintRightArrow = true;
		}
		
		g.drawString("Click left/right, to view",MainMidlet.getCanvasInstance().getWidth()>>1,MainMidlet.getCanvasInstance().getHeight()-40,17);
		g.drawString("other animation",MainMidlet.getCanvasInstance().getWidth()>>1,MainMidlet.getCanvasInstance().getHeight()-25,17);
		
		animationPlayer.drawFrame(g);
		
	}

	/** Update Function */
	public void update(){
		if((MainCanvas.keyPressed&(Key.SOFT_R))!=0 ){
			MainMidlet.exitApp();
			return;
		}
			
		// changing animation based on key pressed
		if((MainCanvas.keyPressed&Key.RIGHT)!=0 ){
			if(animationPlayer.getAnimation() >= animationPlayer.getAnimationCount()-1){
				animationPlayer.setAnimation(0);
			} else {
				animationPlayer.setAnimation(animationPlayer.getAnimation()+1);
			}
			paintRightArrow = false;
		} else if((MainCanvas.keyPressed&Key.LEFT)!=0 ){
			if(animationPlayer.getAnimation()<=0){
				animationPlayer.setAnimation(animationPlayer.getAnimationCount()-1);
			} else {
				animationPlayer.setAnimation(animationPlayer.getAnimation()-1);
			}
			paintLeftArrow = false;
		} else {
			animationPlayer.update();
		}
	}
}
