/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreeziidaemon@yahoo.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.blogspot.com
 * 
*/

//This file inserts the script files into the HTML (main.html)

//Varibles
var scriptsrc=new Array();
scriptsrc[0]='global.js';
scriptsrc[1]='create.js';
scriptsrc[2]='utils.js';
scriptsrc[3]='engine.js';
scriptsrc[4]='preload.js';
scriptsrc[5]='actions.js';
scriptsrc[6]='language.js';
scriptsrc[7]=SelectScreen();

//Insert the files in the HEAD of the HTML
for(var i=0;i<scriptsrc.length;i++)
{
	script=document.createElement("script");
	script.language="Javascript";
	script.type="text/javascript";
	script.src="js/"+scriptsrc[i];

	var head = document.getElementsByTagName('head').item(0);
	head.appendChild(script);
}

//Select the screen file to load
function SelectScreen()
{
	Varsfrom=location.search.substr(1).split("&");//Take the first parameter
    
	this.screenjs='screens/title.js'; //By default it's the title screen
    
    if(Varsfrom[0]!="")
    {
      this.screenjs='screens/'+Varsfrom[0]+'.js';
    }
    
    return this.screenjs;
}
