package com.motionwelder.fontdemo;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;

import com.motionwelder.fontdemo.screens.SplashScreen;
import com.motionwelder.fontdemo.utils.Screen;
import com.motionwelder.fontdemo.utils.Utils;

public class MainCanvas extends Canvas implements Runnable{

	public static int keyPressed    	= 0;   // keyPressed in this paint cycle
	public static int keyReleased   	= 0;   // keyPressed in this paint cycle

	public static int keyKeptPressed 	= 0;  // keyKept pressed

	// temp key events
	int currentKeyPressed  = 0;
	int currentKeyReleased = 0;

	private static Screen currentScreen;

	public MainCanvas(){
		setFullScreenMode(true);

		//initScreen(SCREEN_LOGO_MONGO);
		switchScreen(new SplashScreen());

		new Thread(this).start();
	}

	public void run(){
		try{

			long time;


			while (true) {
				time = System.currentTimeMillis();

				boolean repaintScreen = requestRepaint || requestFastRepaint;
				boolean doNotSleep=requestFastRepaint;

				// update key event
				requestRepaint     = false;
				requestFastRepaint = false;

				updateKeyEvent();
				if(currentKeyPressed!=0 || currentKeyReleased!=0){
					repaintScreen = true;
				}

				repaintScreen = true;
				if(repaintScreen){
					repaint();
					serviceRepaints();
				}

				doNotSleep = doNotSleep || (currentKeyPressed!=0 || currentKeyReleased!=0);

				if(doNotSleep){
					continue;
				}

				long timeTakenForPainting = System.currentTimeMillis() - time;
				if(timeTakenForPainting < 100){
					Thread.sleep(100-timeTakenForPainting);
				}
			}
		}catch (Exception e){
			System.out.println("Error " + e);	
		}
	}

	private static boolean requestRepaint;
	private static boolean requestFastRepaint;
	public static void requestRepaint(){
		requestRepaint = true;
	}

	public static void requestFastRepaint(){
		requestFastRepaint = true;
	}

	protected void keyPressed(int keyCode){
		int myKey = Utils.getKeyMask(keyCode);
		currentKeyPressed |= myKey;
	}

	protected void keyReleased(int keyCode){
		int myKey = Utils.getKeyMask(keyCode);
		currentKeyReleased |= myKey;
	}

	void updateKeyEvent(){
		keyPressed  = currentKeyPressed;
		keyReleased = currentKeyReleased;

		keyKeptPressed |=  currentKeyPressed;    // adding   all the key pressed into key KeptPressed
		keyKeptPressed &= ~currentKeyReleased;   // removing all the key released frm key Kept Pressed

		//reinitalizing the keys
		currentKeyPressed  = 0;
		currentKeyReleased = 0;
	}

	public static Font font = Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_SMALL);

	public void paint(Graphics g){
		g.setColor(0x314754);
		g.fillRect(0,0,MainMidlet.getCanvasInstance().getWidth(),MainMidlet.getCanvasInstance().getHeight());
		g.setFont(font);
		currentScreen.update();
		currentScreen.paint(g);
	}

	public static void switchScreen(Screen s){
		currentScreen = s;
	}

	public static void drawCommands(Graphics g,String str1,String str2){
		CustomFont.drawString(g, str1, 5, MainMidlet.getCanvasInstance().getHeight()-10, CustomFont.ALIGN_LEFT);
		CustomFont.drawString(g, str2, MainMidlet.getCanvasInstance().getWidth()-5, MainMidlet.getCanvasInstance().getHeight()-10, CustomFont.ALIGN_RIGHT);
	}
}

