//
//  main.m
//  MapLoader
//
//  Created by trarck trarck on 11-11-10.
//  Copyright yitengku.com 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	#if (TARGET_OS_EMBEDDED || TARGET_OS_IPHONE)
	NSLog(@"test:in iphone");
	#elif TARGET_OS_MAC
	NSLog(@"test:in mac");
	#endif
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"MapLoaderAppDelegate");
	[pool release];
	
	return retVal;
}
