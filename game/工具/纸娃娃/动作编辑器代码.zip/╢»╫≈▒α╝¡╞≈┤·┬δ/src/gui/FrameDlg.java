package gui;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import anim.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

public class FrameDlg extends Dialog implements ActionListener, ItemListener, TextListener, AdjustmentListener, WindowListener
{
    Animation m_actor, backup, m_partyActor;
    List sptList, imgList;
    Image[] m_image, m_partyImage;
    AniFrame m_frame, m_partyFrame;
    TextField fldDuration;
    TextField fldColLeft, fldColTop, fldColRight, fldColBottom, fldName;
    TextField[] fldAttack = new TextField[4];
    Checkbox cbxShowGrid, cbxShowCol;
    ScrollPane leftPanel;
    ScrollPane imagePanel;

    int moduleToAdd;
    int curFrame;
    FrameCanvas frmCanvas;
    ImgCanvas imgCanvas;
    Scrollbar bar;
    Label lbFrameId, lbCursorPos;
    int[] cbcol = new int[4];
    int[] cbAttack = new int[4];

    public FrameDlg(Frame owner, Animation _actor, Animation _partyActor, Image[] img, Image[] partyImg, int idFrame)
    {
        super(owner, "Frame Window", true);
        m_actor = _actor;
        m_partyActor = _partyActor;
        curFrame = idFrame;
        m_frame = m_actor.getFrame(idFrame);
        GetPartyFrame(idFrame);
        int i;
        m_image = new Image[img.length];
        for (i = img.length - 1; i >= 0; i--)
            m_image[i] = img[i];
        if (partyImg != null)
        {
            m_partyImage = new Image[img.length];
            for (i = img.length - 1; i >= 0; i--)
                m_partyImage[i] = partyImg[i];
        }
        Button btn;
        setSize(1140, 690);

        centerOnParent(owner);
////////////////////////////////////////////////////////////////////////////////
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        setLayout(gridbag);

        leftPanel = new ScrollPane();
        leftPanel.setSize(700, 540);
        c.fill = GridBagConstraints.BOTH;
        c.gridheight = 3;
        gridbag.setConstraints(leftPanel, c);
        add(leftPanel);
        frmCanvas = new FrameCanvas();
        leftPanel.add(frmCanvas);
////////////////////////////////////////////////////////////////////////////////
        imagePanel = new ScrollPane();
        imagePanel.setSize(280, 300);
        c.gridx = c.RELATIVE;
//        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridheight = 1;
        gridbag.setConstraints(imagePanel, c);
        add(imagePanel);
        imgCanvas = new ImgCanvas();
        imagePanel.add(imgCanvas);
////////////////////////////////////////////////////////////////////////////////
        Panel imgListPanel = new Panel(new BorderLayout());
        c.gridwidth = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(imgListPanel, c);
        add(imgListPanel);
        imgList = new List(14);
        imgList.addActionListener(this);
        imgListPanel.add(imgList);

        Panel imgBtnPanel = new Panel(new GridLayout(1, 1));
        imgListPanel.add(imgBtnPanel, "South");
        btn = new Button("Switch");
        btn.addActionListener(this);
        imgBtnPanel.add(btn);
////////////////////////////////////////////////////////////////////////////////
        c.gridwidth = 1;
        sptList = new List(14);
        sptList.setMultipleMode(true);
        sptList.setSize(100, 30);
        sptList.addItemListener(this);
        gridbag.setConstraints(sptList, c);
        add(sptList);
////////////////////////////////////////////////////////////////////////////////
        Panel boxPanel = new Panel(new GridLayout(8, 2));
        c.gridwidth = c.REMAINDER;
        gridbag.setConstraints(boxPanel, c);
        add(boxPanel);

        boxPanel.add(new Label("ColBox L:"));
        fldColLeft = new TextField(Integer.toString(m_frame.colBox[0]));
        fldColLeft.addTextListener(this);
        boxPanel.add(fldColLeft);
        boxPanel.add(new Label("ColBox T:"));
        fldColTop = new TextField(Integer.toString(m_frame.colBox[1]));
        fldColTop.addTextListener(this);
        boxPanel.add(fldColTop);
        boxPanel.add(new Label("ColBox R:"));
        fldColRight = new TextField(Integer.toString(m_frame.colBox[2]));
        fldColRight.addTextListener(this);
        boxPanel.add(fldColRight);
        boxPanel.add(new Label("ColBox B:"));
        fldColBottom = new TextField(Integer.toString(m_frame.colBox[3]));
        fldColBottom.addTextListener(this);
        boxPanel.add(fldColBottom);

        boxPanel.add(new Label("AtkBox L:"));
        fldAttack[0] = new TextField(Integer.toString(m_frame.attackBox[0]));
        fldAttack[0].addTextListener(this);
        boxPanel.add(fldAttack[0]);
        boxPanel.add(new Label("AtkBox T:"));
        fldAttack[1] = new TextField(Integer.toString(m_frame.attackBox[1]));
        fldAttack[1].addTextListener(this);
        boxPanel.add(fldAttack[1]);
        boxPanel.add(new Label("AtkBox R:"));
        fldAttack[2] = new TextField(Integer.toString(m_frame.attackBox[2]));
        fldAttack[2].addTextListener(this);
        boxPanel.add(fldAttack[2]);
        boxPanel.add(new Label("AtkBox B:"));
        fldAttack[3] = new TextField(Integer.toString(m_frame.attackBox[3]));
        fldAttack[3].addTextListener(this);
        boxPanel.add(fldAttack[3]);
////////////////////////////////////////////////////////////////////////////////
        Panel infoPanel = new Panel(new GridLayout(4, 2));
        c.gridwidth = c.REMAINDER;
        gridbag.setConstraints(infoPanel, c);
        add(infoPanel);

        infoPanel.add(new Label("Name:"));
        fldName = new TextField(m_frame.name);
        infoPanel.add(fldName);

        fldDuration = new TextField(Integer.toString(m_frame.duration));

        infoPanel.add(new Label("Cursor:"));
        lbCursorPos = new Label("( 0, 0 )");
        infoPanel.add(lbCursorPos);

        cbxShowGrid = new Checkbox("Show Grid");
        cbxShowGrid.setState(true);
        cbxShowGrid.addItemListener(this);
        cbxShowCol = new Checkbox("Show ColBox");
        cbxShowCol.setState(true);
        cbxShowCol.addItemListener(this);
        infoPanel.add(cbxShowGrid);
        infoPanel.add(cbxShowCol);

        lbFrameId = new Label("No. " + Integer.toString(idFrame) + " ");
        lbFrameId.setAlignment(lbFrameId.RIGHT);
        infoPanel.add(lbFrameId);

        bar = new Scrollbar(Scrollbar.HORIZONTAL, idFrame, 24, 0, 24 + m_actor.getFrameCount() - 1);
        bar.setSize(200, 24);
        bar.addAdjustmentListener(this);
        infoPanel.add(bar);
////////////////////////////////////////////////////////////////////////////////
        Panel bpan = new Panel(new GridLayout(2, 8, 2, 2));
        c.gridx = c.RELATIVE;
        c.gridy = c.RELATIVE;
        c.gridwidth = c.REMAINDER;
        c.gridheight = c.REMAINDER;
        gridbag.setConstraints(bpan, c);
        add(bpan);

        btn = new Button("Zoom In");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Copy ColBox");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Flip X");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Rotate");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Move Up");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Zoom In Image");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Cancel");
        btn.addActionListener(this);
        bpan.add(btn);

        btn = new Button("Zoom Out");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Paste ColBox");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Flip Y");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Remove Module");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Move Down");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("Zoom Out Image");
        btn.addActionListener(this);
        bpan.add(btn);
        btn = new Button("OK");
        btn.addActionListener(this);
        bpan.add(btn);

        refreshList();

        backup = m_actor.Clone();
        addWindowListener(this);

        AniStudioFrm.instance.clearHistry();
        AniStudioFrm.instance.pushHistry();
    }

    private void undo()
    {
        if (AniStudioFrm.instance.undoHistry())
        {
            m_actor = AniStudioFrm.instance.m_actor;
            m_frame = m_actor.getFrame(curFrame);
            GetPartyFrame(curFrame);
            refreshAll();
        }
    }

    private void redo()
    {
        if (AniStudioFrm.instance.redoHistry())
        {
            m_actor = AniStudioFrm.instance.m_actor;
            m_frame = m_actor.getFrame(curFrame);
            GetPartyFrame(curFrame);
            refreshAll();
        }
    }
    private void GetPartyFrame(int idFrame)
    {
        if (m_partyActor != null)
        {
            m_partyFrame = m_partyActor.getFrame(idFrame * m_partyActor.getFrameCount() / m_actor.getFrameCount());
        }
    }

    private void centerOnParent(Component comp)
    {
        setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2,
                    comp.getLocation().y + (comp.getSize().height - getSize().height) / 2);
    }

    public void actionPerformed(java.awt.event.ActionEvent actionEvent)
    {
        String s = actionEvent.getActionCommand();
        if (s == "OK")
        {
            saveAll();
            AniStudioFrm.instance.refresh();
            dispose();
        }
        else if (s == "Zoom In")
        {
            frmCanvas.zoomIn();
        }
        else if (s == "Zoom Out")
        {
            frmCanvas.zoomOut();
        }
        else if (s == "Zoom In Image")
        {
            imgCanvas.zoomIn();
        }
        else if (s == "Zoom Out Image")
        {
            imgCanvas.zoomOut();
        }
        else if (s == "Move Up")
        {
            int i, id, ids[] = sptList.getSelectedIndexes();
            if (ids.length > 0 && ids[0] > 0)
            {
                boolean sel;
                for (i = 0; i < ids.length; i++)
                {
                    id = ids[i];
                    sel = sptList.isIndexSelected(id - 1);
                    Sprite spt = (Sprite)m_frame.sprites.elementAt(id - 1);
                    m_frame.sprites.setElementAt(m_frame.sprites.elementAt(id), id - 1);
                    m_frame.sprites.setElementAt(spt, id);
                    sptList.select(id - 1);
                    if (sel)
                    {
                        sptList.select(id);
                    }
                    else
                    {
                        sptList.deselect(id);
                    }
                }
                frmCanvas.repaint();
            }
        }
        else if (s == "Move Down")
        {
            int id, i, ids[] = sptList.getSelectedIndexes();
            if (ids.length > 0 && !sptList.isIndexSelected(sptList.getItemCount() - 1))
            {
                boolean sel;
                for (i = ids.length - 1; i >= 0; i--)
                {
                    id = ids[i];
                    sel = sptList.isIndexSelected(id + 1);
                    Sprite spt = (Sprite)m_frame.sprites.elementAt(id + 1);
                    m_frame.sprites.setElementAt(m_frame.sprites.elementAt(id), id + 1);
                    m_frame.sprites.setElementAt(spt, id);
                    sptList.select(id + 1);
                    if (sel)
                    {
                        sptList.select(id);
                    }
                    else
                    {
                        sptList.deselect(id);
                    }
                }
            }
            frmCanvas.repaint();
        }
        else if (s == "Remove Module")
        {
            int i, ids[] = sptList.getSelectedIndexes();
            for (i = ids.length - 1; i >= 0; i--)
            {
                sptList.remove(ids[i]);
                m_frame.sprites.removeElementAt(ids[i]);
            }
            frmCanvas.repaint();
        }
        else if (s == "Flip X")
        {
            int i, ids[] = sptList.getSelectedIndexes();
            for (i = ids.length - 1; i >= 0; i--)
            {
                Sprite spt = (Sprite)m_frame.sprites.elementAt(ids[i]);
                spt.flipX();
                // update module flip info
                m_actor.updateModuleFlip(spt);
            }
            frmCanvas.repaint();
        }
        else if (s == "Flip Y")
        {
            int i, ids[] = sptList.getSelectedIndexes();
            for (i = ids.length - 1; i >= 0; i--)
            {
                Sprite spt = ((Sprite)m_frame.sprites.elementAt(ids[i]));
                spt.flipY();
                // update module flip info
                m_actor.updateModuleFlip(spt);
            }
            frmCanvas.repaint();
        }
        else if (s == "Rotate")
        {
            int i, ids[] = sptList.getSelectedIndexes();
            for (i = ids.length - 1; i >= 0; i--)
            {
                ((Sprite)m_frame.sprites.elementAt(ids[i])).Rotate(90);
            }
            frmCanvas.repaint();
        }
        else if (s == "Copy ColBox")
        {
            cbcol[0] = m_frame.colBox[0];
            cbcol[1] = m_frame.colBox[1];
            cbcol[2] = m_frame.colBox[2];
            cbcol[3] = m_frame.colBox[3];
            cbAttack[0] = m_frame.attackBox[0];
            cbAttack[1] = m_frame.attackBox[1];
            cbAttack[2] = m_frame.attackBox[2];
            cbAttack[3] = m_frame.attackBox[3];
        }
        else if (s == "Paste ColBox")
        {
            m_frame.colBox[0] = cbcol[0];
            m_frame.colBox[1] = cbcol[1];
            m_frame.colBox[2] = cbcol[2];
            m_frame.colBox[3] = cbcol[3];
            m_frame.attackBox[0] = cbAttack[0];
            m_frame.attackBox[1] = cbAttack[1];
            m_frame.attackBox[2] = cbAttack[2];
            m_frame.attackBox[3] = cbAttack[3];
            refreshCol();
            frmCanvas.repaint();
        }
        else if (s == "Cancel")
        {
            windowClosing(null);
        }
        else if (s == "Switch")
        {
            m_actor.setCurImage(imgList.getSelectedIndex());
            imgCanvas.changeImage();
            imgCanvas.repaint();
        }
    }

    private void refreshCol()
    {
        fldColLeft.setText(Integer.toString(m_frame.colBox[0]));
        fldColTop.setText(Integer.toString(m_frame.colBox[1]));
        fldColRight.setText(Integer.toString(m_frame.colBox[2]));
        fldColBottom.setText(Integer.toString(m_frame.colBox[3]));
        fldAttack[0].setText(Integer.toString(m_frame.attackBox[0]));
        fldAttack[1].setText(Integer.toString(m_frame.attackBox[1]));
        fldAttack[2].setText(Integer.toString(m_frame.attackBox[2]));
        fldAttack[3].setText(Integer.toString(m_frame.attackBox[3]));
    }

    private void refreshAll()
    {
        lbFrameId.setText("No. " + Integer.toString(curFrame) + " ");
        fldName.setText(m_frame.name);
        fldDuration.setText(Integer.toString(m_frame.duration));
        refreshCol();
        refreshList();
        frmCanvas.repaint();
    }

    private void saveAll()
    {
        m_frame.duration = Integer.parseInt(fldDuration.getText());
        if (m_frame.duration < 1)
        {
            m_frame.duration = 1;
        }
        m_frame.name = fldName.getText();
    }

    public void itemStateChanged(java.awt.event.ItemEvent itemEvent)
    {
        frmCanvas.repaint();
    }

    public void refreshList()
    {
        int i;

        sptList.removeAll();
        for (i = 0; i < m_frame.sprites.size(); i++)
        {
            sptList.add("Sprite " + i + " (" + ((Sprite)(m_frame.sprites.get(i))).idModule + ")");
        }
        imgList.removeAll();
        for (i = 0; i < m_actor.getImageNum(); i++)
        {
            imgList.add(m_actor.getImageFile(i));
        }
        imgList.select(m_actor.getCurImage());
    }

    public void addSprite(int idMod, int x, int y)
    {
        Sprite spt = new Sprite(idMod, x, y);
        m_frame.sprites.addElement(spt);
        refreshList();
    }

    public void selectAllSprites()
    {
        int i;

        for (i = sptList.getItemCount() - 1; i >= 0; i--)
        {
            sptList.select(i);
        }
        frmCanvas.repaint();
    }

    public void textValueChanged(TextEvent textEvent)
    {
        Object src = textEvent.getSource();
        if (src == fldColLeft)
        {
            m_frame.colBox[0] = Integer.parseInt(fldColLeft.getText());
        }
        else if (src == fldColTop)
        {
            m_frame.colBox[1] = Integer.parseInt(fldColTop.getText());
        }
        else if (src == fldColRight)
        {
            m_frame.colBox[2] = Integer.parseInt(fldColRight.getText());
        }
        else if (src == fldColBottom)
        {
            m_frame.colBox[3] = Integer.parseInt(fldColBottom.getText());
        }
        else if (src == fldAttack[0])
        {
            m_frame.attackBox[0] = Integer.parseInt(fldAttack[0].getText());
        }
        else if (src == fldAttack[1])
        {
            m_frame.attackBox[1] = Integer.parseInt(fldAttack[1].getText());
        }
        else if (src == fldAttack[2])
        {
            m_frame.attackBox[2] = Integer.parseInt(fldAttack[2].getText());
        }
        else if (src == fldAttack[3])
        {
            m_frame.attackBox[3] = Integer.parseInt(fldAttack[3].getText());
        }
        frmCanvas.repaint();
    }

    public void adjustmentValueChanged(java.awt.event.AdjustmentEvent adjustmentEvent)
    {
        saveAll();
        curFrame = bar.getValue();
        m_frame = m_actor.getFrame(curFrame);
        GetPartyFrame(curFrame);
        AniStudioFrm.instance.frameList.select(curFrame);
        refreshAll();
    }

    class FrameCanvas extends Canvas implements MouseListener, MouseMotionListener, KeyListener
    {
        final static int REF_X = 256;
        final static int REF_Y = 256;
        final static int MAX_W = 512;
        final static int MAX_H = 512;

        final static int MAX_ZOOM = 5;
        int zoomLevel;
        Image bimg;
        int mouseModule;
        Point mousePos;
        boolean isFirstPaint = true;

        public FrameCanvas()
        {
            mouseModule = -1;
            zoomLevel = 3;
            bimg = AniStudioFrm.instance.createImage(MAX_W * zoomLevel, MAX_H * zoomLevel);
            setSize(MAX_W * MAX_ZOOM, MAX_H * MAX_ZOOM);
            addMouseMotionListener(this);
            addMouseListener(this);
            addKeyListener(this);
        }

        public void update(Graphics g)
        {
            paint(g);
        }

        private void drawGrid(Graphics g)
        {
            int i;
            g.setColor(AnimationEditor.getGridColor());
            for (i = 0; i < MAX_W; i += 4)
            {
                g.drawLine(i * zoomLevel, 0, i * zoomLevel, MAX_H * zoomLevel);
            }
            for (i = 0; i < MAX_H; i += 4)
            {
                g.drawLine(0, i * zoomLevel, MAX_W * zoomLevel, i * zoomLevel);
            }
            g.setColor(AnimationEditor.getCoordColor());
            g.drawLine(REF_X * zoomLevel, 0, REF_X * zoomLevel, MAX_H * zoomLevel);
            g.drawLine(0, REF_Y * zoomLevel, MAX_W * zoomLevel, REF_X * zoomLevel);
        }

        public void paint(Graphics g)
        {
            if (isFirstPaint)
            {
                leftPanel.getHAdjustable().setValue(450);
                leftPanel.getVAdjustable().setValue(450);
                isFirstPaint = false;
            }
            int i, n;
            Graphics bg = bimg.getGraphics();
            Sprite spt;
            // draw background
            bg.setColor(AnimationEditor.getBGColor());
            bg.fillRect(0, 0, bimg.getWidth(null), bimg.getHeight(null));
            if (m_partyFrame != null)
            {
                n = m_partyFrame.sprites.size();
                for (i = 0; i < n; i++)
                {
                    spt = (Sprite)m_partyFrame.sprites.elementAt(i);
                    drawSprite(bg, spt, (Module)m_partyActor.modules.elementAt(spt.idModule), m_partyImage[((Module)m_partyActor.modules.elementAt(spt.idModule)).idImage], REF_X, REF_Y, zoomLevel, false);
                }
            }
            n = m_frame.sprites.size();
            for (i = 0; i < n; i++)
            {
                spt = (Sprite)m_frame.sprites.elementAt(i);
                drawSprite(bg, spt, (Module)m_actor.modules.elementAt(spt.idModule), m_image[((Module)m_actor.modules.elementAt(spt.idModule)).idImage], REF_X, REF_Y, zoomLevel, sptList.isIndexSelected(i));
            }
            if (mouseModule >= 0)
            {
                drawModule(bg, mouseModule, mousePos.x * zoomLevel, mousePos.y * zoomLevel, zoomLevel);
            }
            if (cbxShowGrid.getState())
            {
                drawGrid(bg);
            }
            if (cbxShowCol.getState())
            {
                bg.setColor(AnimationEditor.getColColor());
                bg.drawRect((m_frame.colBox[0] + REF_X) * zoomLevel, (m_frame.colBox[1] + REF_Y) * zoomLevel,
                            (m_frame.colBox[2] - m_frame.colBox[0]) * zoomLevel, (m_frame.colBox[3] - m_frame.colBox[1]) * zoomLevel);
                bg.setColor(AnimationEditor.getAttackColr());
                bg.drawRect((m_frame.attackBox[0] + REF_X) * zoomLevel, (m_frame.attackBox[1] + REF_Y) * zoomLevel,
                            (m_frame.attackBox[2] - m_frame.attackBox[0]) * zoomLevel, (m_frame.attackBox[3] - m_frame.attackBox[1]) * zoomLevel);
            }
            g.drawImage(bimg, 0, 0, null);
        }

        public void drawSprite(Graphics g, Sprite spt, Module mod, Image img, int x, int y, int scale, boolean isSelected)
        {
            Graphics2D g2d = (Graphics2D)g;

            AffineTransform origXform = g2d.getTransform();
            AffineTransform newXform = (AffineTransform)(origXform.clone());
            newXform.scale(scale, scale);
            newXform.translate(x, y);
            newXform.concatenate(spt.trans);
            g2d.setTransform(newXform);
            g2d.drawImage(img, 0, 0, mod.w, mod.h, mod.x, mod.y, mod.x + mod.w, mod.y + mod.h, null);

            if (isSelected)
            {
                g.setXORMode(new Color(0xffffff));
                g.fillRect(0, 0, mod.w, mod.h);
                g.setPaintMode();
            }
            g2d.setTransform(origXform);
        }

        public void drawModule(Graphics g, int id, int x, int y, int scale)
        {
            Module mod = (Module)m_actor.modules.elementAt(id);
            g.drawImage(m_image[mod.idImage], x, y, mod.w * scale + x, mod.h * scale + y, mod.x, mod.y, mod.w + mod.x, mod.h + mod.y, null);
        }

        public void zoomIn()
        {
            if (zoomLevel < MAX_ZOOM)
            {
                zoomLevel++;
                setSize(MAX_W * zoomLevel, MAX_H * zoomLevel);
                bimg = createImage(MAX_W * zoomLevel, MAX_H * zoomLevel);
                leftPanel.getHAdjustable().setValue(180*zoomLevel);
                leftPanel.getVAdjustable().setValue(180*zoomLevel);
            }
        }

        public void zoomOut()
        {
            if (zoomLevel > 1)
            {
                zoomLevel--;
                setSize(MAX_W * zoomLevel, MAX_H * zoomLevel);
                bimg = createImage(MAX_W * zoomLevel, MAX_H * zoomLevel);
                leftPanel.getHAdjustable().setValue(180*zoomLevel);
                leftPanel.getVAdjustable().setValue(180*zoomLevel);
            }
        }

        void LP2DP(Point p)
        {
            p.x /= zoomLevel;
            p.y /= zoomLevel;
        }

        public void mouseClicked(MouseEvent e)
        {
        }

        public void mouseEntered(MouseEvent e)
        {
            mouseModule = moduleToAdd;
        }

        public void mouseExited(MouseEvent e)
        {
            mouseModule = -1;
        }

        public void mousePressed(MouseEvent e)
        {
            Point p = e.getPoint();
            LP2DP(p);
            mousePos = p;
            if (mouseModule >= 0)
            {
                if ((e.getModifiers() & e.BUTTON1_MASK) != 0)
                {
                    addSprite(mouseModule, p.x - REF_X, p.y - REF_Y);
                }
                mouseModule = -1;
                moduleToAdd = -1;
                int i;
                for (i = sptList.getItemCount() - 1; i >= 0; i--)
                {
                    sptList.deselect(i);
                }
                sptList.select(sptList.getItemCount() - 1);
            }
            else
            {
                if ((e.getModifiers() & e.BUTTON1_MASK) != 0)
                {
                    int i;
                    int curItem = itemFromPoint(p.x, p.y);
                    if (curItem >= 0)
                    {
                        if ((e.getModifiers() & e.CTRL_MASK) != 0)
                        {
                            if (sptList.isIndexSelected(curItem))
                            {
                                sptList.deselect(curItem);
                            }
                            else
                            {
                                sptList.select(curItem);
                            }
                        }
                        else
                        {
                            if (!sptList.isIndexSelected(curItem))
                            {
                                for (i = sptList.getItemCount() - 1; i >= 0; i--)
                                {
                                    sptList.deselect(i);
                                }
                                sptList.select(curItem);
                            }
                        }
                    }
                    else
                    {
                        for (i = sptList.getItemCount() - 1; i >= 0; i--)
                        {
                            sptList.deselect(i);
                        }
                    }
                }
                else
                {
                    if ((e.getModifiers() & e.SHIFT_MASK) != 0)
                    {
                        m_frame.attackBox[0] = p.x - REF_X;
                        m_frame.attackBox[1] = p.y - REF_Y;
                        m_frame.attackBox[2] = p.x - REF_X;
                        m_frame.attackBox[3] = p.y - REF_Y;
                    }
                    else
                    {
                        m_frame.colBox[0] = p.x - REF_X;
                        m_frame.colBox[1] = p.y - REF_Y;
                        m_frame.colBox[2] = p.x - REF_X;
                        m_frame.colBox[3] = p.y - REF_Y;
                    }
                    refreshCol();
                }
            }
            repaint();
        }

        public void mouseReleased(MouseEvent e)
        {
            AniStudioFrm.instance.pushHistry();
        }

        public int itemFromPoint(int x, int y)
        {
            int i;
            Sprite spt;
            Module mod;
            Point2D.Double pt = new Point2D.Double(x - REF_X, y - REF_Y);
            Point t = new Point();

            for (i = m_frame.sprites.size() - 1; i >= 0; i--)
            {
                spt = (Sprite)m_frame.sprites.elementAt(i);
                try
                {
                    spt.trans.inverseTransform((Point2D.Double)pt.clone(), t);
                }
                catch (NoninvertibleTransformException e)
                {
                    continue;
                }
                if (t.x < 0 || t.y < 0)
                {
                    continue;
                }
                mod = (Module)m_actor.modules.elementAt(spt.idModule);
                if (t.x >= mod.w || t.y >= mod.h)
                {
                    continue;
                }
                return i;
            }
            return -1;
        }

        public void mouseDragged(MouseEvent e)
        {
            int i;

            Sprite spt;

            Point p = e.getPoint();
            LP2DP(p);
            if ((e.getModifiers() & e.BUTTON1_MASK) != 0)
            {
                for (i = sptList.getItemCount() - 1; i >= 0; i--)
                {
                    if (sptList.isIndexSelected(i))
                    {
                        spt = (Sprite)m_frame.sprites.elementAt(i);
                        spt.Translate(p.x - mousePos.x, p.y - mousePos.y);
                    }
                }
            }
            else
            {
                if ((e.getModifiers() & e.SHIFT_MASK) != 0)
                {
                    m_frame.attackBox[2] = p.x - REF_X;
                    m_frame.attackBox[3] = p.y - REF_Y;
                }
                else
                {
                    m_frame.colBox[2] = p.x - REF_X;
                    m_frame.colBox[3] = p.y - REF_Y;
                }
                refreshCol();
            }
            mousePos = p;
            repaint();
        }

        public void mouseMoved(MouseEvent e)
        {
            Point p = e.getPoint();
            LP2DP(p);
            mousePos = p;
            lbCursorPos.setText("( " + (p.x - REF_X) + "," + (p.y - REF_X) + " )");
            if (mouseModule >= 0)
            {
                repaint();
            }
        }

        public void keyPressed(KeyEvent e)
        {
            int[] ids = sptList.getSelectedIndexes();
            Sprite spt;
            int i;

            if (e.getKeyCode() == KeyEvent.VK_Z)
            {
                if (e.getModifiers() == e.CTRL_MASK)
                {
                    undo();
                }
                else if (e.getModifiers() == (e.CTRL_MASK | e.SHIFT_MASK))
                {
                    redo();
                }
                return;
            }

            if (e.getKeyCode() == KeyEvent.VK_DELETE)
            {
                for (i = ids.length - 1; i >= 0; i--)
                {
                    sptList.remove(ids[i]);
                    m_frame.sprites.removeElementAt(ids[i]);
                }
                repaint();
                return;
            }
            if (e.getKeyCode() == KeyEvent.VK_A && (e.getModifiers() & KeyEvent.CTRL_MASK) != 0)
            {
                selectAllSprites();
                return;
            }

            for (i = ids.length - 1; i >= 0; i--)
            {
                spt = (Sprite)m_frame.sprites.elementAt(ids[i]);
                switch (e.getKeyCode())
                {
                case KeyEvent.VK_LEFT:
                    spt.Translate( -1, 0);
                    break;
                case KeyEvent.VK_RIGHT:
                    spt.Translate(1, 0);
                    break;
                case KeyEvent.VK_UP:
                    spt.Translate(0, -1);
                    break;
                case KeyEvent.VK_DOWN:
                    spt.Translate(0, 1);
                    break;
                }
            }
            repaint();
        }

        public void keyReleased(KeyEvent e)
        {
            AniStudioFrm.instance.pushHistry();
        }

        public void keyTyped(KeyEvent e)
        {
        }

    }

    class ImgCanvas extends Canvas implements MouseListener
    {
        final static int MAX_ZOOM = 10;
        int zoomLevel;
        Image scimg, bimg;

        public ImgCanvas()
        {
            moduleToAdd = -1;
            zoomLevel = 2;
            Image tmpImg = m_image[m_actor.getCurImage()];
            scimg = AniStudioFrm.instance.createImage(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
            Graphics g = scimg.getGraphics();
            g.setColor(AnimationEditor.getBGColor());
            g.fillRect(0, 0, scimg.getWidth(null), scimg.getHeight(null));
            g.drawImage(tmpImg, 0, 0, scimg.getWidth(null), scimg.getHeight(null), 0, 0, tmpImg.getWidth(null), tmpImg.getHeight(null), null);
            bimg = AniStudioFrm.instance.createImage(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
            setSize(tmpImg.getWidth(null) * MAX_ZOOM, tmpImg.getHeight(null) * MAX_ZOOM);
            addMouseListener(this);
        }

        public void update(Graphics g)
        {
            paint(g);
        }

        public void paint(Graphics g)
        {
            int i;
            Graphics bg = bimg.getGraphics();
            Module mod;

            int w = scimg.getWidth(null);
            int h = scimg.getHeight(null);
            bg.drawImage(scimg, 0, 0, null);

            if (moduleToAdd >= 0)
            {
                mod = (Module)m_actor.modules.elementAt(moduleToAdd);
                if (mod.idImage == m_actor.getCurImage())
                {
                    bg.setXORMode(new Color(0xffffff));
                    bg.fillRect(mod.x * zoomLevel, mod.y * zoomLevel, mod.w * zoomLevel, mod.h * zoomLevel);
                }
            }
            bg.setColor(AnimationEditor.getGridColor());
            bg.setPaintMode();
            for (i = m_actor.modules.size() - 1; i >= 0; i--)
            {
                mod = (Module)m_actor.modules.elementAt(i);
                if (mod.idImage == m_actor.getCurImage())
                    bg.drawRect(mod.x * zoomLevel, mod.y * zoomLevel, mod.w * zoomLevel - 1, mod.h * zoomLevel - 1);
            }
            g.drawImage(bimg, 0, 0, null);
        }

        public void zoomIn()
        {
            if (zoomLevel < MAX_ZOOM)
            {
                zoomLevel++;
                Image tmpImg = m_image[m_actor.getCurImage()];
                setSize(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
                scimg = createImage(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
                scimg.getGraphics().drawImage(tmpImg, 0, 0, scimg.getWidth(null), scimg.getHeight(null), 0, 0, tmpImg.getWidth(null),
                                              tmpImg.getHeight(null), null);
                bimg = createImage(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
            }
        }

        public void zoomOut()
        {
            if (zoomLevel > 1)
            {
                zoomLevel--;
                Image tmpImg = m_image[m_actor.getCurImage()];
                setSize(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
                scimg = createImage(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
                scimg.getGraphics().drawImage(tmpImg, 0, 0, scimg.getWidth(null), scimg.getHeight(null), 0, 0, tmpImg.getWidth(null),
                                              tmpImg.getHeight(null), null);
                bimg = createImage(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
            }
        }

        public void changeImage()
        {
            moduleToAdd = -1;
            zoomLevel = 2;
            Image tmpImg = m_image[m_actor.getCurImage()];
            scimg = AniStudioFrm.instance.createImage(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
            Graphics g = scimg.getGraphics();
            g.setColor(AnimationEditor.getBGColor());
            g.fillRect(0, 0, scimg.getWidth(null), scimg.getHeight(null));
            g.drawImage(tmpImg, 0, 0, scimg.getWidth(null), scimg.getHeight(null), 0, 0, tmpImg.getWidth(null), tmpImg.getHeight(null), null);
            bimg = AniStudioFrm.instance.createImage(tmpImg.getWidth(null) * zoomLevel, tmpImg.getHeight(null) * zoomLevel);
            setSize(tmpImg.getWidth(null) * MAX_ZOOM, tmpImg.getHeight(null) * MAX_ZOOM);
        }

        void LP2DP(Point p)
        {
            p.x /= zoomLevel;
            p.y /= zoomLevel;
        }

        public void mouseClicked(MouseEvent e)
        {
        }

        public void mouseEntered(MouseEvent e)
        {
        }

        public void mouseExited(MouseEvent e)
        {
        }

        int lastItem;
        public void mousePressed(MouseEvent e)
        {
            Point p = e.getPoint();
            LP2DP(p);
            moduleToAdd = itemFromPoint(p.x, p.y, lastItem);
            lastItem = moduleToAdd;
            if (moduleToAdd >= 0 && (e.getModifiers() & MouseEvent.SHIFT_MASK) != 0)
            {
                int[] ids = sptList.getSelectedIndexes();
                if (ids.length == 1)
                {
                    ((Sprite)m_frame.sprites.elementAt(ids[0])).idModule = moduleToAdd;
                    moduleToAdd = -1;
                }
            }
            frmCanvas.repaint();
            repaint();
        }

        public void mouseReleased(MouseEvent e)
        {
        }
        public int itemFromPoint(int x, int y, int prevId)
        {
            int i;
            Module mod;
            if (prevId >= m_actor.modules.size()) prevId = -1;
            for (i = prevId+1; i < m_actor.modules.size(); i++)
            {
                mod = (Module)m_actor.modules.elementAt(i);
                if (mod.idImage != m_actor.getCurImage())
                    continue;
                if (x >= mod.x && x <= mod.x + mod.w && y >= mod.y && y <= mod.y + mod.h)
                {
                    return i;
                }
            }
            for (i = 0; i <= prevId; i++)
            {
                mod = (Module)m_actor.modules.elementAt(i);
                if (mod.idImage != m_actor.getCurImage())
                    continue;
                if (x >= mod.x && x <= mod.x + mod.w && y >= mod.y && y <= mod.y + mod.h)
                {
                    return i;
                }
            }
            return -1;
        }
    }

    public void windowOpened(WindowEvent e)
    {
    }

    public void windowClosing(WindowEvent e)
    {
        AniStudioFrm.instance.m_actor = backup;
        dispose();
    }

    public void windowClosed(WindowEvent e)
    {
    }

    public void windowIconified(WindowEvent e)
    {
    }

    public void windowDeiconified(WindowEvent e)
    {
    }

    public void windowActivated(WindowEvent e)
    {
    }

    public void windowDeactivated(WindowEvent e)
    {
    }
}
