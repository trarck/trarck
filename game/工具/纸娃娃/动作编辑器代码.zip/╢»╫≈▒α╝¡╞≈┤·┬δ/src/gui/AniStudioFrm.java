package gui;

/**
 * �����༭��������
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import anim.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

public class AniStudioFrm extends Frame implements WindowListener, ActionListener, ItemListener
{
	/** ���а汾ID */
	private static final long serialVersionUID = -4083998080892169L;
	MenuBar mainMenuBar;
	//	Choice actorType;//, imageId;
	List actionList, frameList, imageList;
	//	Checkbox hasMModel;
	Animation m_actor, m_oldactor, m_partyActor;
	//	TextField[] fldImageFile;
	static AniStudioFrm instance;
	Button btnAddFrame, btnFrameUp, btnFrameDown, btnCopyFrame, btnDelFrame, btnAddAction, btnCopyAction, btnDelAction,
			btnMoveUp, btnMoveDown;
	Image[] m_image, m_partyImage;
	String m_filename;
	Vector histry = new Vector();
	int curhistry;
	int frameSelId = -1;

	/*
	 public void refreshActorTypes()
	 {
	 int i;
	 actorType.removeAll();
	 String[] s = AnimationEditor.getActorTypes();
	 for(i = 0; i < s.length; i++)
	 actorType.add(s[i]);
	 for(i = s.length; i < 100; i++)
	 actorType.add("Actor" + i);
	 actorType.select(actor.type);
	 }
	 */
	private static String sTitle = "�����༭��";

	private static String sFile = "�ļ�";
	private static String sNew = "�½�";
	private static String sLoad = "��ȡ";
	private static String sLoadPartyActor = "Load Party Actor";
	private static String sSave = "����";
	private static String sSaveAs = "����Ϊ";
	private static String sImport = "����";
	private static String sExport = "����";
	private static String sAbout = "����";
	private static String sExit = "�˳�";

	private static String sOpmitize = "�Ż�";
	private static String sRemoveUnusedImages = "ɾ��δʹ��ͼƬ";
	private static String sRemoveUnusedModules = "ɾ��δʹ��ͼ��";
	private static String sRemoveUnusedFrames = "ɾ��δʹ����";

	private static String sOptions = "����";
	private static String sScale = "Scale";
	private static String sBGColor = "������ɫ";
	private static String sGridColor = "������ɫ";
	private static String sAxisColor = "��������ɫ";
	private static String sColBoxColor = "��ײ������ɫ";
	private static String sSelectionColor = "Selection Color";
	private static String sFrameDelay = "���ӳ�";
	private static String sEditActorTypes = "Edit Actor Types";

	private static String[] strFileMenu = {
			sFile, sNew, sLoad, sLoadPartyActor, sSave, sSaveAs, sImport, sExport, sAbout, sExit,
	};

	private static String[] strOpmizite = {
			sOpmitize, sRemoveUnusedImages, sRemoveUnusedModules, sRemoveUnusedFrames,
	};

	private static String[] strOptions = {
			sOptions, sScale, sBGColor, sGridColor, sAxisColor, sColBoxColor, sSelectionColor, sFrameDelay,
			sEditActorTypes,
	};

	public AniStudioFrm()
	{
		super(sTitle);

		m_actor = Animation.Create();
		m_oldactor = m_actor.Clone();

		instance = this;
		addNotify();
		mainMenuBar = new MenuBar();

		Menu menu1 = new Menu(strFileMenu[0]);
		for (int i = 1; i < strFileMenu.length; i++)
		{
			if (i == 6 || i == 8 || i == 9)
				menu1.addSeparator();
			menu1.add(strFileMenu[i]);
		}
		menu1.addActionListener(this);
		mainMenuBar.add(menu1);

		Menu menu2 = new Menu(strOpmizite[0]);
		for (int i = 1; i < strOpmizite.length; i++)
		{
			menu2.add(strOpmizite[i]);
		}
		menu2.addActionListener(this);
		mainMenuBar.add(menu2);

		Menu menu3 = new Menu(strOptions[0]);
		for (int i = 1; i < strOptions.length; i++)
		{
			if (i == 8)
				menu3.addSeparator();
			menu3.add(strOptions[i]);
		}
		menu3.addActionListener(this);
		mainMenuBar.add(menu3);

		setMenuBar(mainMenuBar);
		setSize(getInsets().left + getInsets().right + 800, getInsets().top + getInsets().bottom + 600);

		setLocation((getToolkit().getScreenSize().width - getSize().width) / 2,
				(getToolkit().getScreenSize().height - getSize().height) / 2);
		addWindowListener(this);

		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints c = new GridBagConstraints();
		setLayout(gridbag);

		Panel framePenel = new Panel(new BorderLayout());
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1.0;
		gridbag.setConstraints(framePenel, c);
		add(framePenel);

		framePenel.add(new Label("���б�"), "North");
		frameList = new List(32);
		frameList.addActionListener(this);
		frameList.addItemListener(this);
		ActionEvent ae;
		framePenel.add(frameList, "Center");

		Panel frameBtnPanel = new Panel(new GridLayout(3, 2));
		framePenel.add(frameBtnPanel, "South");

		btnAddFrame = new Button("������");
		btnAddFrame.addActionListener(this);
		btnAddFrame.setEnabled(false);
		frameBtnPanel.add(btnAddFrame);

		btnCopyFrame = new Button("������");
		btnCopyFrame.addActionListener(this);
		btnCopyFrame.setEnabled(false);
		frameBtnPanel.add(btnCopyFrame);

		btnFrameUp = new Button("�����ƶ���");
		btnFrameUp.addActionListener(this);
		frameBtnPanel.add(btnFrameUp);

		btnFrameDown = new Button("�����ƶ���");
		btnFrameDown.addActionListener(this);
		frameBtnPanel.add(btnFrameDown);

		btnDelFrame = new Button("ɾ����");
		btnDelFrame.addActionListener(this);
		frameBtnPanel.add(btnDelFrame);

		Panel leftPenel = new Panel(new BorderLayout());
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1.0;
		gridbag.setConstraints(leftPenel, c);
		add(leftPenel);

		leftPenel.add(new Label("�����б�"), "North");
		actionList = new List(32);
		actionList.addActionListener(this);
		leftPenel.add(actionList, "Center");

		frameBtnPanel = new Panel(new GridLayout(3, 2));
		leftPenel.add(frameBtnPanel, "South");

		btnAddAction = new Button("���Ӷ���");
		btnAddAction.addActionListener(this);
		btnAddAction.setEnabled(false);
		frameBtnPanel.add(btnAddAction);
		btnCopyAction = new Button("���ƶ���");
		btnCopyAction.addActionListener(this);
		frameBtnPanel.add(btnCopyAction);
		btnMoveUp = new Button("�����ƶ�����");
		btnMoveUp.addActionListener(this);
		frameBtnPanel.add(btnMoveUp);
		btnMoveDown = new Button("�����ƶ�����");
		btnMoveDown.addActionListener(this);
		frameBtnPanel.add(btnMoveDown);
		btnDelAction = new Button("ɾ������");
		btnDelAction.addActionListener(this);
		btnDelAction.setEnabled(true);
		frameBtnPanel.add(btnDelAction);

		c.weightx = 1.0;
		Panel rightPanel = new Panel(new BorderLayout());
		c.gridwidth = GridBagConstraints.BOTH/*REMAINDER*/;
		gridbag.setConstraints(rightPanel, c);
		add(rightPanel);

		rightPanel.add(new Label("ͼƬ�б�"), "North");
		imageList = new List(32);
		imageList.addActionListener(this);
		rightPanel.add(imageList, "Center");
		Panel imgBtnPanel = new Panel(new GridLayout(4, 1));
		rightPanel.add(imgBtnPanel, "South");
		Button btn = new Button("�༭ͼ��");
		btn.addActionListener(this);
		imgBtnPanel.add(btn);

		//		rightPanel.add(new Label("Actor Type"));

		//		actorType = new Choice();
		//		refreshActorTypes();
		//		rightPanel.add(actorType);

		//		hasMModel = new Checkbox("MechModel");
		//		rightPanel.add(hasMModel);

		btn = new Button("����ͼƬ");
		btn.addActionListener(this);
		imgBtnPanel.add(btn);
		btn = new Button("����ͼƬ");
		btn.addActionListener(this);
		imgBtnPanel.add(btn);
		btn = new Button("ɾ��ͼƬ");
		btn.addActionListener(this);
		imgBtnPanel.add(btn);

		/*        fldImageFile = new TextField[m_actor.getImageNum()];
		 for (int i = 0; i < m_actor.getImageNum(); i++)
		 {
		 fldImageFile[i] = new TextField(m_actor.getImageFile(i));
		 fldImageFile[i].setEditable(false);
		 rightPanel.add(fldImageFile[i]);
		 Button btn = new Button("����ͼƬ" + Integer.toString(i));
		 btn.addActionListener(this);
		 rightPanel.add(btn);
		 }*/
		/*		imageId = new Choice();
		 for(int i = 0; i < 60; i++)
		 imageId.add(Integer.toString(i));
		 rightPanel.add(imageId);
		 */
	}

	public void saveProperties()
	{
		//		actor.hasMModule = hasMModel.getState();
		//		actor.type = actorType.getSelectedIndex();
		//		actor.imageId = imageId.getSelectedIndex();
	}

	public void pushHistry()
	{
		if (histry.isEmpty() || !((Animation) histry.get(curhistry - 1)).isEqual(m_actor))
		{
			if (histry.size() > curhistry)
			{
				histry.setSize(curhistry);
			}
			histry.add(m_actor.Clone());
			curhistry++;

			//limit undo buffer size
			while (curhistry > 40)
			{
				histry.remove(0);
				curhistry--;
			}
		}
	}

	public boolean undoHistry()
	{
		if (curhistry > 1)
		{
			curhistry--;
			m_actor = ((Animation) histry.get(curhistry - 1)).Clone();
			//			histry.remove(histry.size() - 1);
			return true;
		}
		return false;
	}

	public boolean redoHistry()
	{
		if (curhistry < histry.size())
		{
			m_actor = ((Animation) histry.get(curhistry)).Clone();
			curhistry++;
			return true;
		}
		return false;
	}

	public void clearHistry()
	{
		histry.removeAllElements();
		curhistry = 0;
	}

	public void refreshActionList()
	{
		int i;
		int sel;
		Action action;
		sel = actionList.getSelectedIndex();
		actionList.removeAll();
		for (i = 0; i < m_actor.actions.size(); i++)
		{
			action = m_actor.getAction(i);
			actionList.add("(Action " + Integer.toString(i) + ")" + action.getName(frameSelId));
		}
		actionList.select(sel);
	}

	public void refreshFrameList()
	{
		int sel = frameList.getSelectedIndex();
		frameList.removeAll();
		AniFrame frame;
		for (int i = 0; i < m_actor.getFrameCount(); i++)
		{
			frame = m_actor.getFrame(i);
			frameList.add("(Frame " + Integer.toString(i) + ")" + frame.getName(ModuleDlg.moduleSelId));
		}
		frameList.select(sel);
	}

	public void refreshImageList()
	{
		int sel = imageList.getSelectedIndex();
		imageList.removeAll();
		for (int i = 0; i < m_actor.getImageNum(); i++)
		{
			imageList.add(m_actor.getImageFile(i));
		}
		imageList.select(sel);
	}

	public void refresh()
	{
		refreshFrameList();
		refreshActionList();
		//		actorType.select(actor.type);
		//		imageId.select(actor.imageId);
		//		hasMModel.setState(actor.hasMModule);
		refreshImageList();
		//        for (int i = m_actor.getImageNum() - 1; i >= 0; i--)
		//            fldImageFile[i].setText(m_actor.getImageFile(i));
	}

	public void itemStateChanged(java.awt.event.ItemEvent itemEvent)
	{
		int id = frameList.getSelectedIndex();
		if (id >= 0)
		{
			if (frameSelId != id)
			{
				frameSelId = id;
				refreshActionList();
			}
		}
	}

	public void actionPerformed(ActionEvent e)
	{
		String s = e.getActionCommand();
		if (e.getSource() == frameList)
		{
			int id = frameList.getSelectedIndex();
			if (id >= 0)
			{
				if (frameSelId != id)
				{
					frameSelId = id;
					refreshActionList();
				}
				saveProperties();
				FrameDlg dlg = new FrameDlg(this, m_actor, m_partyActor, m_image, m_partyImage, id);
				dlg.show();
			}

		} else if (e.getSource() == actionList)
		{
			int id = actionList.getSelectedIndex();
			if (id >= 0)
			{
				saveProperties();
				ActionDlg dlg = new ActionDlg(this, m_actor, m_image, id);
				dlg.show();
			}

		} else if (s == sNew)
		{
			checkSave();
			m_oldactor = m_actor = Animation.Create();
			m_partyActor = null;
			btnAddFrame.setEnabled(false);
			btnAddAction.setEnabled(false);
			btnCopyFrame.setEnabled(false);
			refresh();

		} else if (s == sLoad)
		{
			onLoad();

		} else if (s == sLoadPartyActor)
		{
			onLoadPartyActor();

		} else if (s == sSave)
		{
			if (m_filename == null)
				onSaveAs();
			else
				onSave();

		} else if (s == sSaveAs)
		{
			onSaveAs();

		} else if (s == sImport)
		{
			onImport();

		} else if (s == "Export")
		{
			onExport();
		} else if (s == sAbout)
		{
			MsgBox m = new MsgBox(this, "������Ϣ",
					"�����༭��\n�汾: 4.0.0\n��Ȩ����: ����Gameloft\n����:  Qiu Wei Min, Cao Heng\n����: �¤���ͫ\n\n��ݼ�:\nCtrl+Z: ��������\nShift+Ctrl+Z: ȡ������");
			m.show();

		} else if (s == sExit)
		{
			exit();

		} else if (s == sRemoveUnusedImages)
		{
			int i, n = 0;
			for (i = m_actor.getImageNum() - 1; i >= 0; i--)
			{
				if (m_actor.isImageUsed(i) == -1)
				{
					m_actor.removeImageFile(i);
					imageList.remove(i);
					n++;
				}
			}
			resetImage();
			if (m_actor.getCurImage() > m_actor.getImageNum() - 1)
				m_actor.setCurImage(m_actor.getImageNum() - 1);
			MsgBox msg = new MsgBox(this, sRemoveUnusedImages, "���ֲ�ɾ�� " + n + " ��δʹ�õ�ͼƬ�ļ�");
			msg.show();

		} else if (s == sRemoveUnusedModules)
		{
			int i, n = 0;
			for (i = m_actor.modules.size() - 1; i >= 0; i--)
			{
				if (!m_actor.isModuleUsed(i, null))
				{
					m_actor.removeModule(i);
					n++;
				}
			}
			MsgBox msg = new MsgBox(this, sRemoveUnusedModules, "���ֲ�ɾ�� " + n + " ��δʹ�õ�ͼ��");
			msg.show();

		} else if (s == sRemoveUnusedFrames)
		{
			int i, n = 0;
			for (i = m_actor.getFrameCount() - 1; i >= 0; i--)
			{
				if (m_actor.isFrameUsed(i) == -1)
				{
					m_actor.removeFrame(i);
					n++;
				}
			}
			MsgBox msg = new MsgBox(this, sRemoveUnusedFrames, "���ֲ�ɾ�� " + n + " ��δʹ�õ���");
			msg.show();
			refresh();

		} else if (s == sScale)
		{
			ScaleDlg dlg = new ScaleDlg(this);
			dlg.show();
			if (dlg.fac != 1.0)
				m_actor.Scale(dlg.fac);

		} else if (s == sBGColor)
		{
			ColorDlg dlg = new ColorDlg(this, AnimationEditor.getBGColor());
			dlg.show();
			AnimationEditor.setBGColor(dlg.color);

		} else if (s == sGridColor)
		{
			ColorDlg dlg = new ColorDlg(this, AnimationEditor.getGridColor());
			dlg.show();
			AnimationEditor.setGridColor(dlg.color);

		} else if (s == sAxisColor)
		{
			ColorDlg dlg = new ColorDlg(this, AnimationEditor.getCoordColor());
			dlg.show();
			AnimationEditor.setCoordColor(dlg.color);

		} else if (s == sColBoxColor)
		{
			ColorDlg dlg = new ColorDlg(this, AnimationEditor.getColColor());
			dlg.show();
			AnimationEditor.setColColor(dlg.color);

		} else if (s == sSelectionColor)
		{
			ColorDlg dlg = new ColorDlg(this, AnimationEditor.getSelColor());
			dlg.show();
			AnimationEditor.setSelColor(dlg.color);

		} else if (s == sFrameDelay)
		{
			FrameTimeDlg dlg = new FrameTimeDlg(this, AnimationEditor.getFrameTime());
			dlg.show();
			AnimationEditor.setFrameTime(dlg.val);

		} else if (s == sEditActorTypes)
		{
			saveProperties();
			ActorTypeDlg dlg = new ActorTypeDlg(this);
			dlg.show();
			//			refreshActorTypes();

		} else if (s == "������")
		{
			saveProperties();
			m_actor.addFrame(new AniFrame());
			FrameDlg dlg = new FrameDlg(this, m_actor, m_partyActor, m_image, m_partyImage, m_actor.getFrameCount() - 1);
			dlg.show();
			frameList.select(frameList.getItemCount() - 1);

		} else if (s == "Insert Before")
		{
			int id = frameList.getSelectedIndex();
			if (id < 0)
				id = 0;
			m_actor.insertFrame(id, new AniFrame());
			FrameDlg dlg = new FrameDlg(this, m_actor, m_partyActor, m_image, m_partyImage, id);
			dlg.show();

		} else if (s == "������")
		{
			int id = frameList.getSelectedIndex();
			if (id >= 0)
			{
				m_actor.addFrame((AniFrame) (m_actor.getFrame(id)).clone());
				refresh();
				frameList.select(frameList.getItemCount() - 1);
			} else
			{
				MsgBox msg = new MsgBox(this, "Error", "Please select the frame to copy from.");
				msg.show();
			}

		} else if (s == "�����ƶ���")
		{
			int id = frameList.getSelectedIndex();
			if (id > 0 && id < m_actor.getFrameCount())
			{
				m_actor.moveFrameUp(id);
				refresh();
				frameList.select(id - 1);
			}

		} else if (s == "�����ƶ���")
		{
			int id = frameList.getSelectedIndex();
			if (id >= 0 && id < m_actor.getFrameCount() - 1)
			{
				m_actor.moveFrameDown(id);
				refresh();
				frameList.select(id + 1);
			}

		} else if (s == "ɾ����")
		{
			int id = frameList.getSelectedIndex();
			if (id >= 0)
			{
				int t = m_actor.isFrameUsed(id);
				if (t >= 0)
				{
					MsgBox msg = new MsgBox(this, "Error", "This frame is in use by action: " + t);
					msg.show();
					return;
				}
				frameList.select(id - 1);
				m_actor.removeFrame(id);
				frameList.remove(id);
			}

		} else if (s == "���Ӷ���")
		{
			saveProperties();
			m_actor.actions.addElement(new Action());
			ActionDlg dlg = new ActionDlg(this, m_actor, m_image, m_actor.actions.size() - 1);
			dlg.show();

		} else if (s == "���ƶ���")
		{
			int id = actionList.getSelectedIndex();
			if (id >= 0)
			{
				if (id >= 0)
					m_actor.actions.insertElementAt(((Action) (m_actor.actions.elementAt(id))).clone(), id + 1);
				else
					m_actor.actions.addElement(((Action) (m_actor.actions.elementAt(id))).clone());
				refreshActionList();
				actionList.select(id + 1);
			} else
			{
				MsgBox msg = new MsgBox(this, "Error", "Please select an action to copy from.");
				msg.show();
			}

		} else if (s == "�����ƶ�����")
		{
			int id = actionList.getSelectedIndex();
			if (id > 0)
			{
				Object obj = m_actor.actions.elementAt(id);
				m_actor.actions.setElementAt(m_actor.actions.elementAt(id - 1), id);
				m_actor.actions.setElementAt(obj, id - 1);
				refreshActionList();
				actionList.select(id - 1);
			}

		} else if (s == "�����ƶ�����")
		{
			int id = actionList.getSelectedIndex();
			if (id >= 0 && id < m_actor.actions.size() - 1)
			{
				Object obj = m_actor.actions.elementAt(id);
				m_actor.actions.setElementAt(m_actor.actions.elementAt(id + 1), id);
				m_actor.actions.setElementAt(obj, id + 1);
				refreshActionList();
				actionList.select(id + 1);
			}

		} else if (s == "ɾ������")
		{
			int id = actionList.getSelectedIndex();
			if (id >= 0)
			{
				m_actor.removeAction(id);
				actionList.select(id - 1);
				actionList.remove(id);
			}

		} else if (s == "�༭ͼ��" || e.getSource() == imageList)
		{
			//if(m_actor.getImageFile(m_actor.getCurImage()) == null || m_actor.getImageFile(m_actor.getCurImage()).length() == 0)
			//    browseImageFile(false);
			int id = imageList.getSelectedIndex();
			if (id >= 0)
			{
				m_actor.setCurImage(imageList.getSelectedIndex());
				if (m_actor.getImageFile(m_actor.getCurImage()) != null
						&& m_actor.getImageFile(m_actor.getCurImage()).length() > 0)
				{
					btnAddFrame.setEnabled(true);
					btnAddAction.setEnabled(true);
					btnCopyFrame.setEnabled(true);
					ModuleDlg dlg = new ModuleDlg(this, m_actor, m_image[m_actor.getCurImage()]);
					dlg.show();
				}
			} else
			{
				MsgBox msg = new MsgBox(this, "�������", "��ѡ��Ҫ�༭��ͼƬ.");
				msg.show();
			}

		} else if (s == "����ͼƬ")
		{
			int id = imageList.getSelectedIndex();
			if (id >= 0)
			{
				m_actor.setCurImage(id);
				browseImageFile(false);
			} else
			{
				MsgBox msg = new MsgBox(this, "�������", "��ѡ��Ҫ������ͼƬ.");
				msg.show();
			}

		} else if (s == "����ͼƬ")
		{
			browseImageFile(true);

		} else if (s == "ɾ��ͼƬ")
		{
			int id = imageList.getSelectedIndex();
			if (id >= 0)
			{
				int t = m_actor.isImageUsed(id);
				if (t >= 0)
				{
					MsgBox msg = new MsgBox(this, "�������", "��ǰͼƬ�Ѿ�Ӧ����ͼ��: " + t);
					msg.show();
					return;
				}
				imageList.select(id - 1);
				m_actor.removeImageFile(id);
				resetImage();
				imageList.remove(id);
			}
		}
	}

	private void onExport()
	{
		FileDialog dlg = new FileDialog(this, "Save As", FileDialog.SAVE);
		dlg.setFile("*.dat");
		dlg.show();
		if (dlg.getFile() == null)
			return;
		String filename = dlg.getDirectory() + dlg.getFile();
		saveProperties();
		try
		{
//			FileOutputStream fou = new FileOutputStream(filename);
//			DataOutputStream dou = new DataOutputStream(fou);
//			actor.exportForBrew(dou);
//			dou.close();
//			fou.close();
//			String actfn = filename.substring(0, filename.indexOf(".")) + ".txt";
//			fou = new FileOutputStream(actfn);
//			actor.exportActionNames(actorType.getSelectedItem(), fou);
//			fou.close();
		} catch (Exception e)
		{
			MsgBox msg = new MsgBox(this, "����ʧ��", "Export operation failed!");
			msg.show();
		}
	}

	private void onImport()
	{
		FileDialog dlg = new FileDialog(this, "���붯������", FileDialog.LOAD);
		dlg.setFile("*.anm");
		dlg.show();
		if (dlg.getFile() != null)
		{
			m_filename = null;
			try
			{
				FileInputStream fin = new FileInputStream(dlg.getDirectory() + dlg.getFile());
				DataInputStream din = new DataInputStream(fin);
				m_actor.LoadFromAni(din);
				din.close();
				fin.close();
				resetImage();
			} catch (Exception e)
			{
				e.printStackTrace();
				MsgBox msg = new MsgBox(this, "����ʧ��", "Import operation failed!");
				msg.show();
			}
			btnAddFrame.setEnabled(true);
			btnAddAction.setEnabled(true);
			btnCopyFrame.setEnabled(true);
			refresh();
		}
	}

	private void onSave()
	{
		saveProperties();
		try
		{
			FileOutputStream fou = new FileOutputStream(m_filename);
			//			DataOutputStream dou = new DataOutputStream(fou);
			//			actor.saveToAni(dou);
			m_actor.exportXML(fou);
			//			dou.close();
			fou.close();
			m_oldactor = m_actor.Clone();

		} catch (Exception e)
		{
			MsgBox msg = new MsgBox(this, "Error", "Save operation failed!");
			msg.show();
		}
	}

	private void onSaveAs()
	{
		FileDialog dlg = new FileDialog(this, "Save As", FileDialog.SAVE);
		dlg.setFile("*.xml");
		dlg.show();
		if (dlg.getFile() != null)
		{
			m_filename = dlg.getDirectory() + dlg.getFile();
			onSave();
		}
	}

	private void onLoad()
	{
		checkSave();
		FileDialog dlg = new FileDialog(this, "Load", FileDialog.LOAD);
		dlg.setFile("*.xml");
		dlg.show();
		if (dlg.getFile() != null)
		{
			m_filename = dlg.getDirectory() + dlg.getFile();
			try
			{
				FileInputStream fin = new FileInputStream(m_filename);
				//				DataInputStream din = new DataInputStream(fin);
				m_actor.importXML(fin);
				//				din.close();
				fin.close();
				/*                fldImageFile = new TextField[m_actor.getImageNum()];
				 for (int i = 0; i < m_actor.getImageNum(); i++)
				 {
				 fldImageFile[i] = new TextField(m_actor.getImageFile(i));
				 fldImageFile[i].setEditable(false);
				 rightPanel.add(fldImageFile[i]);
				 Button btn = new Button("����ͼƬ" + Integer.toString(i));
				 btn.addActionListener(this);
				 rightPanel.add(btn);
				 }*/
				resetImage();
				m_oldactor = m_actor.Clone();
			} catch (Exception e)
			{
				MsgBox msg = new MsgBox(this, "Error", "Load operation failed!");
				msg.show();
			}
			btnAddFrame.setEnabled(true);
			btnAddAction.setEnabled(true);
			btnCopyFrame.setEnabled(true);
			refresh();
		}
	}

	private void onLoadPartyActor()
	{
		FileDialog dlg = new FileDialog(this, "Load Party Actor", FileDialog.LOAD);
		dlg.setFile("*.xml");
		dlg.show();
		if (dlg.getFile() != null)
		{
			String filename = dlg.getDirectory() + dlg.getFile();
			try
			{
				if (m_partyActor == null)
				{
					m_partyActor = Animation.Create();
				}
				FileInputStream fin = new FileInputStream(filename);
				m_partyActor.importXML(fin);
				fin.close();
				loadPartyImage();
			} catch (Exception e)
			{
				MsgBox msg = new MsgBox(this, "Error", "Load operation failed!");
				msg.show();
			}
			btnAddFrame.setEnabled(true);
			btnAddAction.setEnabled(true);
			btnCopyFrame.setEnabled(true);
			refresh();
		}
	}

	private void browseImageFile(boolean addImg)
	{
		FileDialog dlg = new FileDialog(this, "Load Image", FileDialog.LOAD);
		dlg.setFile("*.gif;*.png;*.bmp");
		dlg.show();
		if (dlg.getFile() != null)
		{
			if (!addImg)
				m_actor.setImageFile(dlg.getDirectory() + dlg.getFile(), m_actor.getCurImage());
			//fldImageFile[m_actor.getCurImage()].setText(m_actor.getImageFile(m_actor.getCurImage()));
			else
			{
				m_actor.addImageFile(dlg.getDirectory() + dlg.getFile());
				imageList.add(dlg.getDirectory() + dlg.getFile());
			}
			refresh();
			resetImage();
		}
	}

	private void resetImage()
	{
		m_image = null;
		MediaTracker tracker = new MediaTracker(this);
		m_image = new Image[m_actor.getImageNum()];
		for (int i = m_actor.getImageNum() - 1; i >= 0; i--)
		{
			m_image[i] = getToolkit().createImage(m_actor.getImageFile(i));
			tracker.addImage(m_image[i], 0);
		}
		try
		{
			tracker.waitForAll();
		} catch (Exception e)
		{
		}
	}

	private void loadPartyImage()
	{
		m_partyImage = null;
		MediaTracker tracker = new MediaTracker(this);
		m_partyImage = new Image[m_actor.getImageNum()];
		for (int i = m_partyActor.getImageNum() - 1; i >= 0; i--)
		{
			m_partyImage[i] = getToolkit().createImage(m_partyActor.getImageFile(i));
			tracker.addImage(m_partyImage[i], 0);
		}
		try
		{
			tracker.waitForAll();
		} catch (Exception e)
		{
		}
	}

	public void windowClosing(WindowEvent e)
	{
		exit();
	}

	public void windowActivated(WindowEvent e)
	{
	}

	public void windowClosed(WindowEvent e)
	{
	}

	public void windowDeactivated(WindowEvent e)
	{
	}

	public void windowDeiconified(WindowEvent e)
	{
	}

	public void windowIconified(WindowEvent e)
	{
	}

	public void windowOpened(WindowEvent e)
	{
	}

	void checkSave()
	{
		if (!m_oldactor.isEqual(m_actor))
		{
			MsgBox msg = new MsgBox(this, "Save", "This actor has been modified and not saved. Save this actor?",
					MsgBox.TYPE_YESNO);
			msg.show();
			if (msg.ret == MsgBox.YES)
			{
				if (m_filename == null)
				{
					onSaveAs();
				} else
				{
					onSave();
				}
			}
		}
	}

	protected void exit()
	{
		checkSave();
		AnimationEditor.savePreference();
		System.exit(0);
	}
}