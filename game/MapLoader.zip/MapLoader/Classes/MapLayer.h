//
//  MapLayer.h
//  Dungeons
//
//  Created by trarck trarck on 11-10-27.
//  Copyright 2011 yitengku.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.h"
#import "Coordinate.h"
#import "Astar.h"


#define Background_ZOrder -10
#define Intermediate_ZOrder 0
#define Foreground_ZOrder 10

#define ComponentOFFSET 2

@interface MapLayer : CCLayer {
	int mapColumn_,mapRow_;
	
	CCLayer *background_;//背景层，加载地形资源
	CCLayer *intermediate_;//中间层，显示角色，怪物，等可变元素
	CCLayer *foreground_;//前景层,背景层某些物体的遮挡元素。通常为空。
	
	Coordinate *coordinate_;
	Astar *astar_;

	
	CGPoint lastTouchLocation_;
	
	CGPoint moveableBoundingMin_;
	CGPoint moveableBoundingMax_;
	
	BOOL isTouchMoved_;
	
	MapInfo *mapInfos_;

	CGSize tileSize_;
	
	int componentRow_;
	int componentCol_;
	CCArray *backgroundComponents_;
	CGSize fixSize_;
	CGPoint componentPosition_;//component活动区域相对地图的坐标
	int componentOuterGridX_,componentOuterGridY_;//component外围区域相对地图的格子坐标
	int componentIndexX_,componentIndexY_;//活动区左边单元格的索引号
}

@property(nonatomic,retain) Coordinate *coordinate;
@property(nonatomic,retain) Astar *astar;


-(void) initUtil;
-(void) initMapLayers;
-(void) loadBackground;
-(void) loadInterMediate;

-(void) addInterMediateItemWithMapLocation:(CGPoint)mapLocation;
-(void) addInterMediateItem:(CGPoint)location;

-(NSArray *) searchPathsFrom:(CGPoint)from to:(CGPoint)to;
-(NSArray *) mapPathsToViewPaths:(NSArray *)paths;
@end
