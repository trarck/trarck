//
//  MapLayer.m
//  Dungeons
//
//  Created by trarck trarck on 11-10-27.
//  Copyright 2011 yitengku.com. All rights reserved.
//
#import "GameConfig.h"
#import "MapLayer.h"
#import "GameScene.h"

#define COLUMN 20
#define ROW	20

@implementation MapLayer

static int mapItemGid=1;

@synthesize coordinate=coordinate_;
@synthesize astar=astar_;

-(void) dealloc
{
	CCLOG(@"MapLayer dealloc");
	[self unscheduleAllSelectors];
	self.astar=nil;
	self.coordinate=nil;
	free(mapInfos_);
	[backgroundComponents_ release];
	[super dealloc];
}

-(id) init
{
	
	if((self=[super init])){
		CCLOG(@"MapLayer init");
		self.isTouchEnabled=YES;

		
		//[self loadMapInfo];
		mapColumn_=COLUMN;
		mapRow_=ROW;
		mapInfos_=calloc(mapColumn_*mapRow_, sizeof(MapInfo));
		
		[self initUtil];
		[self initMapLayers];
				
		tileSize_.width=256;
		tileSize_.height=256;
		//[self loadBackground];
		//[self loadBackgroundAllInOne];
		//[self loadBackgroundRightAngleTile];
		
			
		[self loadBackgroundRightAngleTileDynamic];
		
		
		[self loadInterMediate];
		
				
		//[self schedule:@selector(randomEvent:) interval:1.0];
		//[self schedule:@selector(showBarrier) interval:0.1];
	}
	return self;
}

/**
 * 初始化一些工具方法
 * 寻路，坐标转换
 */
-(void) initUtil
{
	
	CGSize screenSize=[[CCDirector sharedDirector] winSize];
	NSLog(@"width=%f,height=%f",screenSize.width,screenSize.height);
	//coord transform
	coordinate_=[Coordinate sharedCoordinate];
	[coordinate_ setTileWidth:kGameTileWidth height:kGameTileHeight];
	//[coordinate_ setOriginPosition:screenSize.width/2 y:0];
	//astar search
	astar_=[Astar sharedAstar];
	[astar_ setBounding:0 minY:0 maxX:mapColumn_ maxY:mapRow_];
	[astar_	setBarrier:mapInfos_ column:mapColumn_];
	
//	//moveable size
//	moveableBoundingMax_.x=kGameTileWidth*mapRow_/2;
//	moveableBoundingMax_.y=0;
//	moveableBoundingMin_.x=screenSize.width-kGameTileWidth*mapColumn_/2;
//	moveableBoundingMin_.y=screenSize.height-kGameTileHeight*(mapRow_+mapColumn_)/2;
//	
//	self.position=ccp(screenSize.width/2,0);
	
}

/**
 * 初始化地图层
 */
-(void) initMapLayers
{
	background_=[CCLayer node];
	background_.position=ccp(0,0);
	[self addChild:background_ z:Background_ZOrder];
		
	intermediate_=[CCLayer node];
	intermediate_.position=ccp(0,0);
	[self addChild:intermediate_ z:Intermediate_ZOrder];
	
	foreground_=[CCLayer node];
	foreground_.position=ccp(0,0);
	[self addChild:foreground_ z:Foreground_ZOrder];
}

//static CCSprite *backgrounds[ROW][COLUMN];

/**
 * 输入地图背景层
 */
-(void) loadBackground
{	

	CCLOG(@"MapLayer loadBackground");
	CCSpriteBatchNode *batch=[CCSpriteBatchNode batchNodeWithFile:@"coord_bg.png" capacity:1];
	[background_ addChild:batch z:0 tag:9999];
	
	for (int i=0; i<mapRow_; i++) {
		for (int j=0; j<mapColumn_; j++) {
			
			CCSprite *tile=[CCSprite  spriteWithTexture:batch.texture rect:CGRectMake(0,0,64,32)];
			//CCSprite *tile=[CCSprite  spriteWithFile:@"coord_bg.png"];
			tile.anchorPoint=ccp(0.5,0);
			//tile.color=ccRED;
			CGPoint p=[coordinate_ mapToScreen:j y:i];
			
			tile.position=p;
			//NSLog(@"%f,%f",p.x,p.y);
			[batch addChild:tile];
			//[background_ addChild:tile];
			//backgrounds[i][j]=tile;
		}
	}
	CGSize screenSize=[[CCDirector sharedDirector] winSize];
	//moveable size
	moveableBoundingMax_.x=kGameTileWidth*mapRow_/2;
	moveableBoundingMax_.y=0;
	moveableBoundingMin_.x=screenSize.width-kGameTileWidth*mapColumn_/2;
	moveableBoundingMin_.y=screenSize.height-kGameTileHeight*(mapRow_+mapColumn_)/2;
	
	self.position=ccp(screenSize.width/2,0);
}
//斜视角tile
-(void) loadBackgroundIsoTile
{	
	
	CCLOG(@"MapLayer loadBackground");
	CCSpriteBatchNode *batch=[CCSpriteBatchNode batchNodeWithFile:@"coord_bg.png" capacity:1];
	[background_ addChild:batch z:0 tag:9999];
	
	for (int i=0; i<mapRow_; i++) {
		for (int j=0; j<mapColumn_; j++) {
			
			CCSprite *tile=[CCSprite  spriteWithTexture:batch.texture rect:CGRectMake(0,0,64,32)];
			//CCSprite *tile=[CCSprite  spriteWithFile:@"coord_bg.png"];
			tile.anchorPoint=ccp(0.5,0);
			//tile.color=ccRED;
			CGPoint p=[coordinate_ mapToScreen:j y:i];
			
			tile.position=p;
			//NSLog(@"%f,%f",p.x,p.y);
			[batch addChild:tile];
			//[background_ addChild:tile];
			//backgrounds[i][j]=tile;
		}
	}
}
//一张图
-(void) loadBackgroundAllInOne
{	
	
	CCLOG(@"MapLayer loadBackgroundAllInOne");
	
	CGSize screenSize=[[CCDirector sharedDirector] winSize];
	
	CCSprite *bg=[CCSprite  spriteWithFile:@"1.png"];
	bg.position=ccp(0,0);
	[background_ addChild:bg];
	NSLog(@"contentSize:%f,%f",bg.contentSize.width,bg.contentSize.height);
	moveableBoundingMax_.x=1024;
	moveableBoundingMax_.y=900;
	moveableBoundingMin_.x=screenSize.width-1024;
	moveableBoundingMin_.y=screenSize.height-900;
		
	self.position=ccp(screenSize.width/2,screenSize.height/2);
}
//直角tile
-(void) loadBackgroundRightAngleTile
{	
	
	CCLOG(@"MapLayer loadBackgroundRightAngleTile");
	
	int row=7,col=9;
	CGSize tileSize={256,256};
	
	for (int i=0; i<row; i++) {
		for (int j=0; j<col; j++) {
			
			NSString *name=[NSString stringWithFormat:@"m_r%d_c%d.png",row-i,j+1];
			CCSprite *tile=[CCSprite  spriteWithFile:name];
			tile.anchorPoint=ccp(0,0);
			//tile.color=ccRED;
			CGPoint p={tileSize.width*j,tileSize.height*i};
			
			tile.position=p;
			//NSLog(@"%f,%f",p.x,p.y);
			
			[background_ addChild:tile];
			//backgrounds[i][j]=tile;
		}
	}
	
	CGSize screenSize=[[CCDirector sharedDirector] winSize];
	//moveable size
	moveableBoundingMax_.x=0;
	moveableBoundingMax_.y=0;
	moveableBoundingMin_.x=screenSize.width-col*tileSize.width;
	moveableBoundingMin_.y=screenSize.height-row*tileSize.height;
	
	self.position=ccp(0,0);
}

//动态直角tile
-(void) loadBackgroundRightAngleTileDynamic
{	
	
	CCLOG(@"MapLayer loadBackgroundRightAngleTileDynamic");
	
	backgroundComponents_=nil;
	fixSize_.width=fixSize_.height=160;
	
	
	int row=7,col=9;
	CGSize tileSize={256,256};
	
	CGSize screenSize=[[CCDirector sharedDirector] winSize];

	
	[self calcComponentQuantity:tileSize screenSize:screenSize];
	[self initComponents];
	
	[self setComponents];
	
	//moveable size
	moveableBoundingMax_.x=0;
	moveableBoundingMax_.y=0;
	moveableBoundingMin_.x=screenSize.width-col*tileSize.width;
	moveableBoundingMin_.y=screenSize.height-row*tileSize.height;
	
	self.position=ccp(-256,-256);
	
	componentPosition_.x=256;
	componentPosition_.y=256;
	componentOuterGridX_=0;
	componentOuterGridX_=0;
	componentIndexX_=1;
	componentIndexY_=1;
	//self.position=ccp(0,0);
}

-(void) initComponents
{
	[backgroundComponents_ release];
	backgroundComponents_=[[CCArray alloc] initWithCapacity:componentCol_*componentRow_];
	
	for (int i=0; i<componentRow_; i++) {
		for (int j=0; j<componentCol_; j++) {
			CCSprite *cell=[CCSprite  node];
			cell.anchorPoint=ccp(0,0);
			[background_ addChild:cell];
			[backgroundComponents_ addObject:cell];
		}
	}
}

-(void) calcComponentQuantity:(CGSize) tileSize screenSize:(CGSize) screenSize
{

	componentCol_=(int)(ceilf(screenSize.width/tileSize.width));
	componentRow_=(int)(ceilf(screenSize.height/tileSize.height));
	componentCol_+=ComponentOFFSET;
	componentRow_+=ComponentOFFSET;
	
	NSLog(@"game: compoinet size:%d,%d",componentCol_,componentRow_);
}

-(void) setComponents
{
	CCLOG(@"game: setComponents");
	
	CGSize tileSize={256,256};
	
	for (int i=0; i<componentRow_; i++) {
		for (int j=0; j<componentCol_; j++) {
			CCSprite *cell=[backgroundComponents_ objectAtIndex:i*componentCol_+j];
			
			CCTexture2D *texture = [[CCTextureCache sharedTextureCache] addImage: 
									[NSString stringWithFormat:@"m_r%d_c%d.png",7-i,j+1]];
			[cell setTexture:texture];
			CGRect rect = CGRectZero;
			rect.size = texture.contentSize;
			[cell setTextureRect:rect];
			//[texture release];
			
			cell.position=ccp(tileSize.width*j,tileSize.height*i);

			//NSLog(@"m_r%d_c%d.png",7-i,j+1);
		}
	}
}

-(void) resetComponents:(CGPoint ) dis
{
	//NSLog(@"game:move by:%f,%f,%f,%f",dis.x,dis.y,fabs(dis.x),fabs(dis.y));
	CGPoint p1=self.position;
	dis.x=componentPosition_.x+p1.x;
	dis.y=componentPosition_.y+p1.y;
	//NSLog(@"game:move by:%f,%f,%f,%f",dis.x,dis.y,fabs(dis.x),fabs(dis.y));
	
	float dx,dy;
	int dirX,dirY;
	int loopX,loopY;
	float modX,modY;
	
	dx=fabs(dis.x);
	dy=fabs(dis.y);
	
	dirX=dis.x>0?-1:1;
	dirY=dis.y>0?-1:1;
	
	loopX=(int)(dx/tileSize_.width);
	loopY=(int)(dy/tileSize_.height);
	
	modX=fmodf(dx,tileSize_.width);
	modY=fmodf(dy,tileSize_.height);
	
	loopX+=modX>=fixSize_.width?1:0;
	loopY+=modY>=fixSize_.height?1:0;
	
	
	
	int moveIndex;
	CGPoint position;
	int moveToAbsoluteGridX,moveToAbsoluteGridY;
	
	int tmp;
	if (dirX>0) {
		for (int i=0; i<loopX; i++) {
			tmp=componentIndexX_;
			moveToAbsoluteGridX=componentOuterGridX_+componentCol_;
			if (moveToAbsoluteGridX>9-1)  break;
			
			componentPosition_.x+=dirX*tileSize_.width;

			
			moveIndex=(componentIndexX_-dirX+componentCol_)%componentCol_;
			componentIndexX_=(componentIndexX_+dirX)%componentCol_;

			
			componentOuterGridX_+=dirX;
			
			NSLog(@"game:+1:indexX:%d,newIndexX:%d,moveIndex:%d,moveToAbsoluteGridX:%d",
				  tmp,componentIndexX_,moveIndex,moveToAbsoluteGridX);
			
			//移动整列
			for (int j=0; j<componentRow_; j++) {
				CCSprite *cell=[backgroundComponents_ objectAtIndex:componentCol_*j+moveIndex];
				position=cell.position;
				position.x=moveToAbsoluteGridX*tileSize_.width;
				cell.position=position;
				
				[self setComponentTexture:cell x:moveToAbsoluteGridX y:componentOuterGridY_+j];
			}
			
		}
	}else {
		for (int i=0; i<loopX; i++) {
			tmp=componentIndexX_;
			
			componentPosition_.x+=dirX*tileSize_.width;
			
			
			componentOuterGridX_+=dirX;
			
			
			if (componentOuterGridX_<0) {
				componentOuterGridX_=0;
				break;
			}
			
			moveToAbsoluteGridX=componentOuterGridX_;
			moveIndex=(componentIndexX_+dirX-1+componentCol_)%componentCol_;
			
			componentIndexX_=(componentIndexX_+componentCol_)%componentCol_;
			
			
			
			
			NSLog(@"game:-1:indexX:%d,newIndexX:%d,moveIndex:%d,moveToAbsoluteGridX:%d", 
				  tmp,componentIndexX_,moveIndex,moveToAbsoluteGridX);
			//移动整列
			for (int j=0; j<componentRow_; j++) {
				CCSprite *cell=[backgroundComponents_ objectAtIndex:componentCol_*j+moveIndex];
				position=cell.position;
				position.x=moveToAbsoluteGridX*tileSize_.width;
				cell.position=position;
				
				[self setComponentTexture:cell x:moveToAbsoluteGridX y:componentOuterGridY_+j];
			}
		}
	}
	
	if (dirY>0) {
		for (int i=0; i<loopY; i++) {
			tmp=componentIndexY_;
			componentPosition_.y+=dirY*tileSize_.height;
			
			moveToAbsoluteGridY=componentOuterGridY_+componentRow_;
			moveIndex=(componentIndexY_-dirY+componentRow_)%componentRow_;
			
			componentIndexY_=(componentIndexY_+dirY)%componentRow_;
			componentOuterGridY_+=dirY;
			if (moveToAbsoluteGridY>7-1)  break;
			
			NSLog(@"game:+1:indexY:%d,newIndexY:%d,moveIndex:%d,moveToAbsoluteGridY:%d",
				  tmp,componentIndexY_,moveIndex,moveToAbsoluteGridY);
			
			//移动整行
			for (int j=0; j<componentCol_; j++) {
				CCSprite *cell=[backgroundComponents_ objectAtIndex:componentCol_*moveIndex+j];
				
				position=cell.position;
				position.y=moveToAbsoluteGridY*tileSize_.height;
				cell.position=position;
				
				[self setComponentTexture:cell x:componentOuterGridX_+j y:moveToAbsoluteGridY];
			}
		}
	}else {
		for (int i=0; i<loopY; i++) {
			tmp=componentIndexY_;
			
			componentPosition_.y+=dirY*tileSize_.height;
			
			componentOuterGridY_+=dirY;
			
			if (componentOuterGridY_<0)  {
				componentOuterGridY_=0;
				break;
			}
			
			moveToAbsoluteGridY=componentOuterGridY_-1;
			moveIndex=(componentIndexY_+dirY-1+componentRow_)%componentRow_;
			
			componentIndexY_=(componentIndexY_+dirY+componentRow_)%componentRow_;
								
			NSLog(@"game:-1:indexY:%d,newIndexY:%d,moveIndex:%d,moveToAbsoluteGridY:%d",
				  tmp,componentIndexY_,moveIndex,moveToAbsoluteGridY);
			
			
			//移动整行
			for (int j=0; j<componentCol_; j++) {
				CCSprite *cell=[backgroundComponents_ objectAtIndex:componentCol_*moveIndex+j];
				
				position=cell.position;
				position.y=moveToAbsoluteGridY*tileSize_.height;
				cell.position=position;
				
				[self setComponentTexture:cell x:componentOuterGridX_+j y:moveToAbsoluteGridY];
			}
		}
	}

	
	
	
	
}

-(void) setComponentTexture:(CCSprite *) cell x:(int) x y:(int) y
{
	//NSLog(@"m_r%d_c%d.png %f,%f",7-y,x+1,cell.position.x,cell.position.y);
	CCTexture2D *texture = [[CCTextureCache sharedTextureCache] addImage: 
							[NSString stringWithFormat:@"m_r%d_c%d.png",7-y,x+1]];
	[cell setTexture:texture];
	CGRect rect = CGRectZero;
	rect.size = texture.contentSize;
	[cell setTextureRect:rect];
	//[texture release];
}
-(void) moveCamera:(CGPoint) dis
{
	
}

/**
 * 载入游戏内容
 *
 */
-(void) loadInterMediate
{
	//[self addInterMediateItemWithMapLocation:ccp(10,10)];
//	
//	[self addInterMediateItemWithMapLocation:ccp(5,10)];
//	[self addInterMediateItemWithMapLocation:ccp(5,9)];
//	[self addInterMediateItemWithMapLocation:ccp(4,10)];
	
//	[self	addNpc:ccp(10,10)];
//	[self	addNpc:ccp(5,9)];
//	[self	addNpc:ccp(4,10)];
//	[self	addNpc:ccp(5,10)];
//	[self	addNpc:ccp(6,6)];
}

/**
 * 添加物体到中间层
 * @param {CGPoint} mapLocation 地图坐标
 */
-(void) addInterMediateItemWithMapLocation:(CGPoint) mapLocation
{

}
/**
 * 添加物体到中间层
 * @param {CGPoint} mapLocation 视图坐标
 */
-(void) addInterMediateItem:(CGPoint )location
{
	CGPoint mapLocation=[coordinate_ screenToMapGrid:location];
	[self addInterMediateItemWithMapLocation:mapLocation];
}

/**
 * 对寻路算法的封装
 */
-(NSArray *) searchPathsFrom:(int) fromX formY:(int) fromY toX:(int) toX toY:(int) toY
{
	[astar_ reset];
	[astar_ setStart:fromX y:fromY];
	[astar_ setEnd:toX y:toY];
	
	return [astar_ search]?[astar_ getPathWithEnd]:nil;
}

/**
 * 对寻路算法的封装
 * 返回的数组要手动释放
 */
-(NSArray *) searchPathsFrom:(CGPoint) from to:(CGPoint) to 
{
	[astar_ reset];
	[astar_ setStart:(int)from.x y:(int) from.y];
	[astar_ setEnd:(int)to.x y:(int) to.y];
	BOOL result=[astar_ search];
	//NSLog(@"result:%d %@",result,astar_);
//	if (result) {
//		NSLog(@"paths:%@",[astar_ getPathWithEnd]);
//	}
	return result?[astar_ getPathWithEnd]:nil;
}

/**
 * 地图格子转成视图坐标(视图坐标不同于屏幕坐标)
 * 返回的数组要手动释放
 */
-(NSArray *) mapPathsToViewPaths:(NSArray *) paths
{
	if (paths) {
		NSMutableArray *newPaths=[[NSMutableArray alloc] initWithCapacity:[paths count]];
		CGPoint p;
		CGPoint newp;
		for (NSValue *v in paths) {
			p=[v CGPointValue];
			newp=[coordinate_ mapToScreen:p];
			[newPaths addObject:[NSValue valueWithCGPoint:newp]];
		}
		return newPaths;
	}else {
		return nil;
	}
}

#pragma mark -
#pragma mark touch event
/**
 * 接收touch事件
 */
-(void) registerWithTouchDispatcher
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self
													 priority:0
											  swallowsTouches:YES];
}
/**
 * touch开始事件
 */
-(BOOL) ccTouchBegan:(UITouch *) touch withEvent:(UIEvent *) event
{
	isTouchMoved_=NO;
	
	lastTouchLocation_=[GameScene locationFromTouch:touch];
	//CGPoint location=lastTouchLocation_;
	//CGPoint gameLocation=ccpSub(location, self.position);
	//NSLog(@"gl:%f,%f self:%f,%f map:%f,%f",location.x,location.y,self.position.x,self.position.y,gameLocation.x,gameLocation.y);
	//NSLog(@"x=%f,y=%f",location.x,location.y);
	//CGPoint mp=[coordinate_ screenToMap:location.x y:location.y];
	//NSLog(@"x=%f,y=%f",mp.x,mp.y);
	//CGPoint mc=[coordinate_ screenToMapGrid:gameLocation];
	//NSLog(@"x=%f,y=%f",mc.x,mc.y);
	//[self addBox:location];
	return YES;
}

/**
 * touch move事件
 */
-(void) ccTouchMoved:(UITouch *) touch withEvent:(UIEvent*) event
{
	CGPoint currentTouchLocation=[GameScene locationFromTouch:touch];
	
	if (isTouchMoved_ || ccpDistance(lastTouchLocation_, currentTouchLocation)>TouchMoveDistance) {
		CGPoint moveBy=ccpSub(lastTouchLocation_, currentTouchLocation);
		moveBy=ccpMult(moveBy, -1);
		
		//NSLog(@"moveTo:%f,%f",moveTo.x,moveTo.y);
		lastTouchLocation_=currentTouchLocation;
		self.position=ccpClamp(ccpAdd(self.position, moveBy),moveableBoundingMin_,moveableBoundingMax_);
		[self resetComponents:moveBy];
		isTouchMoved_=YES;
		
	}
}

/**
 * touch end事件
 */
-(void) ccTouchEnded:(UITouch *) touch withEvent:(UIEvent*) event
{
	if(!isTouchMoved_){
		CGPoint location=[GameScene locationFromTouch:touch];
		CGPoint gameLocation=ccpSub(location, self.position);
		
	}
	//NSLog(@"moveTo:%f,%f",self.gameLocation.x,self.gameLocation.y);
	//NSLog(@"zindex:%@",zIndex_);
	//NSLog(@"data:",mapController_);
	//[mapController_ showBarrier];
}

-(NSString *) description{
	return @"Maplayer";
}

@end
