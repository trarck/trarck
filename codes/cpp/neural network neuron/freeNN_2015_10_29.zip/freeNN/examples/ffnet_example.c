#include <stdio.h>
#include <stdlib.h>

#include "freeNN/feedforwardnetwork.h"

// Network constants
static const unsigned NUM_INPUTS = 2;
static const unsigned NUM_OUTPUTS = 4;
static const unsigned NUM_HIDDEN_LEVELS = 1;
static const unsigned NUM_NEURONS_IN_HIDDEN_LEVELS[] = {6};
static const int WITH_BIAS = 1;
static const double TRAINING_RATE = 0.08;
static const double OUTPUT_TRAINING_RATE = 0.01;
static const NeuronActivationFunction HIDDEN_LAYER_TYPE = TANH;
static const NeuronActivationFunction OUTPUT_LAYER_TYPE = LINEAR;


static const unsigned NUM_EPOCHS = 10000;

int main() {
	// Defining network custom settings
	FeedForwardNetworkSettings *settings = FeedForwardNetworkSettings_new_default();
	settings->withBias_ = WITH_BIAS;
	settings->trainingRate_ = TRAINING_RATE;
	settings->outputLayerTrainingRate_ = OUTPUT_TRAINING_RATE;
	settings->hiddenLayerType_ = HIDDEN_LAYER_TYPE;
	settings->outputLayerType_ = OUTPUT_LAYER_TYPE;

	// Creating instance of the network
	FeedForwardNetwork *ffn = FeedForwardNetwork_new(NUM_INPUTS, NUM_OUTPUTS, NUM_HIDDEN_LEVELS, NUM_NEURONS_IN_HIDDEN_LEVELS, settings);
	double inputs[NUM_INPUTS];
	double expectedOutputs[NUM_OUTPUTS];
	double *results;
	int i;
	
	// Training 1st output neuron to function as AND
	//          2nd output neuron to function as OR
	//          3rd output neuron to function as XOR
        //          4th output neuron to a custon function (0,0 -> 9.128  , 0,1 -> -4.27  , 1,0 -> 3.927  , 1,1 -> -8.532)
	for (i = 0 ; i < NUM_EPOCHS ; i++) {
		inputs[0] = 0;
		inputs[1] = 0;
		expectedOutputs[0] = 0;
		expectedOutputs[1] = 0;
		expectedOutputs[2] = 0;
		expectedOutputs[3] = 9.128;
		FeedForwardNetwork_train(ffn, inputs, expectedOutputs);
		inputs[0] = 0;
		inputs[1] = 1;
		expectedOutputs[0] = 0;
		expectedOutputs[1] = 1;
		expectedOutputs[2] = 1;
		expectedOutputs[3] = -4.27;
		FeedForwardNetwork_train(ffn, inputs, expectedOutputs);
		inputs[0] = 1;
		inputs[1] = 0;
		expectedOutputs[0] = 0;
		expectedOutputs[1] = 1;
		expectedOutputs[2] = 1;
		expectedOutputs[3] = 3.927;
		FeedForwardNetwork_train(ffn, inputs, expectedOutputs);
		inputs[0] = 1;
		inputs[1] = 1;
		expectedOutputs[0] = 1;
		expectedOutputs[1] = 1;
		expectedOutputs[2] = 0;
		expectedOutputs[3] = -8.532;
		FeedForwardNetwork_train(ffn, inputs, expectedOutputs);
	}
	// Printing results
	printf("--------------------------------------------------------------------\n");
	printf("| Input   | AND Neuron  | OR Neuron   | XOR Neuron | Custom Neuron |\n");
	printf("--------------------------------------------------------------------\n");
	inputs[0] = 0;
	inputs[1] = 0;
	results = FeedForwardNetwork_activate(ffn, inputs);
	printf("| (0,0)   | %f    | %f    | %f   | %f      |\n", results[0], results[1], results[2], results[3]);
	printf("--------------------------------------------------------------------\n");
	free(results);
	inputs[0] = 0;
	inputs[1] = 1;
	results = FeedForwardNetwork_activate(ffn, inputs);
	printf("| (0,1)   | %f    | %f    | %f   | %f      |\n", results[0], results[1], results[2], results[3]);
	printf("--------------------------------------------------------------------\n");
	free(results);
	inputs[0] = 1;
	inputs[1] = 0;
	results = FeedForwardNetwork_activate(ffn, inputs);
	printf("| (1,0)   | %f    | %f    | %f   | %f      |\n", results[0], results[1], results[2], results[3]);
	printf("--------------------------------------------------------------------\n");
	free(results);
	inputs[0] = 1;	
	inputs[1] = 1;
	results = FeedForwardNetwork_activate(ffn, inputs);
	printf("| (1,1)   | %f    | %f    | %f   | %f      |\n", results[0], results[1], results[2], results[3]);
	printf("--------------------------------------------------------------------\n");
	free(results);

	// Calling the destructor for the network
	FeedForwardNetwork_destroy(ffn);

	return 0;
}

