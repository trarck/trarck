/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreeziidaemon@yahoo.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.blogspot.com
 * 
*/

//This is the engine :-).

//Animate sprite
function Animate()
{
//It takes the name, the status and the actual frame and apply that image
    var sprite=this;
    
    if(sprite.image!=undefined)//If exists the image object
    {
		if(!sprite.loopAnimation)
    	{
      		sprite.loopAnimation=true;
    	}
    	
		sprite.image.src=SpriteFolder+sprite.name+'/'+sprite.status+"/"+Frame+sprite.frame+ImgExt;
		
		sprite.image.onerror=function(){sprite.image.src=SpriteFolder+sprite.name+'/'+Frame+ImgExt; sprite.loopAnimation=false;};
	
		if(sprite.frame<sprite.nframes-1)
		{
			sprite.frame+=1;
		}else{
			sprite.frame=0;
		}
		
    	if(sprite.loopAnimation)
		{
    		setTimeout(function(){sprite.Animate();},fps);
	    }else{
      		sprite.frame=0;
    	}
	}
}

function StopAnimate()
{
  this.loopAnimation=false;
}

function ChangeText(text)
{
    document.getElementById(this.name).firstChild.data=text;
}

function RemoveText(text)
{
    document.body.removeChild(document.getElementById(this.div))
}

//To another screen, passing game data
function GotoScreen(scnum)
{
		this.gameparams="index.html?"+scnum;
		
		if(invnum.length > 0)
		{
			for(i=0;i<invnum.length;i++)
			{
				if(invnum[i]!=undefined){this.gameparams+="&"+invnum[i].fromDiv;}
			}
		}
        
		this.gameparams+="&break";
		for(i=0;i<ObjectsUsed.length;i++)
		{
			this.gameparams+="&"+ObjectsUsed[i];
		}
		
		this.gameparams+="&break";
		for(i=0;i<GameParameters.length;i++)
		{
			this.gameparams+="&"+GameParameters[i];
		}
		window.location.href=this.gameparams;

}

//Set the text to say when speak with an object
function SetConversation(textArray)
{
  this.conversationText=textArray;
  this.conversationPart=0;
}

//With this functions we indicate which objects we can take
function SetTakableObjects(objects)
{
  for(var i=0;i<objects.length;i++)
  {
    objects[i].take=Take;
  }
    
}

//With this functions we indicate which objects we can take
function SetSpeakableObjects(objects)
{
  for(var i=0;i<objects.length;i++)
  {
    objects[i].speak=Speak;
  }
    
}

//It sets where the player can move to and where not.
function SetScreenLimits(x,x2,y)
{
  leftLimit=x;
  rightLimit=x2;
  verticalLimit=y;
}

function SetDefaultScreen(theScreen)
{
	defaultScreen=theScreen;
}

//Flip horizontally a sprite
function FlipSprite()
{
  if(this.status==LeftStatus)
  {
  	this.status=RightStatus;
  }else{
  	this.status=LeftStatus;
  }
  
}

function HideSprite()
{
	this.style.visibility="hidden";
}

function ShowSprite()
{
	this.style.visibility="visible";
}

function DestroyObject(object)
{
    document.body.removeChild(document.getElementById(object.divname)); //Remove the sprite layer    
}

function DestroyText(object)
{
    document.body.removeChild(document.getElementById(object.div)); //Remove the text layer
}

function IsDoorTo(theScreen)
{
	this.use=function(){GotoScreen(theScreen);};
}

function ObjectUsed(TheObject)
{
	return SearchObject(TheObject.divname,ObjectsUsed);
}

function SearchParameter(parameter)
{
	this.found=false;
	
	for(i=0;i<GameParameters.length && !this.found;i++)
	{
		if(GameParameters[i]==parameter){this.found=true;}
	}
	
	return this.found;	
}

//Sets the title of the screen
function SetTitle(titletxt)
{
	document.title=titletxt;
}

function SetFrameAnimation(nFrames)
{
	spriteframes=nFrames;
}

//Parameters to pass between screens
function CreateParameter(parameter)
{
	GameParameters[SearchEmpty(GameParameters)]=parameter;
}

//Run the game :)
function RunGame()
{
  window.onload=Onloadfunctions;
}

function Onloadfunctions()
{
	GetVariables();
	Main();
	UpdateInventory();
	Preload();
	
}
