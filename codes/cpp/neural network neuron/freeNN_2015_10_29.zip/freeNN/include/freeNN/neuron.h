#ifndef FNN_NEURON_H
#define FNN_NEURON_H

#ifdef __cplusplus
extern "C" {
#endif

#define NEURON_STR_BUFFER_SIZE 64
#define NEURON_STR_INC_SIZE 256
#define NEURON_STR_READ_BUFFER_SIZE 1048576

static const char *NEURON_STR_START = "_neuron_start_";
static const char *NEURON_STR_END = "_neuron_end_";

typedef enum NeuronActivationFunction {
	STEP_FUNCTION = 0,
	SIGMOID = 1,
	TANH = 2,
	LINEAR = 3
} NeuronActivationFunction;

typedef struct Neuron {
	unsigned numInputs_;
	double *weights_;
	double threshold_;
	int withBias_;
	NeuronActivationFunction activationFunction_;
} Neuron;

// Public
Neuron *Neuron_new(unsigned numOfInputs, int withBias, NeuronActivationFunction activationFunction);
Neuron *Neuron_new_from_string(const char *neuronStr);
void Neuron_destroy(Neuron *neuron);
double Neuron_getValue(const Neuron *neuron, const double inputs[]);
double Neuron_getResult(const Neuron *neuron, const double inputs[]);
double Neuron_getWeightAt(const Neuron *neuron, unsigned index);
const double *Neuron_getWeights(const Neuron *neuron);
unsigned Neuron_getNumOfInputs(const Neuron *neuron);
double Neuron_getThreshold(const Neuron *neuron);
void Neuron_setWeightAt(Neuron *neuron, unsigned index, double weight);
void Neuron_setWeights(Neuron *neuron, const double *weights);
void Neuron_setThreshold(Neuron *neuron, double threshold);
char *Neuron_toString(const Neuron *neuron);

// Private
void _Neuron_appendToString(char **dest, const char *src, unsigned *used_size, unsigned *alloc_size);
double _Neuron_getRandomDouble();
void _Neuron_getValueFromString(const char *string, const char *prefix, char *buffer);

#ifdef __cplusplus
}
#endif

#endif

