package gui;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import anim.Animation;
import anim.MechModule;

public class MModelDlg extends Dialog implements ActionListener, ItemListener
{
	/** ���а汾ID */
	private static final long serialVersionUID = -196517482456320193L;

	private final static String[] lab = {
			"Speed X", "Speed Y", "Acceleration X", "Acceleration Y"
	};

	MechModule model;
	Animation actor;
	Checkbox cbAll;
	Label txtPreiousWarning;//dong:show the actor use the previuos mechanic model

	TextField[] fldPar = new TextField[lab.length];
	Checkbox[] cbName = new Checkbox[lab.length];

	public MModelDlg(Frame owner, Animation a, MechModule m)
	{
		super(owner, "Edit MechModel", true);
		setSize(240, 180);
		model = m;
		actor = a;
		centerOnParent(owner);
		setLayout(new GridLayout(6, 2));

		int i;
		for (i = 0; i < lab.length; i++)
		{
			cbName[i] = new Checkbox(lab[i]);
			cbName[i].addItemListener(this);
			add(cbName[i]);
			fldPar[i] = new TextField();
			add(fldPar[i]);
		}
		cbAll = new Checkbox("All");
		cbAll.addItemListener(this);
		add(cbAll);
		txtPreiousWarning = new Label("");
		add(txtPreiousWarning);
		Button btn = new Button("Save");
		btn.addActionListener(this);
		add(btn);
		btn = new Button("Cancel");
		btn.addActionListener(this);
		add(btn);
		refresh();
	}

	private void refresh()
	{
		int i;
		boolean isall = true;

		for (i = 0; i < cbName.length; i++)
		{
			if ((model.flag & (1 << i)) == 0)
			{
				isall = false;
				cbName[i].setState(false);
			} else
			{
				cbName[i].setState(true);
			}
			fldPar[i].setText(Double.toString(((double) model.par[i]) / MechModule.FRAC));
		}
		cbAll.setState(isall);
	}

	private void centerOnParent(Component comp)
	{
		setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2, comp.getLocation().y
				+ (comp.getSize().height - getSize().height) / 2);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getActionCommand() == "Save")
		{
			saveValues();
			dispose();
		} else if (e.getActionCommand() == "Cancel")
		{
			dispose();
		}
	}

	private void saveValues()
	{
		int i;
		double dv;

		model.flag = 0;
		for (i = 0; i < fldPar.length; i++)
		{
			if (cbName[i].getState())
			{
				model.flag |= 1 << i;
				dv = (Double.valueOf(fldPar[i].getText())).doubleValue();
				model.par[i] = (int) (dv * MechModule.FRAC);
			} else
			{
				dv = 0;
				model.par[i] = (int) (dv * MechModule.FRAC);
			}
		}
	}

	public void itemStateChanged(ItemEvent e)
	{
		if (e.getSource() == cbAll)
		{
			int i;
			model.flag = 0;
			if (cbAll.getState())
			{
				for (i = 0; i < fldPar.length; i++)
				{
					model.flag |= 1 << i;
				}
			}
			refresh();

		}
	}

	static final String TEXT_PRE = "Previous";
}