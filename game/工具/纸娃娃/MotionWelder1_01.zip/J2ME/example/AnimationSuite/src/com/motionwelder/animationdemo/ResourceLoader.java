/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

import com.studio.motionwelder.MSprite;
import com.studio.motionwelder.MSpriteImageLoader;

/**
 * Resource Loader: Class to load Images
 * @author Nitin Pokar (pokar.nitin@gmail.com)
 *
 */

public class ResourceLoader implements MSpriteImageLoader{
	
	static private ResourceLoader resourceLoader;
	private ResourceLoader(){
		
	}
	
	static public ResourceLoader getInstance(){
		if(resourceLoader==null){
			resourceLoader = new ResourceLoader();
		}
		
		return resourceLoader;
	}
	
	/**
	 *  Function : LoadImage will be called while loading .anu.
	 *  This version of Load Image will be called when .anu is loaded without chopping images
     *  In this example we have loaded .anu where we have passed true to MSpriteLoader, hence this function will be called
	 */
	public Image[] loadImage(String spriteName,int imageId,int orientationUsedInStudio){
		// detrmine whether i need flipped version in my game
		boolean doYouNeedHFlippedSpriteInYourgame=false;
		boolean doYouNeedVFlippedSpriteInYourgame=false;
		
		Image[] images = new Image[3];
		if(spriteName.equals("/animationsuite/animationsuite.anu")){
			doYouNeedHFlippedSpriteInYourgame = false;
			doYouNeedVFlippedSpriteInYourgame = false; // to be used if, i m flipping animation
			
			if(imageId==0)
				images[0] = loadImage("/animationsuite/get.png");
			else if(imageId==1)
				images[0] = loadImage("/animationsuite/mainmenu.png");
			else if(imageId==2)
				images[0] = loadImage("/animationsuite/gameover.png");
		}
		
		// This will never be called, as flip is not used.
		
		/** Please don't load this if using Nokia Direct Graphics */
		if(orientationUsedInStudio==MSprite.ORIENTATION_FLIP_H || orientationUsedInStudio==MSprite.ORIENTATION_FLIP_BOTH_H_V || doYouNeedHFlippedSpriteInYourgame ) // flipH
			images[1] = Image.createImage(images[0],0,0,images[0].getWidth(),images[0].getHeight(),Sprite.TRANS_MIRROR);

		/** Please don't load this if using Nokia Direct Graphics */
		if(orientationUsedInStudio==MSprite.ORIENTATION_FLIP_V || orientationUsedInStudio==MSprite.ORIENTATION_FLIP_BOTH_H_V || doYouNeedVFlippedSpriteInYourgame ) // flipH
			images[1] = Image.createImage(images[0],0,0,images[0].getWidth(),images[0].getHeight(),Sprite.TRANS_MIRROR);

		return images;
	}
	
	/**
	 *  Function : LoadImageClip will be called while loading .anu.
	 *  This version of Load Image will be called when .anu is loaded with chopped images
     *  In this example we have not loaded .anu with passing true in MSpriteLoader, hence this function will never be called
	 */
	public Image[] loadImageClip(String spriteName,int imageId,int x,int y,int w,int h,int orientationUsedInStudio){
		// returning null, as here we dont want to clips the images 
		return null;
	}
	
	public static Image loadImage(String str){
		try{
			return Image.createImage(str);
		}catch (Exception e) {
			System.out.println("Error loading Image " + str);
		}
		return null;
	}
}
