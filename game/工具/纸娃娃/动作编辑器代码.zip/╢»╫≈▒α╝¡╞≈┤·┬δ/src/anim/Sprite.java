package anim;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.io.*;
import java.awt.geom.*;
import org.w3c.dom.*;

public class Sprite implements Cloneable
{
    public int idModule;
    public AffineTransform trans = new AffineTransform();

    public Sprite()
    {
    }

    public Sprite(int id, int _x, int _y)
    {
        idModule = id;
        trans.translate(_x, _y);
    }

    public boolean isFlipX()
    {
        return (trans.getScaleX() < 0);
    }

    public boolean isFlipY()
    {
        return (trans.getScaleY() < 0);
    }

    public void flipX()
    {
        AffineTransform a = new AffineTransform();
        a.scale( -1, 1);
        a.concatenate(trans);
        trans = a;
    }

    public void flipY()
    {
        AffineTransform a = new AffineTransform();
        a.scale(1, -1);
        a.concatenate(trans);
        trans = a;
    }

    public Object clone()
    {
        Sprite spt = new Sprite();
        spt.idModule = idModule;
        spt.trans = (AffineTransform)trans.clone();
        return spt;
    }

    public void exportXML(Document document, Element parent)
    {
        double[] d = new double[6];

        Element e = document.createElement("Sprite");
        parent.appendChild(e);
        e.setAttribute("module_id", String.valueOf(idModule));

        trans.getMatrix(d);
        e.setAttribute("m00", String.valueOf(d[0]));
        e.setAttribute("m10", String.valueOf(d[1]));
        e.setAttribute("m01", String.valueOf(d[2]));
        e.setAttribute("m11", String.valueOf(d[3]));
        e.setAttribute("m02", String.valueOf(d[4]));
        e.setAttribute("m12", String.valueOf(d[5]));
    }

    public static Sprite fromXML(Element e, Animation anim)
    {
        Sprite spt = new Sprite();
        spt.idModule = Integer.parseInt(e.getAttribute("module_id"));
        if (e.getAttribute("flag").length() == 0)
        {
            double m00 = Double.parseDouble(e.getAttribute("m00"));
            double m01 = Double.parseDouble(e.getAttribute("m01"));
            double m02 = Double.parseDouble(e.getAttribute("m02"));
            double m10 = Double.parseDouble(e.getAttribute("m10"));
            double m11 = Double.parseDouble(e.getAttribute("m11"));
            double m12 = Double.parseDouble(e.getAttribute("m12"));
            spt.trans.setTransform(m00, m10, m01, m11, m02, m12);
            // update module flip info
            anim.updateModuleFlip(spt);
        }
        else //old format
        {
            int flag = Integer.parseInt(e.getAttribute("flag"));
            Module mod = (Module)anim.modules.get(spt.idModule);
            if ((flag & 1) != 0)
            {
                spt.flipX();
                spt.Translate(mod.w, 0);
            }
            if ((flag & 2) != 0)
            {
                spt.flipY();
                spt.Translate(0, mod.h);
            }
            spt.Translate(Integer.parseInt(e.getAttribute("x")), Integer.parseInt(e.getAttribute("y")));
        }
        return spt;
    }

    public void exportForBrew(DataOutputStream os)
        throws IOException
    {
        /*		os.writeByte(idModule);
          os.writeByte(flag);
          os.writeByte(x);
          os.writeByte(y);*/
    }

    public static Sprite createFromAni(DataInputStream is, Animation anim)
        throws IOException
    {
        Sprite spt = new Sprite();
        spt.idModule = is.readInt();
        int flag = is.readInt();
        Module mod = (Module)anim.modules.get(spt.idModule);
        if ((flag & 1) != 0)
        {
            spt.flipX();
            spt.Translate(mod.w, 0);
        }
        if ((flag & 2) != 0)
        {
            spt.flipY();
            spt.Translate(0, mod.h);
        }
        spt.Translate(is.readInt(), is.readInt());
        return spt;
    }

    public void Scale(double f)
    {
        double[] matrix = new double[6];
        trans.getMatrix(matrix);
        matrix[4] = (int)(matrix[4] * f + 0.5);
        matrix[5] = (int)(matrix[5] * f + 0.5);
        trans.setTransform(matrix[0], matrix[1], matrix[2],
                           matrix[3], matrix[4], matrix[5]);
    }

    public void Translate(double x, double y)
    {
        AffineTransform a = new AffineTransform();
        a.translate(x, y);
        a.concatenate(trans);
        trans = a;
    }

    public void Rotate(int degree)
    {
        AffineTransform a = new AffineTransform();
        a.rotate(Math.toRadians(degree));
        a.concatenate(trans);
        trans = a;
    }

    boolean isEqual(Sprite dst)
    {
        return dst.idModule == idModule && dst.trans.equals(trans);
    }
}
