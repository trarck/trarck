#!/bin/bash

Commandlet-Tools url mailto: ? body "$1"