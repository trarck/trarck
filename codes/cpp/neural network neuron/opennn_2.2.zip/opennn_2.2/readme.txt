The .pro files are project files for the Qt Creator IDE, which can be downloaded from qt-project.org. Note that OpenNN does not make use of the Qt library. 

The documentation can be found at the official OpenNN site artelnics.com/opennn.



