/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.fontdemo.screens;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.motionwelder.fontdemo.MainCanvas;
import com.motionwelder.fontdemo.utils.Screen;

public class SplashScreen implements Screen{
	
	public SplashScreen(){
		try{
			logoImage = Image.createImage("/logo.png");
		}catch (Exception e) {}
	}
	
	int ctr;
	Image logoImage;
	public void paint(Graphics g){
		
		g.drawImage(logoImage,0,0,20);
		if(ctr>=15){
			MainCanvas.switchScreen(new InfoAboutCplScreen());
		}
	}
	
	public void update(){
		ctr++;
	}
	
	

}
