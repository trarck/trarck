package anim;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.io.*;
import org.w3c.dom.*;

public class Module
{
    public int x, y, w, h;
    public boolean flipX, flipY;
    public int idImage;

    public Module()
    {
    }

    public Module(int _x, int _y, int _w, int _h, int _idImage)
    {
        x = _x;
        y = _y;
        w = _w;
        h = _h;
        idImage = _idImage;
    }

    public void saveToAni(DataOutputStream os)
        throws IOException
    {
        os.writeInt(x);
        os.writeInt(y);
        os.writeInt(w);
        os.writeInt(h);
    }

    public void exportXML(Document document, Element parent)
    {
        Element e = document.createElement("Module");
        parent.appendChild(e);
        e.setAttribute("x", String.valueOf(x));
        e.setAttribute("y", String.valueOf(y));
        e.setAttribute("w", String.valueOf(w));
        e.setAttribute("h", String.valueOf(h));
        e.setAttribute("image_id", String.valueOf(idImage));
    }

    public static Module fromXML(Element e)
    {
        Module mod = new Module();
        mod.x = Integer.parseInt(e.getAttribute("x"));
        mod.y = Integer.parseInt(e.getAttribute("y"));
        mod.w = Integer.parseInt(e.getAttribute("w"));
        mod.h = Integer.parseInt(e.getAttribute("h"));
        String tmp = e.getAttribute("image_id");
        if (tmp == "")
            mod.idImage = 0;
        else
            mod.idImage = Integer.parseInt(e.getAttribute("image_id"));
        return mod;
    }

    public static Module createFromAni(DataInputStream is)
        throws IOException
    {
        Module mod = new Module();
        mod.x = is.readInt();
        mod.y = is.readInt();
        mod.w = is.readInt();
        mod.h = is.readInt();
        return mod;
    }

    public void Scale(float f)
    {
        x *= f;
        y *= f;
        w *= f;
        h *= f;
    }

    public boolean isEqual(Module dst)
    {
        return dst.x == x && dst.y == y && dst.w == w && dst.h == h;
    }

    public Object clone()
    {
        Module m = new Module();
        m.x = x;
        m.y = y;
        m.h = h;
        m.w = w;
        m.idImage = idImage;
        return m;
    }
}
