#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "freeNN/feedforwardnetwork.h"

#ifdef __cplusplus
extern "C" {
#endif

FeedForwardNetwork *FeedForwardNetwork_new(unsigned numInputs, unsigned numOutputs, unsigned numHiddenLevels, 
											const unsigned *numNeuronsInHiddenLevels, FeedForwardNetworkSettings *settings) {
	int i;
	int j;
	FeedForwardNetwork *network = (FeedForwardNetwork*)malloc(sizeof(FeedForwardNetwork));
	network->numInputs_ = numInputs;
	network->numOutputs_ = numOutputs;
	network->numHiddenLevels_ = numHiddenLevels;
	if (settings == NULL) {
		network->settings_ = FeedForwardNetworkSettings_new_default();
		network->selfAllocatedSettings_ = 1;
	} else {
		network->settings_ = settings;
		network->selfAllocatedSettings_ = 0;
	}
	network->numNeuronsInHiddenLevels_ = (unsigned*)malloc(numHiddenLevels * sizeof(unsigned));
	network->neurons_ = (Neuron***)malloc((numHiddenLevels + 1) * sizeof(Neuron**));
	unsigned currLevelNumInputs = numInputs;
	// Creating hidden levels (considering input level as neuron-less)
	for (i = 0 ; i < numHiddenLevels ; i++) {
		network->numNeuronsInHiddenLevels_[i] = numNeuronsInHiddenLevels[i];
		network->neurons_[i] = (Neuron**)malloc(numNeuronsInHiddenLevels[i] * sizeof(Neuron*));
		for (j = 0 ; j < numNeuronsInHiddenLevels[i] ; j++) {
			network->neurons_[i][j] = Neuron_new(currLevelNumInputs, network->settings_->withBias_, network->settings_->hiddenLayerType_);
		}
		currLevelNumInputs = numNeuronsInHiddenLevels[i];
	}
	// Creating output level
	network->neurons_[numHiddenLevels] = (Neuron**)malloc(numOutputs * sizeof(Neuron*));
	for (j = 0 ; j < numOutputs ; j++) {
		network->neurons_[numHiddenLevels][j] = Neuron_new(currLevelNumInputs, network->settings_->withBias_, network->settings_->outputLayerType_);
	}
	
	return network;
}

FeedForwardNetwork *FeedForwardNetwork_new_from_string(const char *networkStr) {
	FeedForwardNetworkSettings *settings = FeedForwardNetworkSettings_new_from_string(networkStr);
	if (settings == NULL) {
		return NULL;
	}
	char buffer[NEURON_STR_READ_BUFFER_SIZE];
	_Neuron_getValueFromString(networkStr, "numInputs=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	int numInputs = atoi(buffer);
	_Neuron_getValueFromString(networkStr, "numOutputs=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	int numOutputs = atoi(buffer);
	_Neuron_getValueFromString(networkStr, "numHiddenLevels=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	int numHiddenLevels = atoi(buffer);
	_Neuron_getValueFromString(networkStr, "numNeuronsInHiddenLevels=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	unsigned *numNeuronsInHiddenLevels = (unsigned*)malloc(numHiddenLevels * sizeof(unsigned));
	int i = 0;
	char *valStart = buffer;
	while (1) {
		char *nextSep = strstr(valStart, ",");
		if (nextSep == NULL) {
			numNeuronsInHiddenLevels[i] = atoi(valStart);
			i++;
			break;
		}
		char *val = (char*)malloc((nextSep - valStart + 2) * sizeof(char));
		memcpy(val, valStart, nextSep - valStart + 1);
		val[nextSep - valStart + 1] = '\0';
		numNeuronsInHiddenLevels[i] = atoi(val);
		free(val);
		valStart = nextSep + 1;
		i++;
	}
	if (i != numHiddenLevels) {
		return NULL;
	}
	FeedForwardNetwork *network = (FeedForwardNetwork*)malloc(sizeof(FeedForwardNetwork));
	network->settings_ = settings;
	network->selfAllocatedSettings_ = 1;
	network->numInputs_ = numInputs;
	network->numOutputs_ = numOutputs;
	network->numHiddenLevels_ = numHiddenLevels;
	network->numNeuronsInHiddenLevels_ = numNeuronsInHiddenLevels;
	network->neurons_ = (Neuron***)malloc((numHiddenLevels + 1) * sizeof(Neuron**));
	int j;
	int k;
	char *neuronStrPtr = (char*)malloc((strlen(networkStr) + 1) * sizeof(char));
	char *neuronStrPtrSav = neuronStrPtr;
	strcpy(neuronStrPtr, networkStr);
	for (i = 0 ; i < (numHiddenLevels + 1) ; i++) {
		int numNeuronsInLevel = (i == numHiddenLevels) ? numOutputs : numNeuronsInHiddenLevels[i];
		network->neurons_[i] = (Neuron**)malloc(numNeuronsInLevel * sizeof(Neuron*));
		for (j = 0 ; j < numNeuronsInLevel ; j++) {
			neuronStrPtr = strstr(neuronStrPtr, NEURON_STR_START);
			if (neuronStrPtr == NULL) {
				free(network);
				free(numNeuronsInHiddenLevels);
				free(neuronStrPtrSav);
				return NULL;
			}
			network->neurons_[i][j] = Neuron_new_from_string(neuronStrPtr);
			neuronStrPtr++;
		}
	}
	free(neuronStrPtrSav);
	return network;
}

FeedForwardNetwork *FeedForwardNetwork_new_from_file(const char *filePath) {
	char *file_contents;
	long input_file_size;
	FILE *input_file = fopen(filePath, "rb");
	if (input_file == NULL) {
		return NULL;
	}
	fseek(input_file, 0, SEEK_END);
	input_file_size = ftell(input_file);
	rewind(input_file);
	file_contents = malloc(input_file_size * (sizeof(char)));
	fread(file_contents, sizeof(char), input_file_size, input_file);
	fclose(input_file);
	
	FeedForwardNetwork *ffn = FeedForwardNetwork_new_from_string(file_contents);
	free(file_contents);
	
	return ffn;
}

void FeedForwardNetwork_destroy(FeedForwardNetwork *network) {
	int i;
	int j;
	for (i = 0 ; i < network->numHiddenLevels_ ; i++) {
		for (j = 0 ; j < network->numNeuronsInHiddenLevels_[i] ; j++) {
			Neuron_destroy(network->neurons_[i][j]);
		}
		free(network->neurons_[i]);
	}
	for (j = 0 ; j < network->numOutputs_ ; j++) {
		Neuron_destroy(network->neurons_[network->numHiddenLevels_][j]);
	}
	free(network->neurons_[network->numHiddenLevels_]);
	free(network->neurons_);
	free(network->numNeuronsInHiddenLevels_);
	if (network->selfAllocatedSettings_) {
		free(network->settings_);
	}
	free(network);	
}

void FeedForwardNetwork_train(FeedForwardNetwork *network, const double *inputs, const double *expectedOutputs) {
	_FeedForwardNetwork_train(network, inputs, expectedOutputs, 0, NULL);
}

int FeedForwardNetwork_train_fast(FeedForwardNetwork *network, const double *inputs, const double *expectedOutputs, int (*binaryChecker)(const double*, const double*)) {
	return _FeedForwardNetwork_train(network, inputs, expectedOutputs, 1, binaryChecker);
}


int _FeedForwardNetwork_train(FeedForwardNetwork *network, const double *inputs, const double *expectedOutputs, int fastMode, int (*binaryChecker)(const double*, const double*)) {
	int i;
	int j;
	int k;
	double **inputsForAllLayers;
	double *results = _FeedForwardNetwork_activateWithTrace(network, inputs, &inputsForAllLayers);
	if (fastMode) {
		if (binaryChecker(expectedOutputs, results)) {
			free(results);
			_FeedForwardNetwork_freeInputsOrErrorsTrace(network, inputsForAllLayers);
			return 0;
		}
	}
	double **errorsForAllLayers = (double**)malloc((network->numHiddenLevels_ + 1) * sizeof(double*));
	double *errorsOfCurrentLayer = (double*)malloc(network->numOutputs_ * sizeof(double));
	
	unsigned numNeuronsInForwardLevel = 0;
	for (i = network->numHiddenLevels_  ; i >= 0 ; i--) {
		unsigned numNeuronsInCurrentLevel = (i < network->numHiddenLevels_) ? network->numNeuronsInHiddenLevels_[i] : network->numOutputs_;
		Neuron **currLayer = network->neurons_[i];
		for (j = 0 ; j < numNeuronsInCurrentLevel ; j++) {
			// Output level case
			if (i == network->numHiddenLevels_) {
				// Output level is constantly linear
				if (network->settings_->outputLayerType_ == SIGMOID) {
					errorsOfCurrentLayer[j] = (expectedOutputs[j] - results[j]) * results[j] * (1 - results[j]);
				} else if (network->settings_->outputLayerType_ == TANH) {
					errorsOfCurrentLayer[j] = (expectedOutputs[j] - results[j]) * (1.0 - pow(tanh(results[j]), 2));
				} else {
					errorsOfCurrentLayer[j] = (expectedOutputs[j] - results[j]);
				}
			} else {
				double sumOfMults = 0;
				for (k = 0 ; k < numNeuronsInForwardLevel ; k++) {
					Neuron *p = network->neurons_[i + 1][k];				
					sumOfMults += errorsForAllLayers[i + 1][k] * Neuron_getWeightAt(p, j);
				}
				double deriviative;
				if (network->settings_->hiddenLayerType_ == SIGMOID) { 
					deriviative = (inputsForAllLayers[i + 1][j] * (1.0 - inputsForAllLayers[i + 1][j]));
				} else if (network->settings_->hiddenLayerType_ == TANH) {
					deriviative = (1.0 - pow(tanh(inputsForAllLayers[i + 1][j]), 2));
				} else {
					deriviative = inputsForAllLayers[i + 1][j];
				}

				errorsOfCurrentLayer[j] = deriviative * sumOfMults;
			}

			Neuron *p = currLayer[j];
			for (k = 0 ; k < Neuron_getNumOfInputs(p) ; k++) {
				double newWeight = Neuron_getWeightAt(p, k);
				double trainingRate = (i == network->numHiddenLevels_) ? network->settings_->outputLayerTrainingRate_ : network->settings_->trainingRate_;
				newWeight += trainingRate * errorsOfCurrentLayer[j] * inputsForAllLayers[i][k];
				Neuron_setWeightAt(p, k, newWeight);
			}
		}
		errorsForAllLayers[i] = errorsOfCurrentLayer;
		if (i != 0) {
			errorsOfCurrentLayer = (double*)malloc(network->numNeuronsInHiddenLevels_[i - 1] * sizeof(double));
		}
		numNeuronsInForwardLevel = numNeuronsInCurrentLevel;
	}
	_FeedForwardNetwork_freeInputsOrErrorsTrace(network, inputsForAllLayers);
	_FeedForwardNetwork_freeInputsOrErrorsTrace(network, errorsForAllLayers);

	return 1;
}

double *_FeedForwardNetwork_activateWithTrace(const FeedForwardNetwork *network, const double *inputs, double ***traceData) {
	int i;
	int j;
	double **inputsForAllLayers = (double**)malloc((network->numHiddenLevels_ + 1) * sizeof(double*));
	double *inputsForCurrentLayer = (double*)malloc(network->numInputs_ * sizeof(double));
	
	for (i = 0 ; i < network->numInputs_ ; i++) {
		inputsForCurrentLayer[i] = inputs[i];
	}
	
	for (i = 0 ; i < network->numHiddenLevels_ + 1 ; i++) {
		unsigned numNeuronsInCurrentLevel = (i < network->numHiddenLevels_) ? network->numNeuronsInHiddenLevels_[i] : network->numOutputs_;
		double *inputsForNextLayer = (double*)malloc(numNeuronsInCurrentLevel * sizeof(double));
		Neuron **currLayer = network->neurons_[i];
		for (j = 0 ; j < numNeuronsInCurrentLevel ; j++) {
			Neuron *p = currLayer[j];
			double result = Neuron_getResult(p, inputsForCurrentLayer);
			inputsForNextLayer[j] = result;
		}
		inputsForAllLayers[i] = inputsForCurrentLayer;
		inputsForCurrentLayer = inputsForNextLayer;
	}
	*traceData = inputsForAllLayers;
	
	return inputsForCurrentLayer;
}

double *FeedForwardNetwork_activate(const FeedForwardNetwork *network, const double *inputs) {
	double **inputsForAllLayers;
	double *results = _FeedForwardNetwork_activateWithTrace(network, inputs, &inputsForAllLayers);
	
	_FeedForwardNetwork_freeInputsOrErrorsTrace(network, inputsForAllLayers);
	
	return results;
}

char *FeedForwardNetwork_toString(const FeedForwardNetwork *network) {
	char *str = NULL;
	char *settings_str = FeedForwardNetworkSettings_toString(network->settings_);
	unsigned settings_str_len = strlen(settings_str);
	unsigned used_size = 0;
	unsigned alloc_size = 0;
	char buffer[64] = "";
	unsigned i;
	unsigned j;

	sprintf(buffer, "%s\n", FEEDFORWARDNETWORK_STR_START);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	str = (char*)realloc(str, (alloc_size + settings_str_len + 1) * sizeof(char));
	strcat(str, settings_str);
	free(settings_str);
	used_size += settings_str_len;
	alloc_size += settings_str_len + 1;
	sprintf(buffer, "\nnumInputs=%u\n", network->numInputs_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	sprintf(buffer, "numOutputs=%u\n", network->numOutputs_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	sprintf(buffer, "numHiddenLevels=%u\n", network->numHiddenLevels_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	_Neuron_appendToString(&str, "numNeuronsInHiddenLevels=", &used_size, &alloc_size);
	for (i = 0 ; i < network->numHiddenLevels_ ; i++) {
		sprintf(buffer, (i == network->numHiddenLevels_ - 1) ? "%u\n" : "%u,", network->numNeuronsInHiddenLevels_[i]);
		_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	}
	for (i = 0 ; i < (network->numHiddenLevels_ + 1) ; i++) {
		int numNeuronsInLevel = (i == network->numHiddenLevels_) ? network->numOutputs_ : network->numNeuronsInHiddenLevels_[i];
		for (j = 0 ; j < numNeuronsInLevel ; j++) {
			char *neuron_str = Neuron_toString(network->neurons_[i][j]);
			unsigned neuron_str_len = strlen(neuron_str);
			str = (char*)realloc(str, (alloc_size + neuron_str_len + 1) * sizeof(char));
			strcat(str, neuron_str);
			free(neuron_str);
			used_size += neuron_str_len;
			alloc_size += neuron_str_len + 1;
			_Neuron_appendToString(&str, "\n", &used_size, &alloc_size);
		}
	}
	_Neuron_appendToString(&str, FEEDFORWARDNETWORK_STR_END, &used_size, &alloc_size);

	return str;
}

int FeedForwardNetwork_saveToFile(const FeedForwardNetwork *network, const char *pathToFile) {
	FILE *f = fopen(pathToFile, "w");
	if (f == NULL) {
		return 1;
	}
	char *networkStr = FeedForwardNetwork_toString(network);
	fprintf(f, "%s", networkStr);
	free(networkStr);
	fclose(f);
	
	return 0;
}

void _FeedForwardNetwork_freeInputsOrErrorsTrace(const FeedForwardNetwork *network, double **inputsOrErrors) {
	int i;
	for( i = 0 ; i < network->numHiddenLevels_ + 1 ; i++) {
		free(inputsOrErrors[i]);
	}
	free(inputsOrErrors);
}

FeedForwardNetworkSettings *FeedForwardNetworkSettings_new(int withBias, double trainingRate, double outputLevelTrainingRate,
							    NeuronActivationFunction hiddenLayerType, NeuronActivationFunction outputLayerType) {
	FeedForwardNetworkSettings *settings = (FeedForwardNetworkSettings*)malloc(sizeof(FeedForwardNetworkSettings));
	settings->withBias_ = withBias;
	settings->trainingRate_ =  trainingRate;
	settings->outputLayerTrainingRate_ = outputLevelTrainingRate;
	settings->hiddenLayerType_ = hiddenLayerType;
	settings->outputLayerType_ = outputLayerType;
	
	return settings;
}

FeedForwardNetworkSettings *FeedForwardNetworkSettings_new_default() {
	FeedForwardNetworkSettings *settings = (FeedForwardNetworkSettings*)malloc(sizeof(FeedForwardNetworkSettings));
	settings->withBias_ = 1;
	settings->trainingRate_ = 1.0;
	settings->outputLayerTrainingRate_ = 0.2;
	settings->hiddenLayerType_ = SIGMOID;
	settings->outputLayerType_ = SIGMOID;
	
	return settings;
}

FeedForwardNetworkSettings *FeedForwardNetworkSettings_new_from_string(const char *settingsStr) {
	char buffer[NEURON_STR_READ_BUFFER_SIZE];
	_Neuron_getValueFromString(settingsStr, "withBias=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	int withBias = atoi(buffer);
	_Neuron_getValueFromString(settingsStr, "trainingRate=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	double trainingRate = atof(buffer);
	_Neuron_getValueFromString(settingsStr, "outputLayerTrainingRate=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	double outputLayerTrainingRate = atof(buffer);
	_Neuron_getValueFromString(settingsStr, "hiddenLayerType=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	int hiddenLayerType = atoi(buffer);
	_Neuron_getValueFromString(settingsStr, "outputLayerType=", buffer);
	if (strcmp(buffer, "") == 0) {
		return NULL;
	}
	int outputLayerType = atoi(buffer);


	FeedForwardNetworkSettings *settings = (FeedForwardNetworkSettings*)malloc(sizeof(FeedForwardNetworkSettings));
	settings->withBias_ = withBias;
	settings->trainingRate_ = trainingRate;
	settings->outputLayerTrainingRate_ = outputLayerTrainingRate;
	settings->hiddenLayerType_ = hiddenLayerType;
	settings->outputLayerType_ = outputLayerType;
	
	return settings;
}

char *FeedForwardNetworkSettings_toString(const FeedForwardNetworkSettings *settings) {
	unsigned alloc_size = 0;
	unsigned used_size = 0;
	char *str = NULL;
	char buffer[NEURON_STR_BUFFER_SIZE] = "";
	unsigned i;


	_Neuron_appendToString(&str, FEEDFORWARDNETWORKSETTINGS_STR_START, &used_size, &alloc_size);
	sprintf(buffer, "\nwithBias=%d\n", settings->withBias_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	sprintf(buffer, "trainingRate=%f\n", settings->trainingRate_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	sprintf(buffer, "outputLayerTrainingRate=%f\n", settings->outputLayerTrainingRate_);
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	sprintf(buffer, "hiddenLayerType=%d\n", (int)(settings->hiddenLayerType_));
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	sprintf(buffer, "outputLayerType=%d\n", (int)(settings->outputLayerType_));
	_Neuron_appendToString(&str, buffer, &used_size, &alloc_size);
	_Neuron_appendToString(&str, FEEDFORWARDNETWORKSETTINGS_STR_END, &used_size, &alloc_size);

	return str;
}


#ifdef __cplusplus
}
#endif


