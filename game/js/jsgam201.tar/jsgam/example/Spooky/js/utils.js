/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreeziidaemon@yahoo.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.blogspot.com
 * 
*/


//This is the engine :-).

//Get Mouse X
function getMouseX(event)
{
	return event.offsetX?parseInt(event.offsetX):parseInt(event.pageX-document.getElementById(DivScreen).offsetLeft);	
}
//Get Mouse Y
function getMouseY(event)
{
	return event.offsetY?parseInt(event.offsetY):parseInt(event.pageY-document.getElementById(DivScreen).offsetTop);
}
//Get Sprite X
function getX()
{
	return	parseInt(this.style.left)+parseInt(this.style.width)/2;
}
//Get Sprite Y
function getY()
{
	return	parseInt(this.style.top)+parseInt(this.style.height);	
}

function getLeft()
{
	return parseInt(this.style.left);
}

function getRight()
{
	return parseInt(this.style.left)+parseInt(this.style.width);
}

//Move main sprite to mouse x,y coordinates
function MovetoMouseXY(event)
{
  if(Player!=undefined)
  {
	Player.move(getMouseX(event),getMouseY(event));
  }
}

//Needed by Move function
function gotoXY()
{
	//Move X coordinates
	if(this.toX>0)
	{
		//Move the sprite with a step and in dirx direction
		this.style.left=parseInt(this.style.left)+this.step*this.dirx;
		this.toX=this.toX-this.step;
	}else{
		this.ismovingH=false;
		if(this.ismovingV==false){
			if(this.actid!=this.id)
			{
				this.actionWith.getx()>this.getx()?this.dirx=1:this.dirx=-1;
			}		
		this.dirx==-1?this.status=LeftStatus:this.status=RightStatus;
		}
	}
	
	//Move Y coordinates
	if(this.toY>0)
	{
		this.style.top=parseInt(this.style.top)+this.step*this.diry;
		this.toY=this.toY-this.step;
		this.checkdepth();
	}else{
		this.ismovingV=false;			
		if(this.ismovingH==false){
			if(this.actid!=this.id)
			{
				this.actionWith.getx()>this.getx()?this.dirx=1:this.dirx=-1;
			}
			this.dirx==-1?this.status=LeftStatus:this.status=RightStatus;
		}
	}
	
	if(this.ismovingH==true || this.ismovingV==true){
        var tmpVar=this;
		this.mtimeout=setTimeout(function(){tmpVar.gotoxy();},30); 
	}else{
      document.getElementById('spanaction').firstChild.data=TextMenuActions;
		if(this.actionWith!=null)	
		{			
			MakeAnAction(this);
			this.actionWith=null;
		}else{	
			this.lockSprite=false;
            ActiontoDo=null;
		}

	}

}

function MakeAnAction(sprite)
{
  //switch(document.getElementById('spanaction').firstChild.data)
  switch(ActiontoDo)
  {
      case "Look":
        sprite.actionWith.look();
        break;
        
      case "Take":
        sprite.actionWith.take();
        break;
          
      case "Use":
        sprite.actionWith.use();              
        break;
            
      case "Speak":
        sprite.actionWith.speak();
        break;
            
      default:
        sprite.lockSprite=false;                      
   }
   document.getElementById('spanaction').firstChild.data=TextMenuActions;
   ActiontoDo=null;

}
//Function used for inventory & made actions
function SearchEmpty(arraytosearch)
{
	var i=0;
	while(arraytosearch[i]!=undefined)
	{
		i++;
	}
	return i;
}
//Check depth of the sprites and modify it
function CheckDepth()
{
	for(i=0;i<objectsArray.length;i++)
	{
		if(objectsArray[i]!=undefined && document.getElementById(objectsArray[i].divname)!=undefined)
		{
			if(this.gety()>objectsArray[i].gety() && this.zindex<=objectsArray[i].zindex)
			{
				this.zindex=objectsArray[i].zindex+1;
			}else{
				if(this.gety()<objectsArray[i].gety() && this.zindex>objectsArray[i].zindex)
				{
					this.zindex=objectsArray[i].zindex-1;	
				}
			}
			
			this.style.zIndex=this.zindex;	
		}
	}
}

//Add actions to the menu
function addActions(imageArray,addtoObject)
{
	for(var i=0;i<imageArray.length;i++)
	{
		var ImagetoAdd=document.createElement('IMG');
		ImagetoAdd.src=MenuFolder+imageArray[i]+ImgExt;
		preloadIcon=new Image();
		preloadIcon=ImagetoAdd.src;
		ImagetoAdd.id=imageArray[i];//The id is the action name for example "Use"
		ImagetoAdd.style.width=iconsize +"px"
		ImagetoAdd.style.height=iconsize +"px"
		addtoObject.appendChild(ImagetoAdd);
		//When you click on a image the action span takes the text from the image id, for example "Use"
		ImagetoAdd.addEventListener("click",function(){SetAction(this.id);},false);
		ImagetoAdd.addEventListener("mouseover",function(){document.getElementById(this.id).style.width=acticonsize + "px";document.getElementById(this.id).style.height =acticonsize + "px";},false);
		ImagetoAdd.addEventListener("mouseout",function(){document.getElementById(this.id).style.width=iconsize + "px";document.getElementById(this.id).style.height =iconsize + "px";},false);
	}
}

//Getting game data, like objects in inventory, etc...
function GetVariables()
{
	Varsfrom=location.search.substr(1).split("&");

//Varsfrom[i+1] is because the 0 is the number of the screen so objects are from 1. 
 if(Varsfrom.length>1)
 {
 	for(i=0;i<Varsfrom.length-1 && Varsfrom[i+1]!="break";i++)
 	{
 		AddtoInventory[i]=Varsfrom[i+1];
 	}
	i++; //Skip the break word
	j=0;
	for(i;i<Varsfrom.length-1 && Varsfrom[i+1]!="break";i++)
	{
		ObjectsUsed[j]=Varsfrom[i+1];
		j++;
	}
	
	i++;
	j=0;
	
	for(i;i<Varsfrom.length-1 && Varsfrom[i+1]!="break";i++)
	{
		GameParameters[j]=Varsfrom[i+1];
		j++;
	}
 }
}

//Search an object in the inventory or used
function SearchObject(object,inarray)
{
	this.found=false;
	
	for(i=0;i<inarray.length && !this.found;i++)
	{
		if(inarray[i]==object){this.found=true;}
	}
	return this.found;
}

function SearchDiv(divname)
{
	this.found=false;
	this.divnumber=0;
	
	for(i=0;i<objectsArray.length && !this.found;i++)
	{
		if(objectsArray[i].divname==ScreenName+"Div-"+divname+"-"+i)
		{
			this.found=true;
			this.divnumber=i+1;
		}
	}
	return this.divnumber;
}

function CleanName(strname)
{
	this.from=0;
	this.to=strname.length;
	
	for(i=0;i<strname.length-1;i++)
	{
		if(strname.charAt(i)=="-")
		{
			if(this.from==0)
			{
				this.from=i+1;
			}else{
				this.to=i;
			}
		}
	}
	
	return strname.substring(this.from,this.to);
}

function UpdateInventory()
{
	for(i=0;i<AddtoInventory.length;i++)
	{
		Taken(AddtoInventory[i],CleanName(AddtoInventory[i]));
	}	
}
