package gui;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

import anim.Action;
import anim.AniFrame;
import anim.Animation;
import anim.MechModule;
import anim.Module;
import anim.Sprite;

public class ActionDlg extends Dialog implements ActionListener, WindowListener, ItemListener, AdjustmentListener, Runnable, TextListener
{
	Animation actor, backup;
	List frameList, actionList;
	Image[] image;
	Action action;
	FrameCanvas frameView;
	TextField fldName, fldDelay;
	ActionCanvas actionView;
	Thread thread;
	Scrollbar bar;
	Label lbActionId, lbMechInfo;
	int idAction;
	boolean toquit;

	public ActionDlg(Frame owner, Animation _actor, Image[] img, int _idAction)
	{
		super(owner, "Action Window", true);
		actor = _actor;
		idAction = _idAction;
        image = new Image[img.length];
        for (int i = img.length - 1; i >= 0; i--)
            image[i] = img[i];
		action = (Action)actor.actions.elementAt(idAction);
		setSize(600, 680);
		centerOnParent(owner);

		GridBagLayout gridbag = new GridBagLayout();
		setLayout(gridbag);
		GridBagConstraints c = new GridBagConstraints();

		c.weightx = 1.0;
		c.fill = GridBagConstraints.BOTH;
		actionList = new List(15);
		actionList.addActionListener(this);
		actionList.addItemListener(this);
		gridbag.setConstraints(actionList, c);
		add(actionList);

		c.gridwidth = GridBagConstraints.REMAINDER;
		actionView = new ActionCanvas();
		gridbag.setConstraints(actionView, c);
		add(actionView);

		c.gridwidth = GridBagConstraints.RELATIVE;
		frameList = new List(15);
		frameList.addItemListener(this);
		frameList.addActionListener(this);
		gridbag.setConstraints(frameList, c);
		add(frameList);

		c.gridwidth = GridBagConstraints.REMAINDER;
		frameView = new FrameCanvas();
		gridbag.setConstraints(frameView, c);
		add(frameView);

		c.gridwidth = GridBagConstraints.REMAINDER;
		Panel btnPanel = new Panel(new GridLayout(6, 2));
		gridbag.setConstraints(btnPanel, c);
		add(btnPanel);

		lbActionId = new Label("No. " + Integer.toString(idAction) + " ");
		lbActionId.setAlignment(lbActionId.RIGHT);
		btnPanel.add(lbActionId);

		bar = new Scrollbar(Scrollbar.HORIZONTAL, idAction, 24, 0, 24 + actor.actions.size() - 1);
		bar.setSize(200, 24);
		bar.addAdjustmentListener(this);
		btnPanel.add(bar);

		Label lb = new Label("Name");
		btnPanel.add(lb);

		fldName = new TextField(action.name);
		btnPanel.add(fldName);

		lb = new Label("Delay");
		btnPanel.add(lb);

		fldDelay = new TextField("");
		fldDelay.addTextListener(this);
		btnPanel.add(fldDelay);

		Button btn = new Button("MechModel");
		btn.addActionListener(this);
		btnPanel.add(btn);

		lbMechInfo = new Label("aaa");
		btnPanel.add(lbMechInfo);

        btn = new Button("Move Up");
        btn.addActionListener(this);
        btnPanel.add(btn);

        btn = new Button("Move Down");
        btn.addActionListener(this);
        btnPanel.add(btn);

		btn = new Button("Cancel");
		btn.addActionListener(this);
		btnPanel.add(btn);

		btn = new Button("OK");
		btn.addActionListener(this);
		btnPanel.add(btn);

		addWindowListener(this);
		refreshFrameList();
		refreshActionList();
		refreshMechInfo();

		backup = actor.Clone();

		thread = new Thread(this);
		thread.start();
	}

	void refreshDelay()
	{
		if(actionList.getSelectedIndex() >= 0)
		{
			fldDelay.setEnabled(true);
			fldDelay.setText(((Integer)action.frmDelay.get(actionList.getSelectedIndex())).toString());
		}
		else
		{
			fldDelay.setEnabled(false);
			fldDelay.setText("");
		}
	}

	void refreshMechInfo()
	{
		String s = "";
		if((action.mechModule.flag & 1) != 0)
		{
			s = s + "vx = " + (action.mechModule.par[0] * 1.0 / MechModule.FRAC);
		}
		if((action.mechModule.flag & 2) != 0)
		{
			s = s + " vy = " + (action.mechModule.par[1] * 1.0 / MechModule.FRAC);
		}
		if((action.mechModule.flag & 4) != 0)
		{
			s = s + " ax = " + (action.mechModule.par[2] * 1.0 / MechModule.FRAC);
		}
		if((action.mechModule.flag & 8) != 0)
		{
			s = s + " ay = " + (action.mechModule.par[3] * 1.0 / MechModule.FRAC);
		}

		lbMechInfo.setText(s);
	}

	public void refreshActionList()
	{
		actionList.removeAll();
		int i;
		AniFrame frm;

		for(i = 0; i < action.frmIdTable.size(); i++)
		{
			int fid = ((Integer)action.frmIdTable.elementAt(i)).intValue();
			frm = (AniFrame)actor.getFrame(fid);
			actionList.add(frm.name + " (Frame " + Integer.toString(fid) + ")");
		}
	}

	public void refreshFrameList()
	{
		frameList.removeAll();
		int i;
		AniFrame frm;

		for(i = 0; i < actor.getFrameCount(); i++)
		{
			frm = (AniFrame)actor.getFrame(i);
			frameList.add(frm.name + " (Frame " + Integer.toString(i) + ")");
		}
	}

	public void refreshAll()
	{
		fldDelay.setText("");
		fldDelay.setEnabled(false);
		refreshMechInfo();
		refreshActionList();
		lbActionId.setText("No. " + idAction + " ");
		fldName.setText(action.name);
	}

	private void centerOnParent(Component comp)
	{
		setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2, comp.getLocation().y + (comp.getSize().height - getSize().height) / 2);
	}

	private boolean saveAll()
	{
		if(fldName.getText().length() == 0)
		{
			MsgBox msg = new MsgBox(AniStudioFrm.instance, "Error", "Action name can't be empty!");
			msg.show();
			return false;
		}
		if(action.name.compareTo(fldName.getText()) != 0)
		{
			if(actor.isActionNameExist(fldName.getText()))
			{
				MsgBox msg = new MsgBox(AniStudioFrm.instance, "Error", "Action name already exists!");
				msg.show();
				return false;
			}
			action.name = fldName.getText();
		}
		return true;
	}

	public void actionPerformed(ActionEvent e)
	{
		String s = e.getActionCommand();
		if(e.getSource() == frameList)
		{
			int id = frameList.getSelectedIndex();
			if(id >= 0)
			{
				action.frmIdTable.addElement(new Integer(id));
				action.frmDelay.addElement(new Integer(1));
				refreshActionList();
				actionList.select(actionList.getItemCount() - 1);
				refreshDelay();
			}
		}
		else if(e.getSource() == actionList)
		{
			int id = actionList.getSelectedIndex();
			if(id >= 0)
			{
				action.frmIdTable.removeElementAt(id);
				refreshActionList();
			}
		}
		else if(s == "OK")
		{
			if(saveAll())
			{
				AniStudioFrm.instance.refreshActionList();
				dispose();
			}
		}
		else if(s == "MechModel")
		{
			MModelDlg dlg = new MModelDlg((Frame)getParent(), actor, action.mechModule);
			dlg.show();
			refreshMechInfo();
		}
		else if(s == "Cancel")
		{
			windowClosing(null);
		}
        else if (s == "Move Up")
        {
            int id = actionList.getSelectedIndex();
            if(id > 0 && id <= actionList.getItemCount() - 1)
            {
                Object obj = action.frmIdTable.elementAt(id - 1);
                action.frmIdTable.setElementAt(action.frmIdTable.elementAt(id), id - 1);
                action.frmIdTable.setElementAt(obj, id);

                obj = action.frmDelay.elementAt(id - 1);
                action.frmDelay.setElementAt(action.frmDelay.elementAt(id), id - 1);
                action.frmDelay.setElementAt(obj, id);
                refreshActionList();
                actionList.select(id - 1);
            }
        }
        else if (s == "Move Down")
        {
            int id = actionList.getSelectedIndex();
            if(id >= 0 && id < actionList.getItemCount() - 1)
            {
                Object obj = action.frmIdTable.elementAt(id + 1);
                action.frmIdTable.setElementAt(action.frmIdTable.elementAt(id), id + 1);
                action.frmIdTable.setElementAt(obj, id);

                obj = action.frmDelay.elementAt(id + 1);
                action.frmDelay.setElementAt(action.frmDelay.elementAt(id), id + 1);
                action.frmDelay.setElementAt(obj, id);
                refreshActionList();
                actionList.select(id + 1);
            }
        }
	}

	public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		AniStudioFrm.instance.m_actor = backup;
		toquit = true;
		dispose();
	}

	public void windowActivated(java.awt.event.WindowEvent windowEvent) {
	}

	public void windowClosed(java.awt.event.WindowEvent windowEvent) {
		toquit = true;
//		thread.stop();
	}

	public void windowDeactivated(java.awt.event.WindowEvent windowEvent) {
	}

	public void windowDeiconified(java.awt.event.WindowEvent windowEvent) {
	}

	public void windowIconified(java.awt.event.WindowEvent windowEvent) {
	}

	public void windowOpened(java.awt.event.WindowEvent windowEvent) {
	}

	public void itemStateChanged(ItemEvent e)
	{
		if(e.getSource() == frameList)
		{
			frameView.setCurFrame(frameList.getSelectedIndex());
		}
		else if(e.getSource() == actionList)
		{
			refreshDelay();
		}
	}

	public void drawSprite(Graphics g, AniFrame frm, int id, int x, int y, int scale, boolean isSelected)
	{
		Sprite spt = (Sprite)frm.sprites.elementAt(id);
		Module mod = (Module)actor.modules.elementAt(spt.idModule);
		Graphics2D g2d = (Graphics2D)g;

		AffineTransform origXform = g2d.getTransform();
		AffineTransform newXform = (AffineTransform)(origXform.clone());
		newXform.scale(scale, scale);
		newXform.translate(x, y);
		newXform.concatenate(spt.trans);
		g2d.setTransform(newXform);
		g2d.drawImage(image[mod.idImage], 0, 0, mod.w, mod.h, mod.x, mod.y, mod.x + mod.w, mod.y + mod.h, null);

		if(isSelected)
		{
			g.setXORMode(new Color(0xffffff));
			g.fillRect(0, 0, mod.w, mod.h);
			g.setPaintMode();
		}
		g2d.setTransform(origXform);
	}

	private void drawFrame(Graphics g, int id, int x, int y, int scale, boolean isSelected)
	{
		AniFrame frame = (AniFrame)actor.getFrame(id);
		int n = frame.sprites.size();
		for(int i = 0 ; i < n; i++)
		{
			drawSprite(g, frame, i, x, y, 1, false);
		}
	}

	public void adjustmentValueChanged(java.awt.event.AdjustmentEvent adjustmentEvent)
	{
		if(saveAll())
		{
			idAction = bar.getValue();
			action = (Action)actor.actions.elementAt(idAction);
			AniStudioFrm.instance.actionList.select(idAction);
			refreshAll();
		}
		else
		{
			bar.setValue(idAction);
		}
	}

	public void run()
	{
		long t = System.currentTimeMillis();
		int d = AnimationEditor.getFrameTime();
		while(!toquit)
		{
			actionView.tickFrame();
			try {
				if(System.currentTimeMillis() - t < d - 5)
//				while(System.currentTimeMillis() < t + d)
					Thread.sleep(d - (System.currentTimeMillis() - t));
			}catch(Exception e){}
			t = System.currentTimeMillis();
		}
	}

	class ActionCanvas extends Canvas
	{
		final static int REF_X = 128;
		final static int REF_Y = 128;
		final static int MAX_W = 256;
		final static int MAX_H = 256;
		int curFrame, curId;
		int curDelay, totalDelay;
		Image bimg;

		public ActionCanvas()
		{
			curFrame = -1;
			setSize(MAX_W, MAX_H);
			bimg = AniStudioFrm.instance.createImage(MAX_W, MAX_H);
		}

		public void nextFrame()
		{
			curDelay = 0;
			totalDelay = 0;
			if(action.frmIdTable.size() == 0)
				curFrame = -1;
			else
			{
				curFrame++;
				if(curFrame >= action.frmIdTable.size())
					curFrame = 0;
				curId = ((Integer)(action.frmIdTable.elementAt(curFrame))).intValue();
				AniFrame frm = (AniFrame)(actor.getFrame(curId));
				totalDelay = ((Integer)(action.frmDelay.elementAt(curFrame))).intValue();
			}
		}

		public void tickFrame()
		{
			if(action.frmIdTable.size() == 0)
				return;
			if(curDelay >= totalDelay)
				nextFrame();
			curDelay++;
			repaint();
		}

		public void update(Graphics g)
		{
			paint(g);
		}

		public void paint(Graphics g)
		{
			int i;

			Graphics bg = bimg.getGraphics();
			bg.setColor(AnimationEditor.getBGColor());
			bg.fillRect(0, 0, MAX_W, MAX_H);
			if(curFrame >= 0 && curFrame < action.frmIdTable.size())
			{
				drawFrame(bg, curId, REF_X, REF_Y, 1, false);
			}
			g.drawImage(bimg, 0, 0, null);
		}
	}

	class FrameCanvas extends Canvas
	{
		final static int REF_X = 128;
		final static int REF_Y = 128;
		final static int MAX_W = 256;
		final static int MAX_H = 256;
		int curFrame;

		public FrameCanvas()
		{
			curFrame = -1;
			setSize(MAX_W, MAX_H);
		}

		public void setCurFrame(int id)
		{
			curFrame = id;
			repaint();
		}

		public void paint(Graphics g)
		{
			int i, n;

			g.setColor(AnimationEditor.getBGColor());
			g.fillRect(0, 0, MAX_W, MAX_H);
			if(curFrame >= 0)
			{
				drawFrame(g, curFrame, REF_X, REF_Y, 1, false);
			}
		}
	}

	public void textValueChanged(TextEvent e) {
		if(e.getSource() == fldDelay)
		{
			if(actionList.getSelectedIndex() >= 0)
			{
				action.frmDelay.set(actionList.getSelectedIndex(), new Integer(fldDelay.getText()));
			}
		}
	}
}
