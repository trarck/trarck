#ifndef FNN_FEEDFORWARDNETWORK_H
#define FNN_FEEDFORWARDNETWORK_H

#include "freeNN/neuron.h"

#ifdef __cplusplus
extern "C" {
#endif

static const char *FEEDFORWARDNETWORK_STR_START = "_feedforwardnetwork_start_";
static const char *FEEDFORWARDNETWORK_STR_END = "_feedforwardnetwork_end_";

static const char *FEEDFORWARDNETWORKSETTINGS_STR_START = "_feedforwardnetworksettings_start_";
static const char *FEEDFORWARDNETWORKSETTINGS_STR_END = "_feedforwardnetworksettings_end_";

typedef struct FeedForwardNetworkSettings {
	int withBias_;
	double trainingRate_;
	double outputLayerTrainingRate_;
	NeuronActivationFunction hiddenLayerType_;
	NeuronActivationFunction outputLayerType_;
} FeedForwardNetworkSettings;

typedef struct FeedForwardNetwork {
	unsigned numInputs_;
	unsigned numOutputs_;
	unsigned numHiddenLevels_;
	unsigned *numNeuronsInHiddenLevels_;
	Neuron ***neurons_;
	FeedForwardNetworkSettings *settings_;
	int selfAllocatedSettings_;
} FeedForwardNetwork;



/**
* 
*/
FeedForwardNetwork *FeedForwardNetwork_new(unsigned numInputs, unsigned numOutputs, unsigned numHiddenLevels, 
							const unsigned *numNeuronsInHiddenLevels, FeedForwardNetworkSettings *settings);


/**
* 
*/
FeedForwardNetwork *FeedForwardNetwork_new_from_string(const char *networkStr);


FeedForwardNetwork *FeedForwardNetwork_new_from_file(const char *filePath);

/**
* 
*/
void FeedForwardNetwork_destroy(FeedForwardNetwork *network);

/**
* 
*/
void FeedForwardNetwork_train(FeedForwardNetwork *network, const double *inputs, const double *expectedOutputs);


/**
* 
*/
int FeedForwardNetwork_train_fast(FeedForwardNetwork *network, const double *inputs, const double *expectedOutputs, int (*binaryChecker)(const double*, const double*));

/**
* 
*/
int _FeedForwardNetwork_train(FeedForwardNetwork *network, const double *inputs, const double *expectedOutputs, int fastMode, int (*binaryChecker)(const double*, const double*));

/**
* 
*/
double *FeedForwardNetwork_activate(const FeedForwardNetwork *network, const double *inputs);


char *FeedForwardNetwork_toString(const FeedForwardNetwork *network);

int FeedForwardNetwork_saveToFile(const FeedForwardNetwork *network, const char *pathToFile);

/**
* 
*/
double *_FeedForwardNetwork_activateWithTrace(const FeedForwardNetwork *network, const double *inputs, double ***traceData);

/**
* 
*/
void _FeedForwardNetwork_freeInputsOrErrorsTrace(const FeedForwardNetwork *network, double **inputsOrErrors);

/**
*
*/
FeedForwardNetworkSettings *FeedForwardNetworkSettings_new_default();

FeedForwardNetworkSettings *FeedForwardNetworkSettings_new_from_string(const char *settingsStr);

char *FeedForwardNetworkSettings_toString(const FeedForwardNetworkSettings *settings);

#ifdef __cplusplus
}
#endif

#endif
