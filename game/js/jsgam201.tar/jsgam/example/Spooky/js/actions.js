/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreeziidaemon@yahoo.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.blogspot.com
 * 
*/

//This file contains the actions that the player can do. It contains functions needed by the action functions too.

//Set the text of the action to do
function SetAction(actiontoset)
{
	if(!Player.lockSprite)
	{
		document.getElementById('spanaction').firstChild.data=actiontoset;
        ActiontoDo=actiontoset;
	}
}

//Set the object in the inventory selected
function SetObject(objecttoset,objectnum)
{
	if(!Player.lockSprite)
	{
		if(document.getElementById('spanobject').firstChild.data==objecttoset)
		{
			document.getElementById('spanobject').firstChild.data=TextMenuInventory;
			actualinv=null;
		}else{
			document.getElementById('spanobject').firstChild.data=objecttoset;
			actualinv=objectnum;
		}
	}
}

//When you click on anywhere this actions is called
function Action()
{
    if(Player!=undefined)
    {
      if(!Player.lockSprite)
      {
          //if(Player.getx()!=this.getx() || Player.gety()!=this.gety())
          if(Player.getx()!=this.getx() || Player.gety()!=this.gety())
          {
              this.objecty=this.gety();
              this.objectx=this.getx();
              this.width=parseInt(this.style.width);

              if(this.objectx<=Player.limitX){this.objectx=Player.limitX+Player.step;} 
              if(this.objectx>=Player.limitX2){this.objectx=Player.limitX2-Player.step;}
		
              //If goto left, player stops at right side else stops at left side.
			  if(!(this.getleft()<Player.getx() && this.getright()>Player.getx()))			  
			  {		
				this.objectx-Player.getx()<0?this.objectx+=this.width:this.objectx-=this.width;
			  }
		
              //If the object is on the wall for example the player move to the limit
              if(this.gety()<=Player.limitY){this.objecty=Player.limitY + Player.step }
              Player.actionWith=this;
              Player.move(this.objectx,this.objecty);
	
          }
      }
    }
	
}

//Moves a sprite (usually the Player)
function Move(x,y)
{
//Check if the coordinate to go is in the sprite limits
	if(y>this.limitY && x>this.limitX && x<this.limitX2 && this.lockSprite==false)
	{
		this.lockSprite=true;
		//Get the distance between the sprite and the coordinate to go
		this.toX=x-this.getx();
		this.toY=y-this.gety();

		this.status=GoLeftStatus;
		this.ismovingH=true;
		this.ismovingV=true;
		
		if(this.toX<0)
		{
			this.dirx=-1;
			this.toX=this.toX*this.dirx; //It must be always positive so if it's negative we convert it
			
		}else{
			this.status=GoRightStauts;
			this.dirx=1;
		}
		
		if(this.toY<0)
		{
			this.diry=-1;
			this.toY=this.toY*this.diry;
		}else{
			this.diry=1;
		}
        
		if(Player==this)
        {
          document.getElementById('spanaction').firstChild.data=TextMenuMoving;
        }
		this.gotoxy();
	}

}

//Needed by Conversation, Look and any other function that the sprite speak
function Say(txt)
{
  saytxt=CreateText(txtwidth,txtheight,parseInt(this.style.left),parseInt(this.style.top)-40,"SayTxt");
  saytxt.ChangeText(txt);
  var tmpthis=this;
  setTimeout(function(){saytxt.RemoveText();if(Player==tmpthis){Player.lockSprite=false;}},delay);
}

//Look function
function Look()
{
	Player.Say(this.description);
}

//Generic function when you can do an action
function Cantdo()
{
	this.text;
	switch(ActiontoDo)
	{			
				case "Take":
					this.text=TextCantTake;
				break;
				
				case "Use":
					this.text=TextCantUse;
				break;
			
				case "Speak":
					this.text=TextCantSpeak;
				break;				
	}
	Player.Say(this.text);
}

//Take function
function Take()
{
	var i=SearchEmpty(invnum);
	invnum[i]=new Inventory(i);
	invnum[i].image.src=this.image.src;
	document.getElementById("MainMenu1-1").appendChild(invnum[i].image);
	invnum[i].name=this.name;
	invnum[i].fromDiv=this.divname;
	invnum[i].image.id=this.name;
	DestroyObject(this);
	Player.lockSprite=false;
	invnum[i].image.addEventListener("click",function(){SetObject(invnum[i].name,i);},false);
	invnum[i].image.addEventListener("mouseover",function(){document.getElementById(invnum[i].name).style.width=acticonsize + "px";document.getElementById(invnum[i].name).style.height =acticonsize + "px";},false);
	invnum[i].image.addEventListener("mouseout",function(){document.getElementById(invnum[i].name).style.width=iconsize + "px";document.getElementById(invnum[i].name).style.height =iconsize + "px";},false);
	
}

//Used for inventary between screens
function Taken(divname,name)
{
		var num=SearchEmpty(invnum);
		invnum[num]=new Inventory(num);
		invnum[num].image.src=SpriteFolder+name+"/"+Frame+ImgExt;
		document.getElementById("MainMenu1-1").appendChild(invnum[num].image);
		invnum[num].name=name;
		invnum[num].fromDiv=divname;
		invnum[num].image.id=name;
		invnum[num].image.addEventListener("click",function(){SetObject(invnum[num].name,num);},false);
		invnum[num].image.addEventListener("mouseover",function(){document.getElementById(invnum[num].name).style.width=acticonsize + "px";document.getElementById(invnum[num].name).style.height =acticonsize + "px";},false);
		invnum[num].image.addEventListener("mouseout",function(){document.getElementById(invnum[num].name).style.width=iconsize + "px";document.getElementById(invnum[num].name).style.height =iconsize + "px";},false);	
}

//Called when the player speaks with another character
function Speak()
{
	if(this.conversationPart<this.conversationText.length)
	{
		var whospeak;
        var tmpthis=this;
        
        //If it's a even number the player speaks else the 'object' speaks
        if(this.conversationPart%2==0)
        {
            whospeak=Player;           
        }else{
            whospeak=this;
        }
        
        saytxt=CreateText(txtwidth,txtheight,parseInt(whospeak.style.left),parseInt(whospeak.style.top)-40,"SayTxt");
        saytxt.ChangeText(this.conversationText[this.conversationPart]);
        this.conversationPart++;
        
        setTimeout(function(){document.body.removeChild(document.getElementById(saytxt.div));tmpthis.speak();},delay);
	}else{
		Player.lockSprite=false;
        this.conversationPart=0;
	}
}


function UsableWith(invObject,useFunction)
{
    this.usableObject=invObject;
    this.objectAction=useFunction;
    this.use=Use;
}

function Use()
{
    if(actualinv!=null && invnum[actualinv].name==this.usableObject){
        this.objectAction();
        Player.lockSprite=false;
    }else{
        Player.Say(TextCantUse);
    }

}
//Delete the inventory object, remove the image
function RemoveInventoryObject()
{
	if(actualinv!=null)
	{
		document.getElementById("MainMenu1-1").removeChild(document.getElementById(invnum[actualinv].name));
		ObjectsUsed[SearchEmpty(ObjectsUsed)]=invnum[actualinv].fromDiv;
		delete invnum[actualinv];				
		actualinv=null;
        document.getElementById('spanobject').firstChild.data=TextMenuInventory;
		Player.lockSprite=false;
	}
}

