#ifndef SNPRINTF_H
#define SNPRINTF_H
#ifdef _MSC_VER
#include <stdio.h>
#define snprintf _snprintf
#endif
#endif
