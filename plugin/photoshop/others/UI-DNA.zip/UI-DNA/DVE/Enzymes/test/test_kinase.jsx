﻿/**
 * Created by bgllj on 2016/7/10.
 */
$.evalFile(File($.fileName).path + "/test.jsx")


var i = 3

//
var　ob = ki.layer.get_XXX_Objcet( Kinase.REF_ActiveLayer, null,"text");
// var　ob = ki.layer.getLayerSmartInfo( Kinase.REF_ItemIndex, 2);

// ki.layer.newSmartFromCopy_ByActive()

log(json(ob))
// ki.layer.setLayerEditInfo( {visible:false},Kinase.REF_ActiveLayer, null);


