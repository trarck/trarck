/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.utils;

public class Utils {
    static public int getKeyMask(int keyCode){
		switch (keyCode){
			case Canvas_KEY.NUM1:		return Key.NUM1;
			case Canvas_KEY.NUM2:		return Key.NUM2;
			case Canvas_KEY.NUM3:		return Key.NUM3;
			case Canvas_KEY.NUM4:		return Key.NUM4;
			case Canvas_KEY.NUM5:		return Key.NUM5;
			case Canvas_KEY.NUM6:		return Key.NUM6;
			case Canvas_KEY.NUM7:		return Key.NUM7;
			case Canvas_KEY.NUM8:		return Key.NUM8;
			case Canvas_KEY.NUM9:		return Key.NUM9;

			case Canvas_KEY.STAR:		return Key.STAR;
			case Canvas_KEY.NUM0:		return Key.NUM0;
			case Canvas_KEY.POUND:		return Key.POUND;

			case Canvas_KEY.UP:			return Key.UP;
			case Canvas_KEY.DOWN:		return Key.DOWN;
			case Canvas_KEY.LEFT:		return Key.LEFT;
			case Canvas_KEY.RIGHT:		return Key.RIGHT;
			case Canvas_KEY.SELECT:		return Key.SELECT;

			case Canvas_KEY.SOFT_L:		return Key.SOFT_L;
			case Canvas_KEY.SOFT_R:		return Key.SOFT_R;

			case Canvas_KEY.SEND:		return Key.SEND;
			case Canvas_KEY.END:		return Key.END;

			default:					return 0;
		}
	}
}