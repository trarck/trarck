/*
 * 
 * JSGAM (JavaScript Graphic Adventure Engine)
 * Version: 2.0
 * License: BSD
 * 
 * Author: Ra�l Va�es Sanz
 * E-mails: kreeziidaemon@yahoo.es
 *          kreezii@users.sourceforge.net 
 * Webpages:http://jsgam.sourceforge.net
 * 		    http://kreezii.blogspot.com
 * 
*/

//This file contains the functions to create the screen, the sprites (Player, Objects and Static Objects), the menu and the texts.

//Create a new sprite for the game
function CreateSprite(name,width,height,x,y,visible)
{
	ThisSprite=new Sprite(name,x,y,width,height,spritedepth,spriteframes,TextDefaultDescription);
	 
	if(!SearchObject(ThisSprite.divname,AddtoInventory) && !SearchObject(ThisSprite.divname,ObjectsUsed))
	{
		//Add the DIV and the image to the HTML
		var SpriteDiv=document.createElement('DIV');
		SpriteDiv.id=ThisSprite.divname;
		
		if(visible) //If not visible the sprite doesn't have images, only the DIV
		{	
			var SpriteImg=document.createElement('IMG');
			SpriteImg.id=ThisSprite.imgname;
			SpriteImg.src=SpriteFolder+ThisSprite.name+"/"+Frame+ImgExt;
			SpriteImg.onerror=function(){alert("Error!"+SpriteFolder+ThisSprite.name+"/"+Frame+ImgExt+" doesn't exist.")};
			SpriteDiv.appendChild(SpriteImg);		
		}
		
		SpriteDiv.style.position="absolute";
		SpriteDiv.style.left=x;
		SpriteDiv.style.top=y;
		SpriteDiv.style.width=width;
		SpriteDiv.style.height=height;
		SpriteDiv.style.zIndex=spritedepth;
		document.body.appendChild(SpriteDiv);
		spritedepth+=1;
		
		ThisSprite.style=document.getElementById(ThisSprite.divname).style;//Use to move the sprites and other things
	    ThisSprite.image=document.images[ThisSprite.imgname];//Use it to change the image
	    
    }
    
    return ThisSprite;
}

//Create the player
function CreatePlayer(width,height,x,y)
{
  Player=CreateSprite("Player",width,height,x,y,true);
  Player.Animate();
}

//Create Objects
function CreateObject(name,width,height,x,y)
{
	if(name=="Player" || name=="Door")
	{
		alert("Error! name can't be < "+name+" >");
	}
	this.object=CreateSprite(name,width,height,x,y,true);
	
	var withobject=this.object;
	if(document.getElementById(this.object.divname)!=undefined)
		document.getElementById(this.object.divname).addEventListener("click",function(){withobject.action();},false);

	//Used for check the depth when the player walks
	objectsArray[objectArrayNumber]=this.object;
	objectArrayNumber+=1;

  	return this.object;
}

function CreateInvisibleObject(width,height,x,y)
{
	this.object=CreateSprite("Invisible",width,height,x,y,false);
	
	var withobject=this.object;
	if(document.getElementById(this.object.divname)!=undefined)
		document.getElementById(this.object.divname).addEventListener("click",function(){withobject.action();},false);
			
	return this.object;
}

function CreateStartButton(name,width,height,x,y,goScreen)
{
  StartButton=CreateObject(name,width,height,x,y);
  StartButton.action=function(){GotoScreen(goScreen);};
}

//Create Tables (auxiliar function not to be called by the game developer)
function CreateTable(tableId,rows,columns)
{
    var newTable=document.createElement('TABLE');

    newTable.border=0;
    
    for(var i=0;i<rows;i++){
        newRow=newTable.insertRow(-1);
        newRow.id=tableId+i;
        for(var j=0;j<columns;j++)
        {
            newColumn=newRow.insertCell(-1);
            newColumn.id=tableId+i+"-"+j;           
        }
    }
    return newTable;    
}

//Create a new screen for the game
function CreateScreen(image,width,height)
{
	var ScreenDiv=document.createElement('DIV');
	var ScreenImg=document.createElement('IMG');

	ScreenImg.id=image+"Img";
	ScreenImg.src=ScreenFolder+image+ImgExt;
    
	ScreenDiv.id="Div"+image;
	//The next two variables are used by another external functions
	// for example to preload and for move the sprites to somewhere
	DivScreen=ScreenDiv.id;
	ImgScreen=image;
	
	ScreenName=image;
	
	ScreenDiv.appendChild(ScreenImg);
	ScreenDiv.style.position="absolute";
	ScreenDiv.style.left=0;
	ScreenDiv.style.top=0;
	ScreenDiv.style.width=width;
	ScreenDiv.style.height=height;
	ScreenDiv.style.zIndex=0;
	document.body.appendChild(ScreenDiv);
	ScreenImg.addEventListener("click",MovetoMouseXY,false);//Add onmouse click event to move the main character
}

//Create the menu for the game
function CreateMenu()
{
	//Define the actions
	var actionsImgs=GameActions;
	//Creating div menu and the table
	var MenuDiv=document.createElement('DIV');
	var MenuTable=CreateTable("MainMenu",2,2);
	
	MenuTable.style.background = MenuBackground;
	MenuTable.style.textAlign = 'center';
	
	MenuDiv.id="DivMenu";
	MenuDiv.style.width=document.getElementById(DivScreen).style.width;
	MenuDiv.style.height=menuheight;
	MenuDiv.style.left=0;
	MenuDiv.style.top=document.getElementById(DivScreen).style.height;
	MenuDiv.style.position="absolute";
	MenuDiv.style.zIndex=999;
	MenuDiv.appendChild(MenuTable);
	document.body.appendChild(MenuDiv);

	//Adding the actions, characters and objects in inventory
	var ActionSpan=document.createElement('SPAN');
	ActionSpan.id="spanaction";
	ActionSpan.style.background = "black";
	ActionSpan.appendChild(document.createTextNode(TextMenuActions));

	var ObjectSpan=document.createElement('SPAN');
	ObjectSpan.id="spanobject";
	ObjectSpan.style.background = "black";
	ObjectSpan.appendChild(document.createTextNode(TextMenuInventory));
	
    this.MainMenuWidth=parseInt(document.getElementById(DivScreen).style.width)/2 + "px";
	document.getElementById("MainMenu0-0").style.width=this.MainMenuWidth;
    document.getElementById("MainMenu0-1").style.width=this.MainMenuWidth;
	document.getElementById("MainMenu1-0").style.width=this.MainMenuWidth;
    document.getElementById("MainMenu1-1").style.width=this.MainMenuWidth;

	
	document.getElementById("MainMenu0-0").appendChild(ActionSpan);
	document.getElementById("MainMenu0-1").appendChild(ObjectSpan);
	addActions(actionsImgs,document.getElementById("MainMenu1-0"));
	
}

//Create a text in the screen
function CreateText(width,height,x,y,name)
{
    var TxtDiv=document.createElement('DIV');
    var TxtSpan=document.createElement('SPAN');
    var TxtNode=document.createTextNode("Default Text");
	if(name==undefined)
	{
		name="Text"+textcount;
		textcount++;
	}
    
    TxtDiv.id=name+"TxtDiv";
    TxtSpan.id=name+"TxtSpan";
    TxtDiv.style.textAlign="center";
    TxtDiv.style.position="absolute";
    
	if(x>=0)
	{
		TxtDiv.style.left=x;
	}else{
		TxtDiv.style.left=0;
	}
	
    if(y>=0)
    {
    	TxtDiv.style.top=y;
	}else{
		TxtDiv.style.top=0;
	}
	
    TxtDiv.style.width=width;
    TxtDiv.style.height=height;
    TxtSpan.style.background = "black";
    TxtSpan.appendChild(TxtNode);
    TxtDiv.appendChild(TxtSpan);
    TxtDiv.style.zIndex=999;
    document.body.appendChild(TxtDiv);

    this.createdtxt=new GameText(TxtSpan.id,TxtDiv.id,width,height,x,y);
    
    return this.createdtxt;

}
