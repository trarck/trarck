﻿$.evalFile("E:/Work/GitHub/UI-DNA/DVE/Enzymes/test/test.jsx")


var ob =
{"strokeColor":{
    "r":157.000005841255,"g":157.000005841255,"b":157.000005841255,"enabled":true},
    "fillColor":{"r":155,"g":0,"b":0,"enabled":true},
    "lineWidth":12,"dashSet":[4,2],"lineAlignment":"strokeStyleAlignInside",
    "lineCapType":"strokeStyleButtCap","lineJoinType":"strokeStyleMiterJoin"}

ki.layer.setStrokeStyle_byActive(ob)