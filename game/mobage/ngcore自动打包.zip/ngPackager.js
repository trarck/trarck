#!bin/node/node

require.paths.unshift('./nodelib/client');
require.paths.unshift('./nodelib/shared');
require.paths.unshift('./prepare');

var sys = require("sys"),
    stdio = process.binding("stdio"),
    fs = require("fs"),
    path = require("path"),
    http = require("http"),
	exec = require("child_process").exec,
	vm = require("vm"),
	ngUtil = require("ngUtil"),
	dir = ngUtil.directory,
	setIf = ngUtil.setIf,
    gameSync = require("gameSync").gameSync,
    opts = require("opts"),
    repackage = require("repackageTool/tool").repackage,
    sm = require("sm"),
    StateMachine = sm.StateMachine,
    State = sm.State
	releaseStates = require('releaseStates'),
	util = require('util'), 
	url = require('url');

/**
 * ngPackager CLI Tool
 * Takes multiple paramaters and can perform multiple operations to interact with the packaging
 * server.  Allows for the deployment and control of a game among stages.
 */
var ngPackagerVersion = '0.2.1';

var DefaultConfigFile = './bin/configs/default.js';
var Config = {};
var Args = {};
var ActionQueue = [];
var Data = {};
var Global = {};
var AllActions = [];
var OptsByName = {};
var Defaults = 
{
	mkdirMode: 0755
}

console.log('\nRunning ngPackager CLI');

/**
 * Prints out the help message by iterating over the options and displaying it's information
 */
function help()
{
    var string = '';
    string += 'Usage: ./ngPackager.js [actions] [parameters]\n' +
              'Defaults will be loaded from bin/configs/default.js (or specified config) for all actions and parameters\n' +
              'Only one action will be done per call\n' + 
			  '* = paramater is defined in a loaded config or passed in params\n' + 
			  '(opt) = optional parameter\n';
              
    var print = function(index)
    {
        var text = '';
        var opt = options[i];
        
        if(opt.short)
        {
            text += ' -' + opt.short;
            if(opt.long)
                text += ',';
        }
        
        text += '\t';
        
        var longDisplay = '--' + opt.long;
        if(opt.long)
        {   
            text += longDisplay;
        }
        
        
        if(opt.value)
        {
            text += ' <value>';
            longDisplay += ' <value>';
        }
        
        //if(opt.description)
        //{
            var needs = null;
            if(opt.actionSet)
            {
                needs = '(Uses ';
            
                var neededArgs = {};
				var argsRequired = {};
                for(var k=0; k<opt.actionSet.length; k++)
                {
                    var actionClass = opt.actionSet[k];                    
                    // instantiate for help purposes
                    var action = new actionClass(true);
                    
                    // iterate through args
                    for(var j=0; j<action.argList.length; j++)
                    {
                        var arg = action.argList[j];
                        neededArgs[arg] = true;
						argsRequired[arg] = action.argRequiredTable[arg];
                    }
                }
                
                var first = true;
                for(arg in neededArgs)
                {
					if(!OptsByName[arg])
						console.log('Display Help Error: doesn\'t exist - ' + arg);
				
                    if(OptsByName[arg].hidden)
                        continue;
                
                    if(!first)
                        needs += ', ';
                    
					// if already specified in a config
					if(Args[arg])
						needs += '*';
						    
                    needs += arg;
					
					// if optional arg
					if(!argsRequired[arg])
						needs += '(opt)';
                    
                    first = false;
                }
                
                needs += ')';
            }
            
            var tabs = '\t';
            
            var tabIndent = (longDisplay.length / 8);
            var build = function(count)
            {
                for(var i=0; i<count; i++)
                    tabs += '\t';
            }
            build(Math.ceil(3 - tabIndent));
 
            text += tabs;
            if(opt.description)
                text += opt.description + ' ';
            
            if(needs)
                text += needs;
       // }
        
        text += '\n';
        return text;
    }
    
    // action pass
    string += 'actions:\n';
    for(var i=0; i<options.length; i++)
    {
        if(options[i].actionSet)
        {
            string += print(i);
        }
    }
    
    // non-action pass
    string += 'parameters:\n';
    for(var i=0; i<options.length; i++)
    {
        if(!options[i].actionSet && !options[i].hidden)
        {
            string += print(i);
        }
    }
    
    console.log(string);
}



/**
 * Actions
 * Actions can be used to accomplish things within this tool.  A command can specify a list of
 * Actions that it will perform (in that order)
 */

 
function Action()
{
    this.argList = [];
	this.argRequiredTable = {};

    this.getErrorMsg = function(name)
    {
        var msg = name + ' Failed\n';
        this.errorMsg = msg;
        return msg;
    }

    this.checkArg = function(argname, notRequired)
    {
        this.argList.push(argname);
		this.argRequiredTable[argname] = !notRequired;
    
        if(!this.help)
        {
            var arg = Args[argname];
            if(!arg)
            {
				if(!notRequired)
				{
					this.errorMsg += 'No ' + argname + ' specificed';
					FatalError(this.errorMsg);
				} else
					return null;
            } else
            {
                return arg;
            }
        }
    };
    
    AllActions.push(this);
};

/**
 * Prints the ngPackager version
 */
function PrintVersion(help)
{
    (Action).bind(this)();
    this.help = help;

    var name = "Print Version";
    var errorMsg = this.getErrorMsg(name);
    
    this.run = function()
	{
        console.log("ngPackager version: " + ngPackagerVersion);
		Actions.runAction();
    }
}

function ClearTokens(help)
{
	(Action).bind(this)();
    this.help = help;

    var name = "Clear Tokens";
    var errorMsg = this.getErrorMsg(name);
	
    this.run = function()
	{
		tokenBin = './bin/tokens';
        console.log('Clearing tokens from tokenBin = ' + tokenBin);
		exec('rm ' + tokenBin + '/*', function(error, stdout, stderr)
		{
			if(!error)
				console.log('Tokens cleared');
			else
				console.log('Error clearing tokens: ' + error);
			
			Actions.runAction();
		});
	}
}

/**
 * Sets the Server Url that will be used for all calls to the packaging server
 */
function SetServerUrl(help)
{
    (Action).bind(this)();
    this.help = help;
       
    var name = "Set Server Url";
    var errorMsg = this.getErrorMsg(name);
    
    var serverUrl = this.checkArg('serverUrl');
    var serverPort = this.checkArg('serverPort');
	var nonVerbose = this.checkArg('nonVerbose', true);
    
    this.run = function()
    {
		if(Args['standaloneBuild'])
		{
			if(!Args['downloadBundle'] && (Args['gameServerUrl'] && Args['gameServerPath']))
			{
				Actions.runAction();
				return;
			}
		}
	
        var initCall = function(state)
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            if(!nonVerbose)
				console.log('Requesting Server Url (' + serverUrl + ':' + serverPort + ')');
			
			gameSync.setServerUrl(serverUrl, serverPort, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 1000);
                    finish();
                }

            }).bind(this));
        };
        
        var successCall = function(data)
        {
            if(!nonVerbose)
				console.log('Server Url Received: ' + data);
            
			Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall, 1 * 60);
    }
}

/**
 * Authenticate, this is basic user authentication via a userID and a password, the password can 
 * either be defined in a config file, command line, or be prompted for it during runtime
 */
function Authenticate(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Authentication";
    var errorMsg = this.getErrorMsg(name);

    var userId = this.checkArg('userId');
    var pass = this.checkArg('pass', true);
	var nonVerbose = this.checkArg('nonVerbose', true);
	var authHost = this.checkArg('authHost');
    
    var Authentication = require('authenticate').Authentication;
    var auth = null;
	
    // prompts for a password and then calls the callback
    function passPrompt(callback)
    {
        var error = { msg: 'passPrompt failed:\n', b: false };
        var st = process.openStdin(); 

        stdio.setRawMode();
        var line = "";
        st.on('data', function(ch) 
        {
            ch = "" + ch;
            switch (ch) 
            {
                case "\n": case "\r": case "\r\n": case "\u0004":
                    stdio.setRawMode(false);
                    st.removeAllListeners('data');
                    st.destroy();
                    console.log('');
                    callback(error, line);
                    break;
                case "\u0003": case "\0":
                
                    stdio.setRawMode(false);
                    
					setTimeout(function()
					{
						process.exit();
                    }, 0);
					
					break;
                default:
                    //console.log('ch = ' + ch);
                    line += ch;
                    break;
            }
        });

        sys.print("enter password:"); 
    }
    
    this.run = function()
    {
        if(Args['standaloneBuild'])
		{
			if(!Args['downloadBundle'] && (Args['gameServerUrl'] && Args['gameServerPath']))
			{
				Actions.runAction();
				return;
			}
		}
		
		var initCall = function(state)
        {
			console.log('Authenticating');
            Authentication.getAuth(userId, authHost, function(err, data)
            {
                if(!data)
                {
                    // ask for pass if needed and request auth
                    if(!pass)
                    {
                        passPrompt(function(err, password)
                        {
                            if(err.b)
                            {
                                state.sm.errorMsg += ('Login Prompt failed\n' + error.msg);
                                state.sm.delayTrigger(state.sm.state('Fail'));
                            } else
                            {
                                if(password)
                                {
                                    state.sm.pass = password;
                                    state.done();
                                } else
                                {
                                    state.sm.errorMsg += 'Invalid password entered\n';
                                    state.sm.delayTrigger(state.sm.state('Fail'));
                                }
                            }
                        });
                        return false
                    } else
                    {
                        state.sm.pass = pass;
                        state.done();
                    }
                } else
                {
                    auth = data;
                    state.done();
                }
            });
        
            return false;
        };
        
        var queryCall = function(state)
        {
            
            var getAuth = function(callback)
            {
                if(!nonVerbose)
					console.log('Validating credentials');
				
				Authentication.getAuthWithPass(userId, state.sm.pass, authHost, (function(err, data)
                {
                    if(err.b)
                    {
                        state.sm.errorMsg += err.msg;
                        state.querySuccess = false;
                        state.queryFinish = true;
                        
                    } else
                    {
                    }

                    callback(err, data);
                }).bind(this));

            };
            
            var authenticate = function(callback)
            {
				gameSync.authenticate(auth, function(err)
                {	
                    if(err.b)
                    {
                        state.sm.errorMsg += err.msg;
                        state.querySuccess = false;
                        state.queryFinish = true;
                    } else
                    {
                    }

                    callback(err);
                });

            }
            
            if(!auth)
            {
                getAuth(function(err, data)
                {   
                    if(!err.b)
                    {
                        auth = data;
                    
                        authenticate(function(err)
                        {
                            if(!err.b)
                            {
                                var finish = function()
                                {
                                    state.querySuccess = true;
                                    state.queryFinish = true;
                                
                                    state.sm.Data = null;
                                };
                                
                                //setTimeout(finish.bind(this), 2000);
                                finish();

                            }
                        });
                    }
                });
                            
            } else
            {
                authenticate(function(err)
                {
                    if(!err.b)
                    {
                        var finish = function()
                        {
                            state.querySuccess = true;
                            state.queryFinish = true;
                        
                            state.sm.Data = null;
                        };
                        
                        //setTimeout(finish.bind(this), 2000);
                        finish();

                    }
                });

            }
        };
        
        var successCall = function(data)
        {
            if(!nonVerbose)
				console.log("\nAuthenticated");
            
			Global['Authenticated'] = true;
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Uploads the build to the server
 */
function SyncGamePath(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Upload Game Path";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
    var stageId = this.checkArg('stageId');
    
    this.run = function()
    {
        var bakedGamePath = Global['bakedGamePath'];
        var noBake = Args['noBake'];
        if(noBake)
        {
            var bakedGamePath = this.checkArg('gamePath');
        }
        
        if(!bakedGamePath)
        {
            errorMsg += 'no bakedGamePath\n';
            FatalError(errorMsg);
        }
        
        var initCall = function(state)
        {
            console.log('\nValidating baked game path=' + bakedGamePath);
            path.exists(bakedGamePath, function(exists)
            {
                if(exists)
                {
                    fs.lstat(bakedGamePath, function(err, stat)
                    {
                        if(stat.isDirectory() || stat.isSymbolicLink() || stat.isFile())
                        {
                            state.done();
                        } else
                        {
                            state.sm.errorMsg += "Not a directory\n";
                            state.sm.delayTrigger(state.sm.state('Fail'));
                        }
                    });
                } else
                {
                    errorMsg += "Path doesn't exist\n";
                    state.sm.delayTrigger(state.sm.state('Fail'));
                }
            });
        
            return false;
        };
        
        var queryCall = function(state)
        {
            console.log('Syncing game data');
            gameSync.uploadGameBundle(appId, stageId, bakedGamePath, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    setTimeout(finish.bind(this), 3000);
                }
            }).bind(this));    };
        
        var successCall = function(data)
        {
            /*var serverGamePath = data.serverGamePath;
            
            if(!serverGamePath)
            {
                errorMsg += state.sm.errorMsg;
                errorMsg += 'invalid serverGamePath\n';
                FatalError(errorMsg);
            } else
            {*/
                console.log("\nGame synced");
                //Global['serverGamePath'] = serverGamePath;
                Actions.runAction();
            //}
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall, 60 * 60);
    }
}

/**
 * Prints a list of all the apps for the userId
 */
function PrintAppList(help)
{
    (Action).bind(this)();
    this.help = help;

    var name = "App List";
    var errorMsg = this.getErrorMsg(name);
    
    this.run = function()
	{
        var initCall = function()
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Apps');
            gameSync.getApps((function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            }).bind(this));
        };
        
        var successCall = function(data)
        {
            var list = data;
            console.log("\nListing Apps:");
            for(var i=0; i<list.length; i++)
            {
                var entry = list[i];
                console.log("\t* " + entry);
            }
            console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Prints a list of all the stages for the userId and appId
 */
function PrintStageList(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Stage List";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
    
    this.run = function()
    {
        var initCall = function()
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Stages');
            gameSync.getAppStages(appId, (function(err, list)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = list;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            }).bind(this));
        };
        
        var successCall = function(data)
        {
            console.log("\nListing Stages for appId=" + appId + ":");
            
			var sandboxPermissions = '';
			var productionPermissions = '';
			
			var displayed = false;
			if(data.sandbox)
			{
				sandboxPermissions = 'view: ' + data.sandbox.view + ', deploy: ' + data.sandbox.deploy;
				if(data.sandbox.view && data.sandbox.stages)
				{
					displayed = true;
					console.log('\tSandbox Stages, permissions (' + sandboxPermissions + ')');
					for(var i=0; i<data.sandbox.stages.length; i++)
					{
						console.log('\t* ' + data.sandbox.stages[i]);
					}
					if(data.sandbox.stages.length === 0)
						console.log('\t* no stages');
					
					console.log('');
				}
			}
			
			if(data.production)
			{
				productionPermissions = 'view: ' + data.production.view + ', deploy: ' + data.production.deploy;
				if(data.production.view)
				{
					displayed = true;
					console.log('\tYou have Production permissions (' + productionPermissions + ')');
				}
			}
			
			if(!displayed)
			{
				console.log('\tThere are no stages or you have no access, you have the following permissions:');
				console.log('\t\t' + sandboxPermissions);
				console.log('\t\t' + productionPermissions);
			}
			
            console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Prints a list of all the releases for the userId, appId, and stageId
 */
function PrintReleaseList(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Release List";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
    
    this.run = function()
    {
        var initCall = function()
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Releases');
            gameSync.getAppReleases(appId, (function(err, list)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = list;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            }).bind(this));

        };
        
        var successCall = function(data)
        {
            var list = data;
            
            console.log("\nListing Releases for appId=" + appId + ":");
            for(var i=0; i<list.length; i++)
            {
                var entry = list[i];
                console.log("\t* " + entry);
            }
            console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Prints the published release
 */
function PrintPublishedRelease(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Print Published Release";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
	var environment = this.checkArg('environment');
    var stageId = this.checkArg('stageId', true);
    
    this.run = function()
    {
        var initCall = function(state)
        {
			if(environment === 'sandbox')
			{
				if(!stageId)
				{
					state.sm.errorMsg += 'sandbox environment specified and no stageId\n';
					state.sm.delayTrigger(state.sm.state('Fail'));
					return false
				}
			}
	
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Published Release');
            gameSync.getPublishedRelease({'appId':appId, 'stageId':stageId, 'environment':environment}, (function(err, data)
            {
				//console.log(' response ', err,' ' + data);
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            }).bind(this));

        };
        
        var successCall = function(data)
        {
            console.log('\nPublished Release for appId=' + appId + ' environment=' + environment + ' stageId=' + stageId + ':');
			//console.log(data);
			if(!data.length)
			{
				console.log('\t* ' + data);
			} else
			{
				for(var i=0; i<data.length; i++)
				{
					console.log('\t* ' + data[i].url + '\t' + data[i].releaseId);
				}
			}
			
			console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Prints a list of all the apps for the userId
 */
function PrintReleaseState(help)
{
    (Action).bind(this)();
    this.help = help;

    var name = "Release State";
    var errorMsg = this.getErrorMsg(name);
    
	var appId = this.checkArg('appId');
	var releaseId = this.checkArg('releaseId');
	
    this.run = function()
	{
        var initCall = function()
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Release State');
            gameSync.getReleaseInfo(appId, releaseId, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            }).bind(this));
        };
        
        var successCall = function(data)
        {
			var message = '\t';
			message += releaseStates.getDisplay(data.status_code);
			message += '\t' + data.status_progress;
		
            console.log("\nRelease State:");
			console.log(message);
			console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Prints info about the release
 */
function PrintReleaseInfo(help)
{
    (Action).bind(this)();
    this.help = help;

    var name = "Release Info";
    var errorMsg = this.getErrorMsg(name);
    
	var appId = this.checkArg('appId');
	var releaseId = this.checkArg('releaseId');
	
    this.run = function()
	{
        var initCall = function()
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Release Info');
            gameSync.getReleaseInfo(appId, releaseId, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            }).bind(this));
        };
        
        var successCall = function(data)
        {
			//var message = '\t';
			//message += releaseStates.getDisplay(data.status_code);
			//message += '\t' + data.status_progress;
		
			if(data.status_code)
				data.status = releaseStates.getDisplay(data.status_code);
		
            console.log("\nRelease Info:");
			console.log(data);
			console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
	};
}

/**
 * Prints the published url
 */
function PrintPublishedUrl(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Print Published Url";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
	var environment = this.checkArg('environment');
    var stageId = this.checkArg('stageId', true);
    
    this.run = function()
    {
        var initCall = function(state)
        {
			if(environment === 'sandbox')
			{
				if(!stageId)
				{
					state.sm.errorMsg += 'sandbox environment specified and no stageId\n';
					state.sm.delayTrigger(state.sm.state('Fail'));
					return false
				}
			}
	
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Published Url');
            gameSync.getPublishedUrl({'appId':appId, 'stageId':stageId, 'environment':environment}, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
					state.querySuccess = true;
					state.queryFinish = true;
				
					state.sm.Data = data;
                }
            }).bind(this));

        };
        
        var successCall = function(data)
        {
            console.log('\nPublished Url(s) for appId=' + appId + ' environment=' + environment + ' stageId=' + stageId + ':');
           
			console.log('\t* ' + data.full);
			
			console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Prints the published release
 */
function PrintDeployedUrl(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Print Deployed Url";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
    var releaseId = this.checkArg('releaseId');
    
    this.run = function()
    {
        var initCall = function(state)
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Deployed Url');
            gameSync.getDeployedUrl(appId, releaseId, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
					state.querySuccess = true;
					state.queryFinish = true;
				
					state.sm.Data = data;
                }
            }).bind(this));

        };
        
        var successCall = function(data)
        {
            console.log('\nDeployed Url for appId=' + appId + ' releaseId=' + releaseId + ':');
            console.log('\t* ' + data.full);
            console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Prints the publish attempts
 */
function PrintPublishAttempts(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Print Publish Attempts";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
	var environment = this.checkArg('environment');
	var stageId = this.checkArg('stageId', true);
    var releaseId = this.checkArg('releaseId', true);
    var count = this.checkArg('count', true);
	var newest = this.checkArg('newest', true);
	var oldest = this.checkArg('oldest', true);
	var queryParams = {};
	
    this.run = function()
    {
        var initCall = function(state)
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Getting Publish Attempts');
			
			queryParams = 
			{
				'count': count,
				'newest': newest,
				'oldest': oldest
			};
			
			var options = 
			{
				'appId': appId,
				'environment': environment,
				'stageId': stageId,
				'releaseId': releaseId,
				'queryParams': queryParams
			};
            gameSync.getPublishAttempts(options, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
					state.querySuccess = true;
					state.queryFinish = true;
				
					state.sm.Data = data;
                }
            }).bind(this));

        };
        
        var successCall = function(data)
        {
			var display = '\nPublish Attempts for appId=' + appId + ' environment=' + environment;
			
			if(stageId)
				display += ' stageId=' + stageId;
				
			if(releaseId)
				display += ' releaseId=' + releaseId;
			
			display += ' queryParams=' + util.inspect(queryParams);
			display += ':';
            console.log(display);
            
			var list = data.list;
			for(var i=0; i<list.length; i++)
			{
				var entry = list[i];
				if(entry.status_code)
					entry.status = releaseStates.getDisplay(entry.status_code);
				console.log(util.inspect(entry));
            }
			
			console.log('');
            Actions.runAction();
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}


/**
 * Adds the specified stageId to the userId and appId
 */
function AddStage(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Adding stageId";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
    var stageId = this.checkArg('stageId');

    this.run = function()
    {
        var initCall = function()
        {
            return true;
        };
        
        var queryCall = function(state)
        {
            console.log('Submiting stageId (' + stageId + ')');
            gameSync.addAppStageId(appId, stageId, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            }).bind(this));
        };
        
        var successCall = function(data)
        {
           console.log('\nstageId Added (' + stageId + ')');
           Actions.runAction(); 
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Sets the current release forthe userId, appId, and stageId to the specified releaseId
 */
function PublishRelease(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Publish Release";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
	var environment = this.checkArg('environment');
    var stageId = this.checkArg('stageId', true);
    var releaseId = this.checkArg('releaseId', true);
	var secureUrl = this.checkArg('secureUrl', true);
	var publishManifest = this.checkArg('publishManifest', true);

    this.run = function()
    {
        var initCall = function(state)
        {
			if(environment !== 'sandbox' && environment !== 'production')
			{
				state.sm.errorMsg += "Invalid environment specified, must specify either production or sandbox\n";
				state.sm.delayTrigger(state.sm.state('Fail'));
			} else if(environment === 'sandbox' && !stageId)
			{
				state.sm.errorMsg += "Sandbox environment chosen and no stageId specified\n";
				state.sm.delayTrigger(state.sm.state('Fail'));
			} else if(Global['deployedReleaseId'])
			{
				releaseId = Global['deployedReleaseId']
				return true;
			} else if(!releaseId)
			{
				state.sm.errorMsg += "No releaseId specified\n";
				state.sm.delayTrigger(state.sm.state('Fail'));
			} else
			{
				return true;
			}
        };
        
        var queryCall = function(state)
        {
			var message = 'Publishing releaseId (' + releaseId + ') to environment (' + environment + ')';
			
			if(stageId)
				message += ' and stageId (' + stageId + ')\n';
			
			console.log(message);
            gameSync.publishRelease({'appId': appId, 'environment': environment, 'stageId': stageId, 'releaseId': releaseId, 'secureUrl': secureUrl, 'publishManifest': publishManifest}, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            }).bind(this));
        };
        
        var successCall = function(data)
        {
           console.log('\nRelease publish request submitted (' + releaseId + '), note that it can take up to 7 minutes for an existing destination to update to a new release');
           Actions.runAction(); 
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * 
 */
function WaitForDeployment(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Wait For Deployment";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId');
	var releaseId = null;

    this.run = function()
    {
        var initCall = function(state)
        {
			if(Global['deployedReleaseId'])
			{
				releaseId = Global['deployedReleaseId']
				return true;
			} else 
			{
				state.sm.errorMsg += "No releaseId found\n";
				state.sm.delayTrigger(state.sm.state('Fail'));
				return false;
			}
        };
        
        var queryCall = function(state)
        {
			console.log('Waiting for deployment of releaseId (' + releaseId + ') to finish');
			var stateCode = releaseStates.states.PublishedToCDN.code;
            gameSync.onReleaseState({'appId': appId, 'releaseId': releaseId, 'stateCode': stateCode, 'timeout': 20 * 60 * 1000}, function(err, data)
			{
				if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
					if(data.done)
					{
						state.querySuccess = true;
						state.queryFinish = true;
					
						state.sm.Data = {};
					}
				}
			});
        };
        
        var successCall = function(data)
        {
           console.log('\nDeployment of releaseId (' + releaseId + ') finished');
           Actions.runAction(); 
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall, 20 * 60);
    }
}

/**
 * Bakes out the game from the specified gamePath
 */
function BakeGame(help)
{ 
    (Action).bind(this)();
    this.help = help;
    
    var name = "Bake Game";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId', true);
    var gamePath = this.checkArg('gamePath');
    var toolPath = this.checkArg('toolPath');
    var destBakedPath = this.checkArg('destBakedPath');
    //新增generateArchives,jslint 
    //false用空字符串处理 jake.js会把所有输入当做字符串,if('false')就会为true
    var generateArchives=this.checkArg('generateArchives',true)||'';//新版本已经修正了，为了兼容使用空字符串
    var jslint=this.checkArg('jslint',true)||false;
    var androidResize=this.checkArg('androidResize',true)||true;

	var skipBake = false;
    
    this.run = function()
    {
        var noBake = Args['noBake'];
        
        if(noBake)
        {
            Actions.runAction();
            return;
        }
        
        var initCall = function(state)
        {
            console.log('\nValidating game path=' + gamePath);
            path.exists(gamePath, function(exists)
            {
                if(exists)
                {
					// let's check if it's a file
					if(fs.statSync(gamePath).isFile())
					{
						// skip it, we already have a baked file, ex: .zip (WE ASSUME ALL FILES ARE ALREADY BAKED)
						skipBake = true;
						state.sm.Data = { 'bakedGamePath': gamePath };
						state.sm.delayTrigger(state.sm.state('Success'));
					} else
					{
						fs.lstat(gamePath, function(err, stat)
						{
							if(stat.isDirectory() || stat.isSymbolicLink())
							{
								state.done();
							} else
							{
								state.sm.errorMsg += "Not a directory\n";
								state.sm.delayTrigger(state.sm.state('Fail'));
							}
						});
					}
                } else
                {
                    errorMsg += "Path doesn't exist\n";
                    state.sm.delayTrigger(state.sm.state('Fail'));
                }
            });
        
            return false;
        };
        
        var queryCall = function(state)
        {
            console.log('Baking game data');
			
			var options = 
			{
				'appId': appId, 
				'localGamePath': gamePath, 
				'toolPath': toolPath, 
				'destPath': destBakedPath,
                'generateArchives':generateArchives,
                'jslint':jslint,
                'androidResize':androidResize
			};
            gameSync.bakeGamePath(options, (function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {   
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 3000);
                    finish();
                }
            }).bind(this));    
        };
        
        var successCall = function(data)
        {
            var bakedGamePath = data['bakedGamePath'];
            
            if(!bakedGamePath)
            {
                errorMsg += 'invalid bakedGamePath\n';
                FatalError(errorMsg);
            } else
            {
				if(!skipBake)
					console.log("\nGame baked bakedGamePath = " + bakedGamePath);
                else
					console.log("\nFile passed, skipping bake, bakedGamePath = " + bakedGamePath);
				
				Global['bakedGamePath'] = bakedGamePath;
                Actions.runAction();
            }
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * Deploys the specified releaseId and gamePath (or resulting bake from it) to the specified appId
 */
function DeployRelease(help)
{
    (Action).bind(this)();
    this.help = help;
	
    var name = "Deploy Release";
    var errorMsg = this.getErrorMsg(name);
    
    var appId = this.checkArg('appId'); 

	var timeout = 120 * 60;
    this.run = function()
    {
		var bakedGamePath = Global['bakedGamePath'];
        var noBake = Args['noBake'];
        if(noBake)
        {
            var bakedGamePath = this.checkArg('gamePath');
        }
		
		
        var initCall = function(state)
        {
			console.log('\nValidating baked game path=' + bakedGamePath);
            path.exists(bakedGamePath, function(exists)
            {
                if(exists)
                {
                    fs.lstat(bakedGamePath, function(err, stat)
                    {
                        if(stat.isDirectory() || stat.isSymbolicLink() || stat.isFile())
                        {
                            state.done();
                        } else
                        {
                            state.sm.errorMsg += "Not a directory\n";
                            state.sm.delayTrigger(state.sm.state('Fail'));
                        }
                    });
                } else
                {
                    errorMsg += "Path doesn't exist\n";
                    state.sm.delayTrigger(state.sm.state('Fail'));
                }
            });
		
            return false;
        };
        var queryCall = function(state)
        {
			var displayOverride = false;
			state.sm.runDisplayCallback = function()
			{
				if(!displayOverride)
					sys.print('.');
			};
			
			gameSync.createRelease({'appId': appId}, (function(err, releaseId)
			{
				if(err.b)
				{
					state.sm.errorMsg += err.msg;
					state.querySuccess = false;
					state.queryFinish = true;
				} else
				{
					console.log('\nDeploying release to (appId=' + appId + ' releaseId=' + releaseId + ')\nUploading: ');
					gameSync.deployRelease({'appId': appId, 'releaseId': releaseId, 'localGameBundle': bakedGamePath}, (function(err, data)
					{
						if(err.b)
						{
							state.sm.errorMsg += err.msg;
							state.querySuccess = false;
							state.queryFinish = true;
						} else
						{
							var finish = function()
							{
								state.querySuccess = true;
								state.queryFinish = true;
							
								state.sm.Data = releaseId;
							};
							
							//setTimeout(finish.bind(this), 2000);
							finish();
						}
					}).bind(this));
					/*
					var stateCode = releaseStates.states.Uploading.code;
					gameSync.onReleaseState({'appId': appId, 'releaseId': releaseId, 'stateCode': stateCode}, function(err, data)
					{
						if(err.b)
						{
						} else
						{
							if(data.done)
							{
								var stateCode = releaseStates.states.Uploading.code;
								var complete = false;
								var lastProgress = null;
								var lastLength = null;
								displayOverride = true;
								console.log('');
								gameSync.onReleaseState({'appId': appId, 'releaseId': releaseId, 'stateCode': stateCode, 'interval': 200, 'timeout': timeout * 1000, 'not': true, 'returnProgress': true}, function(err, data)
								{
									//console.log(err, data);
									if(err.b)
									{
									} else
									{
										if(data.done)
										{
											displayOverride = false;
											console.log('');
										} else
										{
											var progress = data.progress;
											
											if(progress && !complete && (!lastProgress || (progress !== lastProgress)))
											{
												if(progress === 'In Progress')
													progress = 0;
											
												lastProgress = progress;
												
												if(lastLength)
													ngUtil.back(lastLength);
												
												var message = 'Uploading = ' + progress + '%';
												sys.print(message);
												lastLength = message.length;
										
												if(progress === 100)
													complete = true;
											}
										}
									}
								});
							} else
							{
								var progress = data.progress;
								console.log('progress = ' + progress);
							}
						}
					});*/
				}
			}).bind(this));
        };
        
        var successCall = function(data)
        {
            var releaseId = data;
            console.log('\nRelease deployment request submitted and game bundle uploaded ' + appId + ' releaseId=' + releaseId);
			console.log('');
			
			Global['deployedReleaseId'] = releaseId;
			
            Actions.runAction(); 
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall, timeout);
    }
}

/**
 * 
 */
function StandaloneBuild(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Standalone Build";
    var errorMsg = this.getErrorMsg(name);

	var appId = this.checkArg('appId');
	var appName = this.checkArg('appName', true);
	var destBuildPath = this.checkArg('destBuildPath');
	var bundleId = this.checkArg('bundleId');
	var stageId = this.checkArg('stageId', true);
	var releaseId = this.checkArg('releaseId', true);
	//var downloadBundle = this.checkArg('downloadBundle', true);
    var iOSBundlePath = this.checkArg('iOSBundlePath', true);
    var iOSIdentity = this.checkArg('iOSIdentity', true);
    var iOSProfile = this.checkArg('iOSProfile', true);
    var gameServerUrl = this.checkArg('gameServerUrl', true);
    var gameServerPath = this.checkArg('gameServerPath', true);
	var androidBundlePath = this.checkArg('androidBundlePath', true);
	var androidKeyStore = this.checkArg('androidKeyStore', true);
	var androidKeyPass = this.checkArg('androidKeyPass', true);
	var androidStorePass = this.checkArg('androidStorePass', true);
	var androidKeyAlias = this.checkArg('androidKeyAlias', true);
	var environment = this.checkArg('environment', true);
	var os = this.checkArg('os');
	//var destDownloadBuild = this.checkArg('destDownloadBuild');

    this.run = function()
    {
		// this means we've downloaded it and want to use the downloaded version
		var downloadedBuild = Global['downloadedBuild'];
		
		/*if(downloadBundle)
		{
			iOSBundlePath = downloadedBuild;
			androidBundlePath = downloadedBuild;
		}*/
		
        var initCall = function(state)
        {
			/*if(downloadBundle && !downloadedBuild)
			{
				state.sm.errorMsg += 'Download specified but nothing downloaded\n';
				state.sm.delayTrigger(state.sm.state('Fail'));
				return false;
			} else*/
			
			switch(os)
			{
				case 'android':
					if(!androidBundlePath)
					{
						state.sm.errorMsg += 'You must specificy an androidBundlePath for android\n';
						state.sm.delayTrigger(state.sm.state('Fail'));
					}
					
					break;
				case 'ios':
					if(!iOSBundlePath)
					{
						state.sm.errorMsg += 'You must specificy an iOSBundlePath for ios\n';
						state.sm.delayTrigger(state.sm.state('Fail'));
					}
					
					break;
				default:
					state.sm.errorMsg += 'os must either be android or ios, not ' + os + '\n';
					state.sm.delayTrigger(state.sm.state('Fail'));
					return false;
			}
						
			return true;
        };
        
        var queryCall = function(state)
        {
			var rebakeGame = function()
			{
				console.log('Repackaging Standalone Build');
				//var srcBundlePath = destDownloadBuild;

				var finish = function()
				{
					destBuildPath += '/' + appId + '_' + os + '_' + (new Date().getTime());
					if(!path.existsSync(destBuildPath))
						fs.mkdirSync(destBuildPath, Defaults.mkdirMode);
				
					var options = 
					{
						'name': appName || appId, 
						'bundleId': bundleId, 
						'server': gameServerUrl, 
						'path': gameServerPath, 
						'dest': destBuildPath,
						'os': os
					};
			
					if(os === 'ios')
					{
						options['iOSBundlePath'] = path.resolve(iOSBundlePath);
						options['iOSIdentity'] = iOSIdentity;
						options['iOSProfile'] = iOSProfile;
					} else if(os === 'android')
					{
						options['androidBundlePath'] = path.resolve(androidBundlePath);
						options['androidKeyStore'] = androidKeyStore;
						options['androidKeyPass'] = androidKeyPass;
						options['androidStorePass'] = androidStorePass;
						options['androidKeyAlias'] = androidKeyAlias;
					}
					
					if(!gameServerUrl || !gameServerPath)
						options['resignOnly'] = true;
					
					//console.log('call', options);
					repackage(options, function(err, data)
					{	
						//console.log('response', err, data);
						if(err.b)
						{
							state.sm.errorMsg += err.msg;
							state.querySuccess = false;
							state.queryFinish = true;
						} else
						{
							state.querySuccess = true;
							state.queryFinish = true;
						
							state.sm.Data = data;
						}
					});
				};
				
				/*if(downloadBundle && os === 'ios' && path.extname(downloadedBuild) === '.zip')
				{
					srcBundlePath = destDownloadBuild + '/unziped';
					if(!path.existsSync(srcBundlePath))
						fs.mkdirSync(srcBundlePath, Defaults.mkdirMode);
					
					srcBundlePath += '/' + (new Date()).getTime();
					
					if(!path.existsSync(srcBundlePath))
						fs.mkdirSync(srcBundlePath, Defaults.mkdirMode);
					
					var call = 'unzip -o ' + downloadedBuild + ' -d ' + srcBundlePath;
					
					exec(call, function(error, stdout, stderror)
					{
						iOSBundlePath = ngUtil.findFileByExt(srcBundlePath, '.app');
						finish();
					});
				} else
				{*/
					finish();
				//}
			};
		
			if(!gameServerUrl || !gameServerPath)
			{
				var fail = function(message)
				{
					state.sm.errorMsg += message;
					state.querySuccess = false;
					state.queryFinish = true;
				};
				
				if(!environment)
				{
					fail('Neither gameServerUrl and gameServerPath were defined and no environment specified to query them\n');
					return;
				} else if(environment === 'sandbox' && !stageId)
				{
					fail('Neither gameServerUrl and gameServerPath were defined and the environment was set to sandbox with no stageId specified to query them\n');
					return;
				}
				
				gameSync.getPublishedUrl({'appId':appId, 'environment':environment, 'stageId':stageId}, function(err, data)
				{	
					if(!err.b)
					{
						var fullUrl = url.parse(data.full);
						gameServerUrl = 'http://' + fullUrl.hostname;
						gameServerPath = fullUrl.pathname;
						
						if(!gameServerUrl || !gameServerPath)
						{
							fail('Could not query the gameServerUrl and gameServerPath, data recieved: ' + data);
							return;
						}
						
						if(gameServerPath && gameServerPath[0] === '/')
							gameServerPath = gameServerPath.substr(1);
						
						//console.log('got game info', gameServerUrl, gameServerPath);
						rebakeGame();
					} else
					{
						console.log('error: ', err);
						state.sm.errorMsg += 'Neither gameServerUrl and gameServerPath were defined and couldn\'t query them\n';
						state.querySuccess = false;
						state.queryFinish = true;
					
						state.sm.Data = data;
					}
				});
			} else
				rebakeGame();
		};
        
        var successCall = function(data)
        {
            console.log('\nStandalone build at:\n' + data);
            Actions.runAction(); 
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall, 60);
    }
}

// android only
function MarketingApp(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Marketing App";
    var errorMsg = this.getErrorMsg(name);

	var appId = this.checkArg('appId');
	var bundleId = this.checkArg('bundleId');
	var destMarketingAppPath = this.checkArg('destMarketingAppPath');
	var marketingAppSourceContent = this.checkArg('marketingAppSourceContent', true);
    var gameServerUrl = this.checkArg('gameServerUrl');
    var gameServerPath = this.checkArg('gameServerPath');
	var androidKeyStore = this.checkArg('androidKeyStore', true);
	var androidKeyPass = this.checkArg('androidKeyPass', true);
	var androidStorePass = this.checkArg('androidStorePass', true);
	var androidKeyAlias = this.checkArg('androidKeyAlias', true);
	
    this.run = function()
    {
		// this means we've downloaded it and want to use the downloaded version
		var downloadedBuild = Global['downloadedBuild'];
		var marketingAppBundlePath = null;
		
		gameServerUrl = gameServerUrl.replace(/\//g, '\\\\/');
		gameServerPath = gameServerPath.replace(/\//g, '\\\\/');
		
        var initCall = function(state)
        {
			return true;
        };
        
        var queryCall = function(state)
        {
			dir(destMarketingAppPath);
			dir(destMarketingAppPath += '/' + appId);
			dir(destMarketingAppPath += '/' + new Date().getTime());
			
			var repackageMarketingApp = function()
			{
				console.log('Repackaging Marketing App');
				var repackageMarketingScriptPath = 'nodelib/repackageMarketingAppTool';
				var repackageMarketingScript = 'unpack_hack_app.sh';
				
				if(!path.existsSync(repackageMarketingScriptPath + '/' + repackageMarketingScript))
				{
					state.sm.errorMsg += 'repackage marketing app script couldn\'t be found (' + repackageMarketingScriptPath + '/' + repackageMarketingScript + ')\n';
					state.querySuccess = false;
					state.queryFinish = true;
				} else
				{
					var outputFile = path.resolve(repackageMarketingScriptPath + '/output-unsigned-unaligned.apk');
					// if it exists let's remove it
					if(path.existsSync(outputFile))
						fs.unlinkSync(outputFile);
					
					var args = [];
					// destination package
					args.push(bundleId);
					// server
					args.push(gameServerUrl);
					// game path on server
					args.push(gameServerPath);
					// destination application name
					args.push(appId);
					
					if(marketingAppSourceContent)
						args.push(path.resolve(marketingAppSourceContent));
					
					var argstring = '';
					for(var i=0; i<args.length; i++)
						argstring += ' ' + args[i];
					
					//console.log(argstring);
					exec('./' + repackageMarketingScript + argstring, { 'cwd': repackageMarketingScriptPath }, function(error, stdout, stderr)
					{
						//console.log(['error', error, error ? error.stack : '', 'stdout', stdout, 'stderr', stderr]);
						if(!error)
						{
							marketingAppBundlePath = outputFile;
							rebakeGame();
						} else
						{
							state.sm.errorMsg += error;
							state.querySuccess = false;
							state.queryFinish = true;
						}
					});
				}
			};
		
			var rebakeGame = function()
			{
				console.log('\nResigning Marketing App');
				var options = 
				{
					'name': appId, 
					'bundleId': bundleId, 
					'server': gameServerUrl, 
					'path': gameServerPath, 
					'dest': destMarketingAppPath,
					'androidBundlePath': marketingAppBundlePath,
					'resignOnly': true,
					'os': 'android'
				};
				
				if(androidKeyStore)
					androidKeyStore = path.resolve(androidKeyStore);
				
				setIf(options, 'androidKeyStore', androidKeyStore);
				setIf(options, 'androidKeyPass', androidKeyPass);
				setIf(options, 'androidStorePass', androidStorePass);
				setIf(options, 'androidKeyAlias', androidKeyAlias);
				
				repackage(options, function(err, data)
				{	
					if(err.b)
					{
						state.sm.errorMsg += err.msg;
						state.querySuccess = false;
						state.queryFinish = true;
					} else
					{
						state.querySuccess = true;
						state.queryFinish = true;
					
						state.sm.Data = data;
					}
				});
			};
		
			repackageMarketingApp();
		};
        
        var successCall = function(data)
        {
            console.log('\nMarketing app at ' + data);
            Actions.runAction(); 
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

function DownloadStandaloneBuild(help)
{
    (Action).bind(this)();
    this.help = help;
    
    var name = "Download Standalone Build";
    var errorMsg = this.getErrorMsg(name);

	//var downloadBundle = this.checkArg('downloadBundle', true);
    var downloadBundle = false;
	var appId = this.checkArg('appId');
	var environment = this.checkArg('environment', true);
	var stageId = this.checkArg('stageId', true);
	var releaseId = this.checkArg('releaseId', true);
	var os = this.checkArg('os');
	var bundleId = this.checkArg('bundleId', true);
	var destDownloadBuild = this.checkArg('destDownloadBuild');

    this.run = function()
    {
		if(Args['standaloneBuild'])
		{
			if(!Args['downloadBundle'])
			{
				Actions.runAction();
				return;
			}
		}
	
        var initCall = function()
        {
            return true;
        };
        
        var queryCall = function(state)
        {
			console.log('Downloading Standalone Build');
			var options = 
			{
				'appId': appId, 
				'environment': environment,
				'stageId': stageId, 
				'releaseId': releaseId, 
				'bundleId': bundleId, 
				'os': os,
				'destDownloadBuild': destDownloadBuild
			};
		
            gameSync.downloadStandaloneBuild(options, function(err, data)
            {
                if(err.b)
                {
                    state.sm.errorMsg += err.msg;
                    state.querySuccess = false;
                    state.queryFinish = true;
                } else
                {
                    var finish = function()
                    {
                        state.querySuccess = true;
                        state.queryFinish = true;
                    
                        state.sm.Data = data;
                    };
                    
                    //setTimeout(finish.bind(this), 2000);
                    finish();
                }
            });
        };
        
        var successCall = function(data)
        {
            console.log('\nDownloaded Standalone build at ' + data);
			Global['downloadedBuild'] = data;
            Actions.runAction(); 
        };
        
        var query = new Query(name, errorMsg, initCall, queryCall, successCall);
    }
}

/**
 * initialize options and arguments
 */
var options = 
[
    { short: 'lsa',
        long: 'listapps',
        description: '',
        actionSet: [Authenticate, SetServerUrl, PrintAppList] },
    { short: 'lss',
        long: 'liststages',
        description: '',
        actionSet: [Authenticate, SetServerUrl, PrintStageList] },
    { short: 'lsr',
        long: 'listreleases',
        description: '',
        actionSet: [Authenticate, SetServerUrl, PrintReleaseList] },
	{ short: 'lrs',
		long: 'listreleasestate',
		description: '',
		actionSet: [Authenticate, SetServerUrl, PrintReleaseState] },
	{ short: 'lri',
		long: 'listreleaseinfo',
		description: '',
		actionSet: [Authenticate, SetServerUrl, PrintReleaseInfo] },
	{ short: 'lpr',
        long: 'listpublishedrelease',
        description: '',
        actionSet: [Authenticate, SetServerUrl, PrintPublishedRelease] },
	{ short: 'lpu',
		long: 'listpublishedurl',
		description: '',
		actionSet: [Authenticate, SetServerUrl, PrintPublishedUrl] },
	{ short: 'ldu',
		long: 'listdeployedurl',
		description: '',
		actionSet: [Authenticate, SetServerUrl, PrintDeployedUrl] },
	{ short: 'lpa',
		long: 'listpublishattempts',
		description: '',
		actionSet: [Authenticate, SetServerUrl, PrintPublishAttempts] },
    { short: 's',
        long: 'addStage',
        description: '',
        actionSet: [Authenticate, SetServerUrl, AddStage] },
	{ short: 'dr',
        long: 'deployRelease',
        description: '',
        actionSet: [Authenticate, SetServerUrl, BakeGame, DeployRelease] },
    { short: 'pr',
        long: 'publishRelease',
        description: '',
        actionSet: [Authenticate, SetServerUrl, PublishRelease] },
	{ short: 'r',
        long: 'release',
        description: 'Publishes and Deploys the release',
        actionSet: [Authenticate, SetServerUrl, BakeGame, DeployRelease, WaitForDeployment, PublishRelease] },
    { short: 'b',
        long: 'bakeGame',
        actionSet: [BakeGame]},
    { short: 'sb',
        long: 'standaloneBuild',
        actionSet: [Authenticate, SetServerUrl, StandaloneBuild] },
	{ short: 'ma',
		long: 'marketingApp',
		actionSet: [MarketingApp] },
	{ short: 'ct',
		long: 'clearTokens',
		actionSet: [ClearTokens] },
	{ short: 'v',
        description: 'Prints the version of ngPackager',
		actionSet: [PrintVersion] },
    { long: 'userId',
        description: 'userId is needed for most calls',
        value: true },
    { long: 'pass',
        description: 'If no password is specified you will be prompted for one',
        value: true },
	{ long: 'authHost',
		description: '',
		value: true },
	{ long: 'nonVerbose',
        hidden: true,
		description: '' },
    { long: 'appId',
        value: true },
    { long: 'stageId',
        value: true },
    { long: 'releaseId',
        value: true },
	{ long: 'environment',
		value: true },
	{ long: 'version',
        value: true },
    { long: 'toolPath',
        value: true },
    { long: 'destBakedPath',
        value: true },
    { long: 'destBuildPath',
        value: true },
	{ long: 'destMarketingAppPath',
		description: 'The base path for your marketing app to be output to, the default is recommended',
		value: true },
	{ long: 'marketingAppSourceContent',
		description: 'A path that contains icon and background images for your app',
		value: true },
	{ long: 'destDownloadBuild',
		value: true },
    { long: 'gameServerUrl',
        value: true },
    { long: 'gameServerPath',
        value: true },
    { long: 'iOSBundlePath',
        value: true },
    { long: 'iOSIdentity',
        value: true },
    { long: 'iOSProfile',
        value: true },
	{ long: 'androidBundlePath',
        hidden: true,
		value: true },
	{ long: 'androidKeyStore',
        hidden: true,
		value: true },
	{ long: 'androidKeyPass',
        hidden: true,
		value: true },
	{ long: 'androidStorePass',
        hidden: true,
		value: true },
	{ long: 'androidKeyAlias',
        hidden: true,
		value: true },
    { long: 'bundleId',
        value: true },
    { long: 'gamePath',
        value: true },
	{ long: 'os',
        hidden: true,
        value: true },
    { long: 'comment',
        hidden: true,
        description: 'Certain actions can contain comments',
        value: true },
    { long: 'region',
        hidden: true,
        value: true },
    { long: 'appName',
        value: true },
    { long: 'serverUrl', 
        description: 'The Url of the packaging server, default should typically be used',
        value: true },
    { long: 'serverPort', 
        description: 'The Port of the packaging server, default should typically be used',
        value: true },
    { long: 'config',
        description: 'path to a config file to use',
        value: true },
    { long: 'noBake',
        description: ''},
	/*{ long: 'downloadBundle',
		description: 'used in standlone builds' },*/
	{ long: 'secureUrl',
		description: '' },
	{ long: 'publishManifest',
		description: '' },
	{ long: 'count',
		value: true,
		description: '' },
	{ long: 'generateArchives',
		description: 'generateArchives' },
    { long: 'jslint',
		value: true,
		description: 'jslint' },
    { long: 'androidResize',
		value: true,
		description: 'resize img 2 pow for android' },
    { long        : 'help',
        callback    : help }
];

for(var i=0; i<options.length; i++)
    OptsByName[options[i].long] = options[i];

opts.parse(options);


/**
 * in the preinit we check if any action is specified, if not we let the user know
 */
function preinit()
{
    var actionSet = getActionSet();
    if(actionSet)
    {
        // there are actions
        init(function()
        {
            //dumpArgs();
            pushActionSet(actionSet);
            Actions.init();
            Actions.runAction();
        });
    } else
    {
		var finish = function()
		{
			// no actions
			if(!opts.get('help'))
				help();
			
			console.log("no action specified");
			};
		try
		{
			init(function()
			{
				finish();
			});
		} catch (e)
		{
			finish();
		}
    }
}

/**
 * Prints all of the Args
 */
function dumpArgs()
{
    console.log("\nDumping Args...");
    for(arg in Args)
    {
        if(Args[arg])
            console.log(arg + '=' + Args[arg]);
    }
    console.log("");
}

/**
 * iterates through the specified options and finds the first one set with an actionSet
 */
function getActionSet()
{
    var actionSet = null;
    
    for(var i=0; i<options.length; i++)
    {
        var opt = options[i];
        if(opt.actionSet)
        {
            var optName = opt.long;
            if(!optName)
                optName = opt.short;
            
            if(opts.get(optName))
            {
                actionSet = opt.actionSet;
                break;
            }
        }
    }
    
    return actionSet;
}

/**
 * load the config, sync up the values against any arguments passed in, the args passed in have 
 * priority 
 */
function init(callback)
{
	if(initConfig(function()
	{
		for(var i=0; i<options.length; i++)
		{
			var optName = options[i].long || options[i].short;
			var opt = opts.get(optName);
			
			if(!opt && Config[optName])
				opt = Config[optName];
			
			Args[optName] = opt;
		}
		
		callback();
	}));
}

function dir(dirPath)
{
	if(!path.existsSync(dirPath))
		fs.mkdirSync(dirPath);
}

function initConfig(cb)
{
	loadConfigFile(DefaultConfigFile, function()
	{
		var configFile = opts.get('config');
		
		if(configFile)
			loadConfigFile(configFile, cb);
		else
			cb();
	});
};

/**
 * Load the passed in config file and sync it
 */
function loadConfigFile(srcConfigFile, callback)
{
    path.exists(srcConfigFile, function(exists)
    {
        if(exists)
        {
            fs.stat(srcConfigFile, function(err, stat)
            {
                if(!stat.isFile())
                {
                    console.log("could not load config file, it is not a file");
                } else
                {
                    var configString = fs.readFileSync(srcConfigFile).toString();
                    var data = {};
                    vm.runInNewContext(configString, data);
					syncConfig(data.config, callback);
                }
            });
        } else
        {
            console.log(srcConfigFile + " doesn't exist");
            callback();
        }
    });
};

/**
 * Iterates over each of the configs properties and syncs it, if an include is found then
 * immediately load that one 
 */
function syncConfig(srcConfig, callback, startIndex)
{
    if(!startIndex)
        startIndex = 0;

    var i = 0;
    for(prop in srcConfig)
    {
        if(i<startIndex)
        {
            i++;
            continue;
        }
        
        if(prop === 'include')
        {
            loadConfigFile(srcConfig[prop], function()
            {
                syncConfig(srcConfig, callback, i+1);
            });
            return;
        } else
        {
            Config[prop] = srcConfig[prop];
        }
        i++;
    }
    
    callback();
}

/**
 * Push an action set onto the ActionQueue
 */
function pushActionSet(actionSet)
{
    for(var i=(actionSet.length-1); i >= 0; i--)
    {
        ActionQueue.push(actionSet[i]);
    }
}

/**
 * Pop the current action off the queue and run it
 */
var Actions = new function()
{
    this.queue = [];

    this.isInit = false;
    this.init = function()
    {
        while(ActionQueue.length > 0)
        {
            var actionClass = ActionQueue.shift();
            var action = new actionClass();
            this.queue.push(action);
        }
        
        this.isInit = true;
    };

    this.runAction = function()
    {
        if(!this.isInit)
        {
            this.init();
        }
		
        if(this.queue.length > 0)
        {
            var action = this.queue.pop();
			action.run();
            return true;
        }
        
        setTimeout(function()
		{
			process.exit(0);
		}, 100);
	};
};

/**
 * Display the error and exit
 */
function FatalError(message)
{
    console.log('\nFatal Error: ' + message);
    process.exit(1);
}

/**
 * Query (Class) - designed to encapsulate a simple state machine that triggers a few predefined 
 * steps
 *   Init     - initCall is called at the beggining, if true is returned it will proceed 
 *              immediately to the next stage, if false is returned the .Done method needs to be 
 *              called on the Init    stage for it to proceed
 *
 *   Querying - queryCall is called after some initial timing values are set, this allows for the 
 *              interfacing element to hook in and must set .queryFinish to true when it's ready to      
 *              proceeed, Success and Fail are called based on .querySuccess, data must also be set   
 *              if it is to be passed to the successCall
 *
 *   Success  - Cleans up and then calls successCall passing data 
 *   Fail     - Cleans up and triggers a FatalError
 */
function Query(name, errorMsg, initCall, queryCall, successCall, timeoutLimit)
{
    var Name = name;
    var InitCall = initCall;
    var QueryCall = queryCall;
    var SuccessCall = successCall;
	var TimeoutLimit = timeoutLimit || 15;

    var Init = new State('Init');
    var Querying = new State('Querying');
    var Success = new State('Success');
    var Fail = new State('Fail');

    this.Init = Init;
    this.Querying = Querying;
    this.Success = Success;
    this.Fail = Fail;

    var SM = new StateMachine(100);
    SM.add(Init);
    SM.add(Querying);
    SM.add(Success);
    SM.add(Fail);
    
    var errorMsg = errorMsg;
    SM.errorMsg = errorMsg;
    var CleanUp = function()
    {
        SM.kill();
    };

    SM.Data = null;
    
    
    Init.init = function()
    {
        var success = InitCall(this);
        
        if(success)
        {
            this.done();
        }
    };
    
    Init.done = function()
    {
        SM.delayTrigger(Querying);
    };
    
    
    Querying.init = function()
    {
        this.timeoutLimit = TimeoutLimit * 1000;
        this.timeout = 0;
        this.queryTime = 0;
        this.queryFinish = false;
        
        QueryCall(this);
    };
    
    this.setRunDisplayCallback = function(callback)
    {
        this.runDisplayCallback = callback;
    };

    Querying.run = function(delta)
    {
        if(!this.queryFinish)
        {
            this.timeout += delta;
            this.queryTime += delta;
           
            if(this.timeout > this.timeoutLimit)
            {
                errorMsg += '\n' + Name + ' query timed out (' + this.timeoutLimit + 'ms)\n';
                SM.delayTrigger(Fail, true);
            } else if(this.queryTime > 500)
            {
				if(!this.sm.runDisplayCallback)
                    sys.print('.');
                else
                    this.sm.runDisplayCallback();
                
                this.queryTime = 0;
            }
        } else
        {
            if(this.querySuccess)
            {
                SM.delayTrigger(Success, true);
            } else
            {
                errorMsg += '\n' + Name + ' query failed\n';
                SM.delayTrigger(Fail, true);
            }
        }
    };
    
    
    Success.init = function()
    {
        CleanUp();
        SuccessCall(SM.Data);
    };
    
    Fail.init = function()
    {
        CleanUp();
        FatalError(SM.errorMsg);
    };
    
    SM.trigger(Init, true);
}



preinit();