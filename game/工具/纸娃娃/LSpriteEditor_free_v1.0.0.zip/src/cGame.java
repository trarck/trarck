import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import java.io.*;
import javax.microedition.lcdui.*;

public class cGame extends Canvas implements Runnable, DEF_GAME{

	static Graphics m_g;
	
	public static LSprite sprite;
	public static LSpriteInstance spriteInstance = null;
	
	public static int m_game_state;
	private static long m_lastFrameTimer;
	

	cGame() {
		m_game_state = DEF_GAME.LOADING;
		new Thread(this).start();
	}
	
	protected void paint(Graphics g) {
		m_g = g;
		update();
	}

	public void run() {
		m_lastFrameTimer = System.currentTimeMillis ();	
		repaint ();
		
		long delta;
		do{
			delta = System.currentTimeMillis () - m_lastFrameTimer;
			Thread.yield ();
		}
		while (delta >= 0 && delta < (1000 / DEF_GAME.FPS));
		
	    cMIDlet.m_display.callSerially (this);
	}
	
	public static void update() {
		switch(m_game_state) {
			case DEF_GAME.LOADING:
				try {
					InputStream is = "".getClass().getResourceAsStream("/soldier.bin");
					sprite = new LSprite();
					byte[] fb = new byte[is.available()];
					is.read(fb);
					sprite.Load(fb, 0);
					spriteInstance = new LSpriteInstance(sprite,SCREEN_WIDTH >> 1,SCREEN_HEIGHT >> 1);
					is.close();
				} catch (Exception e) {
				    e.printStackTrace();
				}
				m_game_state = DEF_GAME.DISPLAY;
				break;
			case DEF_GAME.DISPLAY:
				try {
					m_g.setColor(0);
					m_g.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
					
					spriteInstance.SetAnim(2);
//					aspriteInstance.SetFlag(1); //1 FLIP_X, 2 FLIP_Y 
					spriteInstance.UpdateSpriteAnim();
					spriteInstance.PaintSprite(m_g);

					m_g.setColor(0xff0000ff);
					m_g.drawLine(0, SCREEN_HEIGHT >> 1, SCREEN_WIDTH, SCREEN_HEIGHT >> 1);
					m_g.drawLine(SCREEN_WIDTH >> 1, 0, SCREEN_WIDTH >> 1, SCREEN_HEIGHT);
					
				} catch (Exception e) {
				    e.printStackTrace();
				}
				break;
		}
	}
	
	
}
