/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

import com.studio.motionwelder.MSprite;
import com.studio.motionwelder.MSpriteImageLoader;

/**
 * Resource Loader: Class to load Images
 * @author Nitin Pokar (pokar.nitin@gmail.com)
 *
 */
public class ResourceLoader implements MSpriteImageLoader{

	/** Making Class Singleton */
	static private ResourceLoader resourceLoader;
	private ResourceLoader(){}

	static public ResourceLoader getInstance(){
		if(resourceLoader==null){
			resourceLoader = new ResourceLoader();
		}
		return resourceLoader;
	}
	
	/**
	 *  Function : LoadImage will be called while loading .anu.
	 *  This version of Load Image will be called when .anu is loaded without chopping images
     *  In this example we have not loaded any .anu where we have passed false to MSpriteLoader, hence this function will never be called
	 */
	public Image[] loadImage(String spriteName,int imageId,int orientationUsedInStudio){
		// returning null, as we are clipping the image in this example, this function will never be called 
		return null;
	}
	
	/**
	 *  If you are using Nokia DirectGraphics, please don't load flipped image, Instead modify MPlayer to flip it at runtime 
	 *
	 *  Function : LoadImageClip will be called while loading .anu.
	 *  This version of Load Image will be called when .anu is loaded with chopped images
     *  In this example we have loaded .anu with passing true in MSpriteLoader, hence this function will be called
	 */
	public Image[] loadImageClip(String spriteName,int imageId,int x,int y,int w,int h,int orientationUsedInStudio){
		// determine whether i need flipped version in my game
		boolean doYouNeedHFlippedSpriteInYourgame=false;
		boolean doYouNeedVFlippedSpriteInYourgame=false;
		
		Image baseImage=null;
		if(spriteName.equals("/mongo/mongo.anu")){
			if(imageId==0){
				baseImage = loadImage("/mongo/character.png");
				doYouNeedHFlippedSpriteInYourgame = true; // mongo need any flip, as that monkey moves both in left and right
				doYouNeedVFlippedSpriteInYourgame = false;
			}else if(imageId==1){
				baseImage = loadImage("/mongo/banana.png");
				doYouNeedHFlippedSpriteInYourgame = false; // banana doesn't need any flip
				doYouNeedVFlippedSpriteInYourgame = false;
			}
		}
		
		Image[] image = new Image[3];
		image[0] = Image.createImage(baseImage,x,y,w,h,Sprite.TRANS_NONE);
		
		/** Please don't load this if using Nokia Direct Graphics */
		if(orientationUsedInStudio==MSprite.ORIENTATION_FLIP_H || orientationUsedInStudio==MSprite.ORIENTATION_FLIP_BOTH_H_V ||doYouNeedHFlippedSpriteInYourgame )
			image[1] = Image.createImage(baseImage,x,y,w,h,Sprite.TRANS_MIRROR);
		
		/** Please don't load this if using Nokia Direct Graphics */
		if(orientationUsedInStudio==MSprite.ORIENTATION_FLIP_V || orientationUsedInStudio==MSprite.ORIENTATION_FLIP_BOTH_H_V || doYouNeedVFlippedSpriteInYourgame)
			image[2] = Image.createImage(baseImage,x,y,w,h,Sprite.TRANS_MIRROR_ROT180);
		
		return image;
	}
	
	public static Image loadImage(String str){
		try{
			return Image.createImage(str);
		}catch (Exception e) {
			System.out.println("Error loading Image " + str);
		}
		return null;
	}
}
