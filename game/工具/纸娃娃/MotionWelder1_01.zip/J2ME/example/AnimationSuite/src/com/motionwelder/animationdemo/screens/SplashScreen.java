/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.screens;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.motionwelder.animationdemo.MainCanvas;
import com.motionwelder.animationdemo.ResourceLoader;
import com.motionwelder.animationdemo.utils.Screen;

public class SplashScreen implements Screen{
	
	public SplashScreen(){
		logoImage = ResourceLoader.loadImage("/logo.png");
	}
	
	int ctr;
	Image logoImage;
	public void paint(Graphics g){
		
		g.drawImage(logoImage,0,0,20);
		if(ctr>=15){
			MainCanvas.switchScreen(new AnimationViewerIntroScreen());
		}
	}
	
	public void update(){
		ctr++;
	}
	
	

}
