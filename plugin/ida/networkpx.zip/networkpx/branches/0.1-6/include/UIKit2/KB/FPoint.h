#ifndef UIKIT2_KB_FPOINT_H
#define UIKIT2_KB_FPOINT_H

namespace KB {
	struct FPoint {
		float x, y;
	};
};

#endif