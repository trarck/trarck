/*
 
 GraphicsUtilities.h ... Convenient functions for UI elements
 
 Copyright (c) 2009, KennyTM~
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 
 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of the KennyTM~ nor the names of its contributors may be
   used to endorse or promote products derived from this software without
   specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
 */

#import <Foundation/NSObject.h>
#import <CoreGraphics/CGGeometry.h>
@class UIView, NSString, UIWebDocumentView;

// Log UIView Hierarchy (downwards/upwards) with NSLog.
void UILogViewHierarchy (UIView* v);
void UILogSuperviews (UIView* v);

// Get title of UIView for debugging.
NSString* UITextOf(UIView* v);

@interface UIWebTexts : NSObject {
	NSString* text;
	NSString* linkLabel;
	NSString* URL;
	NSString* alt;
	NSString* imageURL;
	NSString* title;
	UIView* view;
	CGRect rect;
	int userInfo;
}
@property(retain) NSString* text;
@property(retain) NSString* linkLabel;
@property(retain) NSString* URL;
@property(retain) NSString* alt;
@property(retain) NSString* imageURL;
@property(retain) NSString* title;
@property(assign) UIView* view;
@property(assign) CGRect rect;
@property(assign) int userInfo;
-(void)dealloc;
-(NSString*)description;
@end

// Get texts with extended information at point.
// Primarily used for UIWebDocumentView
UIWebTexts* UITextsAtPoint(UIView* view, CGPoint pt);

// Get localized string
NSString* UILocalizedString(const char* str);