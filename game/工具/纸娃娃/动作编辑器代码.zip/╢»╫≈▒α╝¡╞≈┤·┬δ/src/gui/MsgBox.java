package gui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionListener;

/**
 * <p>Title: Game Editors</p>
 * <p>Description: Editors and tools for 2D games</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Gameloft, Beijing</p>
 * @author Qiu Wei Min
 * @version 1.0
 */

public class MsgBox extends Dialog implements ActionListener
{
	/** ���а汾ID */
	private static final long serialVersionUID = -6959731875850001416L;
	public final static int TYPE_OK = 0;
	public final static int TYPE_YESNO = 1;
	public final static int OK = 0;
	public final static int YES = 1;
	public final static int NO = 2;

	int ret;

	public MsgBox(Frame parent, String title, String msg)
	{
		super(parent, title, true);
		setLayout(new BorderLayout(2, 1));
		add(new TextArea(msg), "Center");
		Button btn = new Button("ȷ��");
		setSize(600, 200);
		centerOnParent(parent);
		btn.addActionListener(this);
		add(btn, "South");
	}

	public MsgBox(Frame parent, String title, String msg, int type)
	{
		super(parent, title, true);
		setLayout(new GridLayout(2, 1));
		setSize(600, 200);
		centerOnParent(parent);
		add(new TextArea(msg));
		Panel pan = new Panel(new GridLayout(1, 2));
		add(pan);
		Button btn = new Button("��");
		btn.addActionListener(this);
		pan.add(btn);
		if (type == TYPE_YESNO)
		{
			btn = new Button("��");
			btn.addActionListener(this);
			pan.add(btn);
		}
	}

	private void centerOnParent(Component comp)
	{
		setLocation(comp.getLocation().x + (comp.getSize().width - getSize().width) / 2, comp.getLocation().y
				+ (comp.getSize().height - getSize().height) / 2);
	}

	public void actionPerformed(java.awt.event.ActionEvent actionEvent)
	{
		if (actionEvent.getActionCommand() == "ȷ��")
		{
			ret = OK;
			dispose();
		}
		if (actionEvent.getActionCommand() == "��")
		{
			ret = YES;
			dispose();
		}
		if (actionEvent.getActionCommand() == "��")
		{
			ret = NO;
			dispose();
		}
	}
}