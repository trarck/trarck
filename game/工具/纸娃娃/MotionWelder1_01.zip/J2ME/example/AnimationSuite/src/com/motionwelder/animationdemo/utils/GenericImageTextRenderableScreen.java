/*
 * COPYRIGHT - MOTIONWELDER
 */
package com.motionwelder.animationdemo.utils;

import java.util.Vector;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.motionwelder.animationdemo.MainCanvas;
import com.motionwelder.animationdemo.MainMidlet;

public class GenericImageTextRenderableScreen implements Screen{

	private int renderOffset;
	private Vector elementVector;
	private int screenHeight;
	private int visibleHeight =  MainMidlet.getCanvasInstance().getHeight()-(15+15);
	int vGap = 4;
	
	
	public GenericImageTextRenderableScreen(){
		renderOffset = 0;
		elementVector = new Vector();
	}
	
	public void append(String str){
		elementVector.addElement(str);
	}
	
	public void append(Image image){
		elementVector.addElement(image);
	}
	
	
	public void paint(Graphics g){
		g.setColor(0xffffff);
		int position=15;
		g.setClip(0,15,MainMidlet.getCanvasInstance().getWidth(),visibleHeight);
		
		for(int i=0;i<elementVector.size();i++){
			int absolutePos = position-renderOffset;
			if(elementVector.elementAt(i) instanceof String){
				drawStringAt(g,(String)elementVector.elementAt(i),absolutePos);
				position += MainCanvas.font.getHeight();
			} else if(elementVector.elementAt(i) instanceof Image){
				Image img = (Image)elementVector.elementAt(i);
				drawImageAt(g,img,absolutePos);
				position += img.getHeight();
			}
			position+=vGap;
		}
		
		g.setClip(0,0,MainMidlet.getCanvasInstance().getWidth(),MainMidlet.getCanvasInstance().getHeight());
	}
	
	private void drawImageAt(Graphics g,Image img, int yPos){
		int xPos =  (MainMidlet.getCanvasInstance().getWidth()>>1) - (img.getWidth()>>1);
		g.drawImage(img,xPos,yPos,20);
	}
	
	private void drawStringAt(Graphics g,String str, int yPos){
		g.drawString(str,15,yPos,20);
	}
	
	public void calculateScreenHeight(){
		screenHeight = 0;
		for(int i=0;i<elementVector.size();i++){
			if(elementVector.elementAt(i) instanceof String){
				screenHeight += MainCanvas.font.getHeight() +vGap;
			} else if(elementVector.elementAt(i) instanceof Image){
				Image img = (Image)elementVector.elementAt(i);
				screenHeight += img.getHeight()+vGap;
			}
		}
	}

	
	public void update(){
		if((MainCanvas.keyPressed&(Key.UP|Key.NUM2))!=0  ||  (MainCanvas.keyKeptPressed&(Key.UP|Key.NUM2))!=0){
			renderOffset-=5;
			if(renderOffset<0)
				renderOffset=0;
		} else if((MainCanvas.keyPressed&(Key.DOWN|Key.NUM8))!=0  || (MainCanvas.keyKeptPressed&(Key.DOWN|Key.NUM8))!=0){
			renderOffset+=5;
			if(renderOffset > screenHeight - visibleHeight){
				renderOffset = screenHeight - visibleHeight;
			}
		}
	}
}

